# 数式カード保管庫 (Equations)

重要な数式（例: `ricci_tensor.md`, `geodesic_equation.md`）の文法分解・導出をここに保存します。
- 記号対応表
- 項ごとの分解
- 導出過程
- 幾何学的・物理的意味
