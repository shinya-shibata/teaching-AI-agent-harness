# 数学・理論物理 概念グラフ インデックス (Concept Knowledge Graph)

このファイルは、本ハーネスで学習・解説した概念（`research/concepts/`）と数式（`research/equations/`）の依存関係をまとめるマスターインデックスです。
エージェントは新しい概念を解説した際、このファイルの関係図を更新します。

---

## 🗺️ 概念依存関係マップ (Concept Dependency Tree)

```mermaid
graph TD
    %% 基礎数学
    VEC["ベクトル空間<br>(Vector Space)"] --> TANGENT["接空間<br>(Tangent Space)"]
    CALC["多変数微積分<br>(Multivariable Calculus)"] --> MANIFOLD["可微分多様体<br>(Smooth Manifold)"]
    
    %% 微分幾何
    MANIFOLD --> TANGENT
    TANGENT --> VECTORFIELD["ベクトル場 / リー括弧積<br>(Vector Fields / Lie Bracket)"]
    TANGENT --> METRIC["リーマン計量<br>(Riemannian Metric)"]
    
    %% 接続・微分
    VECTORFIELD --> CONN["アフィン接続 / 共変微分<br>(Affine Connection / ∇)"]
    METRIC --> LEVICIVITA["レヴィ=チヴィタ接続<br>(Levi-Civita Connection)"]
    CONN --> LEVICIVITA
    
    %% 曲率
    LEVICIVITA --> RIEMANN["リーマン曲率テンソル<br>(Riemann Curvature R)"]
    CONN --> RIEMANN
    RIEMANN --> RICCI["Ricci曲率 / 方程式<br>(Ricci Curvature / Equation)"]
    RICCI --> SCALAR["スカラー曲率<br>(Scalar Curvature)"]
    
    %% 発展・情報幾何
    CONN --> DUALCONN["双対接続 / α-接続<br>(Dual / α-Connection)"]
    METRIC --> FISHER["Fisher情報計量<br>(Fisher Information Metric)"]
    FISHER --> INFOGEOM["情報幾何学<br>(Information Geometry)"]
    DUALCONN --> INFOGEOM
```

---

## 📚 登録済み概念・数式カード一覧

| 概念 / 数式 | カテゴリ | 関連ファイル | 依存前提 |
| :--- | :--- | :--- | :--- |
| *（解説が行われると自動的にここへ追記されます）* | | | |
