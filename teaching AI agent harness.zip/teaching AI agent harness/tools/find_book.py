"""
find_book.py - 科学専門書 869冊 (books.md) からキーワードに合致する蔵書を検索するローカルツール
物理学、数学、化学、CS、自然科学、生物学、神経科学の蔵書から最適な書籍を瞬時に抽出します。
"""

import sys
import os
import re
from pathlib import Path

# Windowsのコンソール出力エンコーディング対策
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def search_books(keywords, max_results=5):
    books_file = Path(__file__).resolve().parent.parent / "books.md"
    if not books_file.exists():
        print(f"Error: {books_file} not found")
        return []

    with open(books_file, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    # テーブル行のパース: | # | 分野 | タイトル | 著者 | 出版社 | ページ数 | 出版年 | ...
    pattern = re.compile(
        r"^\|\s*\d+\s*\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)\|",
        re.MULTILINE
    )
    matches = pattern.findall(content)

    results = []
    kw_lower = [k.lower() for k in keywords if len(k) > 1]

    for field, title, author, publisher, pages, year in matches:
        field = field.strip()
        title = title.strip()
        author = author.strip()
        full_text = f"{field} {title} {author} {publisher}".lower()

        # スコアリング（マッチしたキーワード数）
        score = sum(1 for kw in kw_lower if kw in full_text)
        if score > 0:
            results.append({
                "score": score,
                "field": field,
                "title": title,
                "author": author,
                "year": year.strip(),
                "publisher": publisher.strip()
            })

    # スコア順・新しい出版年順にソート
    results.sort(key=lambda x: (x["score"], x["year"]), reverse=True)
    return results[:max_results]

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python find_book.py <keyword1> <keyword2> ...")
        sys.exit(1)

    queries = sys.argv[1:]
    hits = search_books(queries)
    if not hits:
        print("一致する科学専門書が見つかりませんでした。")
    else:
        print(f"=== books.md (科学蔵書 869冊) からのマッチ結果 (上位 {len(hits)} 件) ===")
        for i, b in enumerate(hits, 1):
            print(f"{i}. [{b['field']}] 『{b['title']}』/ 著: {b['author']} ({b['year']}年, {b['publisher']})")
