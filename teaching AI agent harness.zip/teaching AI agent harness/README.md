# 数学・理論物理 研究読解 AI Harness (VS Code Native)

外部AI APIキー（OpenAI/Claude API等）を一切使わず、**VS Code組み込みのAI Agent（GitHub Copilot, Cursor, Antigravity等）だけで完結**して論文や数式を解説・研究するためのハーネスです。

---

## 📁 ディレクトリ構造

```text
teaching AI agent harness/
│
├── .github/
│   ├── copilot-instructions.md       # エージェント行動規範（3言語翻訳、視覚化、バッチ処理ルール）
│   └── prompts/                      # ショートカット用プロンプトテンプレート
│       ├── visual-explain.prompt.md  # 🎨 「絵を書いてわかりやすく教えて」
│       ├── derive.prompt.md          # 📐 「数式の導出方法をわかりやすく教えて」
│       ├── example.prompt.md         # 💡 「簡単な例題を解いてわかりやすく教えて」
│       ├── book-quote-explain.prompt.md # 📚 「最適な本から引用して教えて（books.md連携）」
│       ├── batch-triage.prompt.md    # ⚡ 「大量の疑問を一括整理して（トリアージ）」
│       ├── generate-guide.prompt.md  # 📖 「疑問を一括解説する集中講義録を作成して」
│       ├── decompose.prompt.md       # 🔬 「数式を分解して教えて」
│       ├── lineage.prompt.md         # 📜 「文献の系譜を遡って教えて」
│       ├── feynman.prompt.md         # 🍎 「ファインマン流にわかりやすく教えて」
│       ├── podcast-script.prompt.md  # 🎙️ 「音声学習用スクリプトを作成して」
│       └── verify-sympy.prompt.md    # 🐍 「数式を計算・検証して（SymPy）」
│
├── books.md                          # 📚 推薦・参照図書カタログ（最適な本の自動選定・引用元）
│
├── instructions/                     # 専用 Custom Instructions
│   └── feynman-technique.md          # 🧠 ファインマン・テクニックの専用行動規範（比喩・平易化原則）
│
├── questions/                        # 疑問のバッチ処理・進捗管理
│   ├── inbox.md                      # 📥 読書中の疑問を殴り書きするポスト
│   └── queue.md                      # 📊 優先度別タスクボード・進捗トラッカー
│
├── papers/                           # 読みたい論文や資料の保管場所（PDF, TeX, MD）
│
├── research/                         # 知識蓄積（Markdown Research OS）
│   ├── index.md                      # 🗺️ 概念依存関係マスターマップ（Mermaid）
│   ├── concepts/                     # 概念カード（curvature.md 等）
│   ├── equations/                    # 数式カード（ricci_tensor.md 等）
│   ├── audio_scripts/                 # 🎧 TTS向け音声解説台本・読み上げ辞書
│   └── explanations/                 # 生成された解説ログ・集中講義録
│
├── profile/
│   └── user_knowledge.md            # ユーザーの理解度・説明の好み（エージェントが自動参照）
│
├── how to study mathematics.md       # 構想メモ・文献系譜プロンプト原案
└── ChatGPT-AI Agent設計案-20260927-2145.md # 7層アーキテクチャ設計メモ
```

---

## ⚡ 【最重要】プロンプト不要の階層型モード (Progressive Zero-Prompt Mode)

長文のプロンプトを毎回書く必要はありません。
論文ファイルで分からない箇所を選択し、チャットに **`?`（クエスチョンマーク1文字）** と打つだけで、まず短い「超要約ダイジェスト」が返ります。導出や例題は、末尾の番号メニューを選んだときだけ展開されます：

```text
[ 論文の分からない箇所をマウスで選択 ]
                   │
                   ▼ チャットに「?」1文字だけ打って送信！
┌────────────────────────────────────────────────────────┐
│             🤖 超要約ダイジェスト（第1段階）           │
│                                                        │
│  ①【絵・図解】幾何学的イメージ（ASCII/Mermaid）を描画    │
│  ②【手のひら直感】日常比喩で本質を1〜2行に凝縮          │
│  ③【結論式】代数・幾何・物理の3視点で要約               │
│  ④【最適書籍】books.mdから1冊と核心アプローチを紹介     │
│                                                        │
│  👉 1:導出 2:例題 3:書籍詳細 4:系譜 5:保存 で追従展開   │
└────────────────────────────────────────────────────────┘
```

---

## ⚡ 大量の疑問を効率よく処理する流れ（バッチ処理ワークフロー）

論文を読んでいて「分からない箇所が何十個もある」場合は、以下の**ドミノ倒しバッチ処理**を使います。

```text
[ 1. 読書中にメモ ] ──> questions/inbox.md に疑問・数式を箇条書きで乱雑にコピペ
                                │
[ 2. 一括トリアージ ] ──> AIチャットで「大量の疑問を一括整理して」と指示
                                │ （共通の根本原因をクラスタリングし、queue.md を自動生成）
                                ▼
[ 3. 集中講義録を生成 ] ──> AIチャットで「疑問を一括解説する集中講義録を作成して」と指示
                                │ （絵・トイモデル・行間QAが詰まったReading Guideを一括生成）
                                ▼
[ 4. 一網打尽に解消 ] ──> 1本のガイドを読むだけで芋づる式に疑問が解消し、進捗が [x] になる
```

---

## 🎯 目的別ショートカットコマンド一覧

| やりたいこと | 入力フレーズ（チャットで送信） | 実行されるプロンプト |
| :--- | :--- | :--- |
| **⚡ 階層型お任せ（最推奨）** | **`?`** または `auto` | [auto.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/auto.prompt.md) (まず超要約、番号選択で導出・例題・保存を展開) |
| **大量の疑問を整理したい** | `大量の疑問を一括整理して` | [batch-triage.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/batch-triage.prompt.md) |
| **疑問群を一括解説してほしい** | `疑問を一括解説する集中講義録を作成して` | [generate-guide.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/generate-guide.prompt.md) |
| **絵・図解で直感理解** | `絵を書いてわかりやすく教えて` | [visual-explain.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/visual-explain.prompt.md) |
| **数式の導出・行間** | `数式の導出方法をわかりやすく教えて` | [derive.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/derive.prompt.md) |
| **簡単な例題で手計算** | `簡単な例題を解いてわかりやすく教えて` | [example.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/example.prompt.md) |
| **最適な本から引用解説** | `最適な本から引用して教えて` | [book-quote-explain.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/book-quote-explain.prompt.md) |
| **数式の項・文法分解** | `数式を分解して教えて` | [decompose.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/decompose.prompt.md) |
| **文献系譜・原典遡及** | `文献の系譜を遡って教えて` | [lineage.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/lineage.prompt.md) |
| **ファインマン平易化** | `ファインマン流にわかりやすく教えて` | [feynman.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/feynman.prompt.md) |
| **耳で聴く音声台本** | `音声学習用スクリプトを作成して` | [podcast-script.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/podcast-script.prompt.md) (一人語りが標準。台本と読み上げ辞書を `research/audio_scripts/` に保存) |
| **SymPyによる計算検証** | `数式を計算・検証して` | [verify-sympy.prompt.md](file:///c:/Users/user/Downloads/teaching%20AI%20agent%20harness/.github/prompts/verify-sympy.prompt.md) |
