# 科学・専門書 蔵書ライブラリ (Academic Science Library - books.md)

物理学、数学、化学、コンピュータサイエンス、自然科学、生物学、神経科学（STEM領域）の専門書カタログです。
エージェントは論文の分からない箇所に対し、この蔵書リストから最も適切な書籍を選定して引用・解説します。

## 📊 蔵書概要 (Science Library Summary)
- **総科学蔵書数:** 869 冊
- **1. 読書中 (Currently Reading):** 6 冊
- **2. 読了 (Read):** 89 冊
- **3. 中断 (Did Not Finish):** 0 冊
- **4. 読みたい本 (To Read):** 774 冊

---

## 1. 読書中 (Currently Reading) (6 冊)

| # | 分野 (Field) | タイトル (Title) | 著者 (Author) | 出版社 (Publisher) | ページ数 | 出版年 | ISBN13 | 追加日 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 生物学・生命科学 (Biology) | Principles of Nutrigenetics and Nutrigenomics: Fundamentals of Individualized Nutrition | Raffaele De Caterina (他: Alfredo J. Martinez, Martin Kohlmeier) | Academic Press | 586 p. | 2019 | 9780128045725 | 2023/10/02 |
| 2 | 物理学 (Physics) | Complexity, Entropy and the Physics of Information | Wojciech Hubert Zurek | CRC Press | 548 p. | 1989 (1990) | 9780201515060 | 2023/10/02 |
| 3 | 数学 (Mathematics) | Comprehensive List of Mathematical Symbols: Complete Version | Math Vault | Math Vault Publishing | - | 2020 | - | 2023/10/02 |
| 4 | 数学 (Mathematics) | Bone Morphogenetic Proteins: Systems Biology Regulators (Progress in Inflammation Research) | Slobodan Vukičević (他: Kuber T. Sampath) | Springer | 457 p. | 2017 | 9783319475059 | 2023/10/02 |
| 5 | 数学 (Mathematics) | Encyclopedia of Data Science and Machine Learning | John Wang | Engineering Science Reference | 803 p. | 2022 | 9781668481653 | 2023/10/02 |
| 6 | 数学 (Mathematics) | A Geometry of Music: Harmony and Counterpoint in the Extended Common Practice (Oxford Studies in Music Theory) | Dmitri Tymoczko | Oxford University Press | 470 p. | 2011 | 9780195336672 | 2023/10/02 |

## 2. 読了 (Read) (89 冊)

| # | 分野 (Field) | タイトル (Title) | 著者 (Author) | 出版社 (Publisher) | ページ数 | 出版年 | ISBN13 | 追加日 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 物理学 (Physics) | Quantum Brain Dynamics and Consciousness (Advances in Consciousness Research) | Mari Jibu (他: Kunio Yasue) | John Benjamins Publishing Company | 258 p. | 1995 | 9789027251237 | 2026/01/19 |
| 2 | 数学 (Mathematics) | Probabilistic Cellular Automata: Theory, Applications and Future Perspectives (Emergence, Complexity and Computation Book 27) | Pierre-Yves Louis (他: Francesca R. Nardi) | Springer | 366 p. | 2018 | 9783319655581 | 2026/01/16 |
| 3 | 化学・物質科学 (Chemistry & Materials) | Lehninger Principles of Biochemistry Lecture Notebook | David L. Nelson (他: Michael M. Cox) | W. H. Freeman | 850 p. | 1970 (2004) | 9780716759546 | 2023/09/23 |
| 4 | 生物学・生命科学 (Biology) | Adult Neurogenesis | Gerd Kempermann | Oxford University Press | 616 p. | 2011 | 9780199729692 | 2024/01/21 |
| 5 | 数学 (Mathematics) | Global Brain Singularity: Universal History, Future Evolution and Humanity’s Dialectical Horizon (World-Systems Evolution and Global Futures) | Cadell Last | Springer | 354 p. | 2020 | 9783030469665 | 2024/01/03 |
| 6 | 計算機科学・情報科学 (Computer Science) | Coding Projects in Python (DK Help Your Kids) | D.K. Publishing | DK Children | 224 p. | 2017 | 9781465461889 | 2023/11/28 |
| 7 | 生物学・生命科学 (Biology) | A Life Decoded: My Genome: My Life | J. Craig Venter | Viking Adult | 400 p. | 2007 | 9780670063581 | 2023/11/07 |
| 8 | 数学 (Mathematics) | Probabilistic Boolean Networks: The Modeling and Control of Gene Regulatory Networks | Ilya Shmulevich (他: Edward R. Dougherty) | Society for Industrial and Applied Mathematics | 184 p. | 2009 (2010) | 9780898716924 | 2023/11/06 |
| 9 | 数学 (Mathematics) | The Humongous Book of Statistics Problems | W. Michael Kelley (他: Robert A. Donnelly Jr.) | Alpha | 550 p. | 2009 | 9781592578658 | 2023/10/08 |
| 10 | 数学 (Mathematics) | The Mathematics of Love: Patterns, Proofs, and the Search for the Ultimate Equation (TED Books) | Hannah Fry | Simon & Schuster / TED | 128 p. | 2015 | 9781476784885 | 2023/10/02 |
| 11 | 生物学・生命科学 (Biology) | Larsen's Human Embryology | Gary C. Schoenwolf (他: Steven B. Bleyl MD  PhD, Philip R. Brauer PhD, Philippa H. Francis-West PhD) | Churchill Livingstone | 712 p. | 2008 | 9780443068119 | 2023/10/02 |
| 12 | 数学 (Mathematics) | Chaos and Fractals: An Elementary Introduction | David P. Feldman | Oxford University Press | 408 p. | 2012 | 9780199566433 | 2023/10/02 |
| 13 | 神経科学・認知科学 (Neuroscience) | A Thousand Brains: A New Theory of Intelligence | Jeff Hawkins (他: Richard Dawkins) | Basic Books | 288 p. | 2021 | 9781541675810 | 2023/10/02 |
| 14 | 数学 (Mathematics) | Chaos: Making a New Science | James Gleick | Penguin Group | 352 p. | 1987 (1988) | 9780140092509 | 2023/10/02 |
| 15 | 生物学・生命科学 (Biology) | Radical Remission: Surviving Cancer Against All Odds | Kelly A. Turner | HarperOne | 336 p. | 2014 | 9780062268778 | 2023/10/02 |
| 16 | 自然科学・複雑系 (Natural Science & Complex Systems) | Principles of Neural Science | Eric R. Kandel (他: James H. Schwartz, Thomas M. Jessell) | McGraw-Hill Medical | 1414 p. | 1981 (2000) | 9780838577011 | 2023/10/02 |
| 17 | 生物学・生命科学 (Biology) | Principles of Neurobiology | Liqun Luo | Garland Science | 696 p. | 2015 | 9780815344926 | 2023/10/02 |
| 18 | 数学 (Mathematics) | Real Time Modeling, Simulation and Control of Dynamical Systems | Asif Mahmood Mughal | Springer | 203 p. | 2016 | 9783319339054 | 2023/09/30 |
| 19 | 数学 (Mathematics) | Essentials of Monte Carlo Simulation: Statistical Methods for Building Simulation Models | Nick T. Thomopoulos | Springer | 192 p. | 2012 | 9781461460213 | 2023/09/30 |
| 20 | 数学 (Mathematics) | Applied Predictive Modeling | Max Kuhn (他: Kjell Johnson) | Springer | 613 p. | 2013 | 9781461468486 | 2023/09/30 |
| 21 | 数学 (Mathematics) | Mathematical and Computational Modeling and Simulation: Fundamentals and Case Studies | Dietmar P.F. Möller | Springer | 437 p. | 2003 | 9783540403890 | 2023/09/30 |
| 22 | 数学 (Mathematics) | Stem Cell Aging: Mechanisms, Consequences, Rejuvenation | Hartmut Geiger (他: Heinrich Jasper, Maria Carolina Florian) | Springer | 365 p. | 2014 (2015) | 9783709112311 | 2023/09/30 |
| 23 | 数学 (Mathematics) | Encyclopedia of Machine Learning and Data Mining | Claude Sammut (他: Geoffrey I. Webb) | Springer | 1352 p. | 2010 (2017) | 9781489976857 | 2023/09/30 |
| 24 | 数学 (Mathematics) | Encyclopedia of Computational Neuroscience | Dieter Jaeger | Springer | 3243 p. | 2014 (2015) | 9781461466741 | 2023/09/30 |
| 25 | 物理学 (Physics) | Quantum Physics in Minutes | Gemma Lavender | Quercus | 416 p. | 2017 | 9781681441740 | 2023/09/29 |
| 26 | 数学 (Mathematics) | Maths in Minutes: 200 Key Concepts Explained in an Instant | Paul Glendinning | Quercus | 416 p. | 2012 | 9781780873695 | 2023/09/29 |
| 27 | 計算機科学・情報科学 (Computer Science) | Understanding the Digital World: What You Need to Know about Computers, the Internet, Privacy, and Security | Brian W. Kernighan | Princeton University Press | 256 p. | 2017 | 9780691176543 | 2023/09/29 |
| 28 | 神経科学・認知科学 (Neuroscience) | The Upward Spiral: Using Neuroscience to Reverse the Course of Depression, One Small Change at a Time | Alex Korb (他: Daniel J. Siegel) | New Harbinger Publications | 240 p. | 2015 | 9781626251205 | 2023/09/29 |
| 29 | 数学 (Mathematics) | Muse Cells: Endogenous Reparative Pluripotent Stem Cells (Advances in Experimental Medicine and Biology, 1103) | Mari Dezawa | Springer | 327 p. | 2018 | 9784431568452 | 2023/09/29 |
| 30 | 計算機科学・情報科学 (Computer Science) | Help Your Kids with Computer Coding: A Unique Step-by-Step Visual Guide, from Binary Code to Building Games | Carol Vorderman | DK | 224 p. | 2014 | 9781465431011 | 2023/09/29 |
| 31 | 計算機科学・情報科学 (Computer Science) | Help Your Kids with Computer Science | D.K. Publishing | DK | 256 p. | 2018 | 9781465473608 | 2023/09/29 |
| 32 | 数学 (Mathematics) | Simulation Algorithms for Computational Systems Biology | L. Marchetti | Springer | 238 p. | 2017 | - | 2023/09/29 |
| 33 | 数学 (Mathematics) | Modeling Biomolecular Networks in Cells: Structures and Dynamics by Luonan Chen (2010-07-15) | Unknown Author | Springer | - | - | - | 2023/09/29 |
| 34 | 神経科学・認知科学 (Neuroscience) | Encyclopedia of Neuroscience (Ten Vol. Set) | Larry R. Squire (他: Aldo Rustichini) | Academic Press | 10 p. | 2009 | 9780080446172 | 2023/09/29 |
| 35 | 数学 (Mathematics) | Encyclopedia of Systems Biology | Werner Dubitzky | Springer | 2414 p. | 2012 (2013) | 9781441998644 | 2023/09/29 |
| 36 | 神経科学・認知科学 (Neuroscience) | The Serotonin Receptors: From Molecular Pharmacology to Human Therapeutics (The Receptors) | Bryan L. Roth | Humana | 636 p. | 2006 | 9781588295682 | 2023/09/29 |
| 37 | 生物学・生命科学 (Biology) | Serotonin Receptors in Neurobiology (Frontiers in Neuroscience) | Amitabha Chattopadhyay | CRC Press | 224 p. | 2007 | 9780849339776 | 2023/09/29 |
| 38 | 数学 (Mathematics) | Serotonin and Anxiety: Neuroanatomical, Pharmacological, and Functional Aspects (SpringerBriefs in Neuroscience) by Caio Maximino (2012-06-07) | Unknown Author | Springer | - | - | - | 2023/09/29 |
| 39 | 物理学 (Physics) | Physical Chemistry | Peter   Atkins (他: Julio de Paula) | W. H. Freeman | 1072 p. | 1978 (2006) | 9780716787594 | 2023/09/29 |
| 40 | 神経科学・認知科学 (Neuroscience) | DMT: The Spirit Molecule | Rick Strassman | Park Street Press | 362 p. | 2000 (2001) | 9780892819270 | 2023/09/29 |
| 41 | 生物学・生命科学 (Biology) | Spice: Understand the Science of Spice, Create Exciting New Blends, and Revolutionize | Bryan  J   Urmetz | - | 452 p. | 2022 | - | 2023/09/29 |
| 42 | 生物学・生命科学 (Biology) | Cellular Senescence: Methods and Protocols (Methods in Molecular Biology, 1896) | Marco DeMaria | Humana | 265 p. | 2018 | 9781493989300 | 2023/09/29 |
| 43 | 神経科学・認知科学 (Neuroscience) | Shadows of the Mind: A Search for the Missing Science of Consciousness | Roger Penrose | Oxford University Press | 480 p. | 1994 (1996) | 9780195106466 | 2023/09/29 |
| 44 | 数学 (Mathematics) | The Oxford Mathematics Study Dictionary | Frank Tapson | Oxford Childrens | 192 p. | 1999 | 9780199145676 | 2023/09/29 |
| 45 | 数学 (Mathematics) | Elementary Differential Equations and Boundary Value Problems | William E. Boyce (他: Richard C. DiPrima) | Wiley | - | 1996 | 9780471089551 | 2023/09/29 |
| 46 | 生物学・生命科学 (Biology) | Enzyme Kinetics for Systems Biology | Herbert M. Sauro | Ambrosius Publishing | 392 p. | 2011 (2012) | 9780982477335 | 2023/09/29 |
| 47 | 数学 (Mathematics) | Differential Equations, Dynamical Systems, and an Introduction to Chaos (Pure and Applied Mathematics) | Morris W. Hirsch (他: Stephen Smale, Robert L. Devaney) | Academic Press | 432 p. | 2003 | 9780123497031 | 2023/09/29 |
| 48 | 数学 (Mathematics) | Nonlinear Oscillations, Dynamical Systems, and Bifurcations of Vector Fields (Applied Mathematical Sciences, 42) | John Guckenheimer (他: Philip Holmes) | Springer | 478 p. | 1983 | 9780387908199 | 2023/09/29 |
| 49 | 数学 (Mathematics) | UNDERSTANDING NONLINEAR DYNAMICS: . (Textbooks in Mathematical Sciences) (Volume 0) | Daniel Kaplan (他: Leon Glass) | Springer-Verlag | 420 p. | 1995 | 9780387944401 | 2023/09/29 |
| 50 | 数学 (Mathematics) | Nonlinear Dynamics and Chaos: With Applications to Physics, Biology, Chemistry, and Engineering | Steven H. Strogatz | CRC Press | 497 p. | 1994 (2000) | 9780738204536 | 2023/09/29 |
| 51 | 数学 (Mathematics) | Student Solutions Manual for Nonlinear Dynamics and Chaos | Mitchal Dichter | Westview Press | 404 p. | 2016 | 9780813350547 | 2023/09/29 |
| 52 | 数学 (Mathematics) | Differential Equations with Linear Algebra | Matthew R. Boelkins (他: Jack L. Goldberg, Merle C. Potter) | Oxford University Press | 576 p. | 2009 | 9780195385861 | 2023/09/29 |
| 53 | 生物学・生命科学 (Biology) | Stem Cells and Aging: Methods and Protocols (Methods in Molecular Biology, 976) | Kursad Turksen | Humana | 190 p. | 2013 | 9781627033169 | 2023/09/29 |
| 54 | 神経科学・認知科学 (Neuroscience) | Guide to Research Techniques in Neuroscience | Matt       Carter | Academic Press | 408 p. | 2009 | 9780123748492 | 2023/09/29 |
| 55 | 数学 (Mathematics) | Stochastic Processes in Cell Biology (Interdisciplinary Applied Mathematics, 41) | Paul C. Bressloff | Springer Nature | 679 p. | 2014 | 9783319084879 | 2023/09/29 |
| 56 | 数学 (Mathematics) | Systems Biology of Tumor Microenvironment: Quantitative Modeling and Simulations (Advances in Experimental Medicine and Biology, 936) | Katarzyna A. Rejniak | Springer | 266 p. | 2016 | 9783319420219 | 2023/09/29 |
| 57 | 計算機科学・情報科学 (Computer Science) | Make Your Own Neural Network | Tariq Rashid | - | 224 p. | 2016 | - | 2023/09/29 |
| 58 | 物理学 (Physics) | Your Brain Is a Time Machine: The Neuroscience and Physics of Time | Dean Buonomano | W. W. Norton & Company | 304 p. | 2017 (2018) | 9780393355604 | 2023/09/29 |
| 59 | 生物学・生命科学 (Biology) | Principles of Regenerative Medicine | Anthony Atala (他: Robert Lanza, Robert Nerem, James A. Thomson) | Academic Press | 1472 p. | 2002 (2007) | 9780123694102 | 2023/09/29 |
| 60 | 計算機科学・情報科学 (Computer Science) | Introduction to Machine Learning with Python: A Guide for Data Scientists | Andreas C. Müller (他: Sarah Guido) | O'Reilly Media | 400 p. | 2015 (2016) | 9781449369415 | 2023/09/29 |
| 61 | 生物学・生命科学 (Biology) | Foundations of Chemical Biology (Oxford Chemistry Primers) | C.M. Dobson (他: J. A. Gerrard, A. J. Pratt) | Oxford University Press | 96 p. | 2002 | 9780199248995 | 2023/09/29 |
| 62 | 計算機科学・情報科学 (Computer Science) | Python Programming for Biology | Tim J. Stevens (他: Wayne Boucher) | Cambridge University Press | 722 p. | 2014 (2015) | 9780521720090 | 2023/09/29 |
| 63 | 生物学・生命科学 (Biology) | The Biology of Cancer | Robert A. Weinberg | Garland Science | 850 p. | 2006 | 9780815340782 | 2023/09/29 |
| 64 | 生物学・生命科学 (Biology) | Molecular Biology of the Cell | Bruce Alberts (他: Alexander Johnson, Julian Lewis, Martin Raff, Keith      Roberts, Peter Walter) | Garland Science | 1616 p. | 1983 (2002) | 9780815332183 | 2023/09/29 |
| 65 | 生物学・生命科学 (Biology) | Molecular Biology of the Cell-Overhead Transparencies | Bruce Alberts (他: Alexander Johnson, Julian Lewis, Martin Raff, Keith      Roberts, Peter Walter) | Garland Science | - | 2002 (2008) | 9780815341093 | 2023/09/29 |
| 66 | 生物学・生命科学 (Biology) | The Mitochondrial Free Radical Theory of Aging (Molecular Biology Intelligence Unit) | Aubrey de Grey | R G Landes Co | 212 p. | 1999 | 9781570595646 | 2023/09/28 |
| 67 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Science Book: Big Ideas Simply Explained | Rob Scott Colson (他: John Farndon, Camilla Hallinan, Dan Green, David John, Adam Hart-Davis) | DK Publishing | 352 p. | 2014 | 9781465419651 | 2023/09/28 |
| 68 | 計算機科学・情報科学 (Computer Science) | Wetware: A Computer in Every Living Cell | Dennis Bray | Yale University Press | 280 p. | 2009 | 9780300141733 | 2023/09/27 |
| 69 | 数学 (Mathematics) | Kinetic Modelling in Systems Biology (Chapman & Hall/CRC Mathematical and Computational Biology) | Oleg Demin (他: Igor I. Goryanin) | Chapman and Hall/CRC | 356 p. | 2008 | 9781584886679 | 2023/09/27 |
| 70 | 生物学・生命科学 (Biology) | Fundamentals of Systems Biology: From Synthetic Circuits to Whole-cell Models | Markus W. Covert | CRC Press | 367 p. | 2014 (2015) | - | 2023/09/27 |
| 71 | 数学 (Mathematics) | Life: An Introduction to Complex Systems Biology (Understanding Complex Systems) | Kunihiko Kaneko | Springer | 388 p. | 2006 | 9783540326663 | 2023/09/27 |
| 72 | 生物学・生命科学 (Biology) | Systems Biology | Edda Klipp (他: Wolfram Liebermeister, Christoph Wierling, Axel Kowald, Hans Lehrach, Ralf Herwig) | Wiley-Blackwell | 592 p. | 2009 | 9783527318742 | 2023/09/27 |
| 73 | 数学 (Mathematics) | An Introduction to Systems Biology: Design Principles of Biological Circuits (Chapman & Hall/CRC Mathematical and Computational Biology) | Uri Alon | Chapman and Hall/CRC | 320 p. | 2006 | 9781584886426 | 2023/09/27 |
| 74 | 神経科学・認知科学 (Neuroscience) | Clinical Neuroanatomy and Neuroscience: With Student Consult Access | M.J. Turlough Fitzgerald (他: Gregory Gruener, Estomih Mtui) | Saunders | 432 p. | 2009 (2011) | 9780702037382 | 2023/09/23 |
| 75 | 神経科学・認知科学 (Neuroscience) | Neuroanatomy and Neuroscience at a Glance | Roger A. Barker (他: Francesca Cicchetti) | Wiley-Blackwell | 160 p. | 2012 | 9780470657683 | 2023/09/23 |
| 76 | 神経科学・認知科学 (Neuroscience) | Brain Bugs: How the Brain's Flaws Shape Our Lives | Dean Buonomano | W. W. Norton & Company | 310 p. | 2011 | 9780393076028 | 2023/09/23 |
| 77 | 神経科学・認知科学 (Neuroscience) | The Human Nervous System: Structure and Function (HUMAN NERVOUS SYSTEM (NOBACK)) (2005-03-01) | Unknown . | Humana Press | - | 1768 | - | 2023/09/23 |
| 78 | 生物学・生命科学 (Biology) | Handbook of Stress and the Brain Part 1: The Neurobiology of Stress: The Neurobiology of Stress | T. Steckler (他: N.H. Kalin, J.M.H.M. Reul) | Elsevier Science & Technology | 856 p. | 2005 | 9780080553245 | 2023/09/23 |
| 79 | 神経科学・認知科学 (Neuroscience) | Living without an Amygdala | David G. Amaral (他: Ralph Adolphs) | The Guilford Press | 430 p. | 2016 | 9781462525942 | 2023/09/23 |
| 80 | 神経科学・認知科学 (Neuroscience) | The Cognitive Neurosciences III | Michael S. Gazzaniga | Bradford Books | 1385 p. | 2004 | 9780262072540 | 2023/09/23 |
| 81 | 神経科学・認知科学 (Neuroscience) | Cerebral Cortex: Principles of Operation | Edmund T Rolls | Oxford University Press | 1008 p. | 2016 | 9780198784852 | 2023/09/23 |
| 82 | 生物学・生命科学 (Biology) | Barr's The Human Nervous System: An Anatomical Viewpoint by John A. Kiernan (2013-05-01) | Unknown Author | Lippincott Williams and Wilkins | - | - | - | 2023/09/23 |
| 83 | 神経科学・認知科学 (Neuroscience) | Atlas of Functional Neuroanatomy | Walter J. Hendelman | CRC Press | 296 p. | 2000 (2005) | 9780849330841 | 2023/09/23 |
| 84 | 神経科学・認知科学 (Neuroscience) | How Emotions Are Made: The Secret Life of the Brain | Lisa Feldman Barrett | Houghton Mifflin Harcourt | 425 p. | 2017 | 9780544133310 | 2023/09/23 |
| 85 | 化学・物質科学 (Chemistry & Materials) | Biochemistry | Jeremy M. Berg (他: John L. Tymoczko, Lubert L. Stryer) | W. H. Freeman | 1026 p. | 1975 (2006) | 9780716787242 | 2023/09/23 |
| 86 | 数学 (Mathematics) | Hands-On Machine Learning with Scikit-Learn and TensorFlow | Aurélien Géron | O'Reilly Media | 450 p. | 2017 | - | 2023/09/23 |
| 87 | 計算機科学・情報科学 (Computer Science) | Deep Learning with Python | François Chollet | Manning | 350 p. | 2017 | 9781617294433 | 2023/09/23 |
| 88 | 計算機科学・情報科学 (Computer Science) | Deep Learning | Ian Goodfellow (他: Yoshua Bengio, Aaron Courville) | The MIT Press | 787 p. | 2016 | - | 2023/09/23 |
| 89 | 生物学・生命科学 (Biology) | Adult Neurogenesis: Stem Cells and Neuronal Development in the Adult Brain | Gerd Kempermann | Oxford University Press | 448 p. | 2005 | 9780195179712 | 2023/09/23 |

## 3. 中断 (Did Not Finish) (0 冊)

| # | 分野 (Field) | タイトル (Title) | 著者 (Author) | 出版社 (Publisher) | ページ数 | 出版年 | ISBN13 | 追加日 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

## 4. 読みたい本 (To Read) (774 冊)

| # | 分野 (Field) | タイトル (Title) | 著者 (Author) | 出版社 (Publisher) | ページ数 | 出版年 | ISBN13 | 追加日 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 物理学 (Physics) | The Principles of Quantum Mechanics | P.A.M. Dirac | BNP | 332 p. | 1958 (2019) | - | 2026/04/24 |
| 2 | 物理学 (Physics) | Photovoltaic Materials and Electronic Devices | Joshua M. Pearce | Mdpi AG | 212 p. | 2016 | 9783038422167 | 2026/09/19 |
| 3 | 数学 (Mathematics) | Handbook of Perovskite Solar Cells, Volume 2: Functional Layer Optimization and Diverse Device Types for Efficiency and Stability (Advances in Materials Science and Engineering) | Jiangzhao Chen (他: Sam Zhang) | CRC Press | 452 p. | 2024 | 9781032509693 | 2026/09/19 |
| 4 | 物理学 (Physics) | Next-Generation Solar Cells: Principles and Materials (Second Edition) | Yoon-Bong Hahn (他: Yousheng Wang, Tahmineh Mahmoudi) | Jenny Stanford Publishing | 402 p. | 2026 | 9789815352177 | 2026/09/19 |
| 5 | 数学 (Mathematics) | High Concentrator Photovoltaics: Fundamentals, Engineering and Power Plants (Green Energy and Technology) | Pedro Perez-Higueras (他: Eduardo F. Fernandez) | Springer | 820 p. | 2015 | - | 2026/09/19 |
| 6 | 数学 (Mathematics) | Computational Methods Based on Peridynamics and Nonlocal Operators: Theory and Applications (Computational Methods in Engineering & the Sciences) | Timon Rabczuk (他: Huilong Ren, Xiaoying Zhuang) | Springer | 333 p. | 2023 | 9783031209055 | 2026/09/18 |
| 7 | 物理学 (Physics) | Meshfree and Particle Methods: Fundamentals and Applications | Ted Belytschko (他: Jason S. Chen, Michael Hillman) | Wiley | 352 p. | 2024 | 9780470848005 | 2026/09/18 |
| 8 | 物理学 (Physics) | Superspace: One Thousand and One Lessons in Supersymmetry (Frontiers in Physics) | S. James Gates | Orange Grove Texts Plus | 568 p. | 1983 (2009) | 9781616100711 | 2026/09/15 |
| 9 | 物理学 (Physics) | Supersymmetry DeMystiFied | Patrick LaBelle | McGraw-Hill Professional | 481 p. | 2009 (2010) | 9780071636414 | 2026/09/15 |
| 10 | 数学 (Mathematics) | Supersymmetry and its Applications: Superstrings, Anomalies and Supergravity | Stephen W. Hawking (他: G. W. Gibbons, P. K. Townsend) | Cambridge University Press | 495 p. | 1986 | 9780521307215 | 2026/09/15 |
| 11 | 物理学 (Physics) | Supersymmetry and Beyond: From the Higgs Boson to the New Physics | Gordon L. Kane | Basic Books | 197 p. | 2013 | 9780465082971 | 2026/09/15 |
| 12 | 物理学 (Physics) | The Quantum Theory of Fields: Volume 3, Supersymmetry | Steven Weinberg | Cambridge University Press | 445 p. | 1995 (2005) | 9781139639651 | 2026/09/15 |
| 13 | 物理学 (Physics) | Supersymmetry and Supergravity | Julius Wess (他: Jonathan Bagger) | Princeton University Press | 260 p. | 1983 (1992) | 9780691025308 | 2026/09/15 |
| 14 | 物理学 (Physics) | Supersymmetry in Particle Physics: An Elementary Introduction | Ian J.R. Aitchison | Cambridge University Press | 238 p. | 2007 | 9780521880237 | 2026/09/15 |
| 15 | 数学 (Mathematics) | String Theory For Dummies | Andrew Zimmerman Jones (他: Daniel Robbins) | For Dummies | 384 p. | 2009 | 9780470467244 | 2026/09/12 |
| 16 | 数学 (Mathematics) | Geometries (UNITEXT Book 178) | Ioannis D. Platis | Springer | 357 p. | 2026 | - | 2026/09/12 |
| 17 | 数学 (Mathematics) | Special Metrics and Group Actions in Geometry (Springer INdAM Series, 23) | Simon G Chiossi (他: Anna Fino, Emilio Musso, Fabio Podestà, Luigi Vezzoni) | Springer | 348 p. | 2017 | 9783319675183 | 2026/09/12 |
| 18 | 数学 (Mathematics) | Transformation Groups in Differential Geometry (Classics in Mathematics) | Shoshichi Kobayashi | Springer | 190 p. | 1972 (1995) | 9783540586593 | 2026/09/12 |
| 19 | 数学 (Mathematics) | The Geometry and Topology of Three-Manifolds | William P. Thurston | American Mathematical Society | 316 p. | 2022 | - | 2026/09/12 |
| 20 | 数学 (Mathematics) | The Shape of Space: How to Visualize Surfaces and Three-Dimensional Manifolds | Jeffrey R. Weeks | CRC Press | 408 p. | 1985 (2001) | 9780824707095 | 2026/09/12 |
| 21 | 数学 (Mathematics) | The Shape of Space (Textbooks in Mathematics) | Jeffrey R. Weeks | Chapman and Hall/CRC | 362 p. | 2019 | - | 2026/09/12 |
| 22 | 数学 (Mathematics) | Visualizing Mathematics with 3D Printing | Henry Segerman | Johns Hopkins University Press | 200 p. | 2016 | 9781421420356 | 2026/09/12 |
| 23 | 数学 (Mathematics) | String Theory Demystified 1st edition by McMahon, David (2008) Paperback | Unknown Author | McGraw-Hill Education | - | - | - | 2026/09/12 |
| 24 | 数学 (Mathematics) | Orbifolds and Stringy Topology (Cambridge Tracts in Mathematics, Series Number 171) | Alejandro Adem (他: Johann Leida, Yongbin Ruan) | Cambridge University Press | 164 p. | 2007 | 9780521870047 | 2026/09/12 |
| 25 | 物理学 (Physics) | Quantum Field Theory Demystified | David McMahon | McGraw Hill | 320 p. | 2008 | 9780071543828 | 2026/09/11 |
| 26 | 数学 (Mathematics) | The Princeton Companion to Applied Mathematics | Nicholas J.  Higham (他: Mark R. Dennis, Paul Glendinning, Paul A. Martin, Fadil Santosa, Jared Tanner) | Princeton University Press | 1032 p. | 2015 | 9780691150390 | 2026/09/11 |
| 27 | 数学 (Mathematics) | The Princeton Companion to Mathematics | Timothy Gowers (他: June Barrow-Green, Imre Leader) | Princeton University Press | 1056 p. | 2007 (2008) | 9780691118802 | 2026/09/11 |
| 28 | 物理学 (Physics) | Quantum Field Theory for the Gifted Amateur | Tom Lancaster (他: Stephen J. Blundell) | Oxford University Press | 504 p. | 2014 | 9780199699322 | 2026/09/08 |
| 29 | 数学 (Mathematics) | Quantum Fields and Strings: A Course for Mathematicians (Volume 2) | Pierre Deligne (他: Pavel Etingof, Daniel S. Freed, Lisa C. Jeffrey, David Kazhdan, John W. Morgan, David R. Morrison, Edward Witten) | American Mathematical Society | - | 1999 | 9780821820131 | 2026/09/06 |
| 30 | 数学 (Mathematics) | Mathematics For Physics: An Illustrated Handbook (Computational Mathematical and) | Adam Marsh | World Scientific Publishing Company | 367 p. | 2017 | 9789813233935 | 2026/09/04 |
| 31 | 数学 (Mathematics) | Mathematical Gauge Theory: With Applications to the Standard Model of Particle Physics | Mark J.D. Hamilton | Springer | 658 p. | 2018 | 9783319684383 | 2026/09/04 |
| 32 | 数学 (Mathematics) | The Art of Gathering: How We Meet and Why It Matters | Priya Parker | Riverhead Books | 304 p. | 2018 | 9781594634925 | 2026/08/22 |
| 33 | 数学 (Mathematics) | Gauge Field Theories (Cambridge Monographs on Mathematical Physics) | Stefan Pokorski | Cambridge University Press | 632 p. | 1987 (2000) | 9780537478169 | 2026/08/14 |
| 34 | 物理学 (Physics) | Introduction to Quantum Field Theory: Classical Mechanics to Gauge Field Theories | Anthony G.  Williams | Cambridge University Press | 792 p. | 2022 | 9781108470902 | 2026/08/14 |
| 35 | 物理学 (Physics) | QUARKS, LEPTONS AND GAUGE FIELDS (2ND EDITION) | Huang Kerson | World Scientific Publishing Company | - | 1992 | 9789810206598 | 2026/08/14 |
| 36 | 数学 (Mathematics) | Topology, Geometry and Gauge fields: Foundations (Texts in Applied Mathematics) | Gregory L. Naber | Springer | - | 1997 | 9780387949468 | 2026/08/14 |
| 37 | 数学 (Mathematics) | Gauge Fields, Knots & Gravity (V4) (Knots and Everything) | Baez J | World Scientific Publishing Company | 480 p. | 1994 | 9789810220341 | 2026/08/14 |
| 38 | 自然科学・複雑系 (Natural Science & Complex Systems) | Enriching the Earth: Fritz Haber, Carl Bosch, and the Transformation of World Food Production (Mit Press) | Vaclav Smil | MIT Press | 338 p. | 2000 (2004) | 9780262693134 | 2026/08/14 |
| 39 | 数学 (Mathematics) | Inference and Asymptotics (Chapman & Hall/CRC Monographs on Statistics and Applied Probability) | Ole E. Barndorff-Nielsen (他: D.R. Cox) | Chapman and Hall/CRC | 372 p. | 1994 | 9780412494406 | 2026/08/08 |
| 40 | 計算機科学・情報科学 (Computer Science) | Mining the Social Web: Data Mining Facebook, Twitter, LinkedIn, Instagram, GitHub, and More | Matthew A. Russell (他: Mikhail Klassen) | O'Reilly Media | 711 p. | 2011 (2018) | 9781491973516 | 2026/08/01 |
| 41 | 数学 (Mathematics) | Informatics for Materials Science and Engineering: Data-driven Discovery for Accelerated Experimentation and Application | Krishna Rajan | Butterworth-Heinemann | 542 p. | 2013 | 9780123943996 | 2026/08/01 |
| 42 | 数学 (Mathematics) | Materials Informatics I: Methods (Challenges and Advances in Computational Chemistry and Physics Book 39) | Kunal Roy (他: Arkaprava Banerjee) | Springer | 561 p. | 2025 | 9783031787362 | 2026/08/01 |
| 43 | 数学 (Mathematics) | An Introduction to Materials Informatics: Advanced Machine Learning | Tongyi Zhang | Springer | 927 p. | 2026 | 9789819560905 | 2026/08/01 |
| 44 | 化学・物質科学 (Chemistry & Materials) | Materials Informatics: Methods, Tools, and Applications | Olexandr Isayev (他: Alexander Tropsha, Stefano Curtarolo) | Wiley-VCH | 299 p. | 2019 | - | 2026/08/01 |
| 45 | 数学 (Mathematics) | STRUCTURAL ASPECTS IN THE THEORY OF PROBABILITY: A PRIMER IN PROBABILITIES ON ALGEBRAIC - TOPOLOGICAL STRUCTURES (SERIES ON MULTIVARIATE ANALYSIS, V. 7) | Herbert Heyer | World Scientific Pub Co Inc | 400 p. | 2004 | 9789812389374 | 2026/07/30 |
| 46 | 数学 (Mathematics) | Probability Measures on Groups X | H. Heyer | Springer | 507 p. | 2013 | 9781489923660 | 2026/07/25 |
| 47 | 数学 (Mathematics) | Probabilities on the Heisenberg Group: Limit Theorems and Brownian Motion (Lecture Notes in Mathematics) by Daniel Neuenschwander (1996-08-19) | Unknown Author | Springer | - | - | - | 2026/07/25 |
| 48 | 数学 (Mathematics) | Probability on Compact Lie Groups (Probability Theory and Stochastic Modelling) | David Applebaum | Springer International Publishing AG | 217 p. | 2014 | 9783319078410 | 2026/07/25 |
| 49 | 数学 (Mathematics) | Probabilistic Group Theory, Combinatorics, and Computing: Lectures from the Fifth de Brún Workshop (Lecture Notes in Mathematics, 2070) | Alla Detinko (他: Dane Flannery, Eamonn  O'Brien) | Springer | 120 p. | 2012 (2013) | 9781447148135 | 2026/07/25 |
| 50 | 数学 (Mathematics) | Arakelov Geometry and Diophantine Applications (Lecture Notes in Mathematics, 2276) | Emmanuel Peyre (他: Gaël Rémond) | Springer | 479 p. | 2021 | 9783030575588 | 2026/07/24 |
| 51 | 数学 (Mathematics) | Survey on Diophantine Geometry | Serge Lang | Springer | 309 p. | 2008 (1997) | 9783642582271 | 2026/07/24 |
| 52 | 数学 (Mathematics) | Fundamentals of Diophantine Geometry | Serge Lang | Springer | 388 p. | 1983 | 9780387908373 | 2026/07/24 |
| 53 | 数学 (Mathematics) | Diophantine Geometry: An Introduction (Graduate Texts in Mathematics, 201) (Volume 0) | Marc Hindry (他: Joseph H. Silverman) | Springer | 574 p. | 2000 | 9780387989815 | 2026/07/24 |
| 54 | 数学 (Mathematics) | Differential algebra and diophantine geometry | Alexandru Buium | HERMANN | 192 p. | 1997 | 9782705662264 | 2026/07/24 |
| 55 | 数学 (Mathematics) | Stochastic Porous Media Equations (Lecture Notes in Mathematics, 2163) | Viorel Barbu (他: Giuseppe Da Prato, Michael Röckner) | Springer | 211 p. | 2016 | 9783319410685 | 2026/07/11 |
| 56 | 数学 (Mathematics) | Hypercomplex Numbers: An Elementary Introduction to Algebras | I.L.;Solodovnikov A. S. Kantor | Springer | 169 p. | 1989 | 9780387969800 | 2026/07/08 |
| 57 | 数学 (Mathematics) | Arakelov Geometry over Adelic Curves (Lecture Notes in Mathematics, 2258) | Huayi Chen (他: Atsushi Moriwaki) | Springer | 470 p. | 2020 | 9789811517273 | 2026/07/07 |
| 58 | 数学 (Mathematics) | Lectures on Arakelov Geometry (Cambridge Studies in Advanced Mathematics, Series Number 33) (Volume 0) | C. Soulé | Cambridge University Press | 188 p. | 1992 (2008) | 9780521477093 | 2026/07/06 |
| 59 | 数学 (Mathematics) | An Introduction to Invariants and Moduli (Cambridge Studies in Advanced Mathematics, Series Number 81) | Shigeru Mukai (他: W. M. Oxbury) | Cambridge University Press | 524 p. | 2012 | 9781107406360 | 2026/07/06 |
| 60 | 数学 (Mathematics) | Commutative Rings with Zero Divisors | James Huckaba | Marcel Dekker | 216 p. | 1988 | 9780824778446 | 2026/07/04 |
| 61 | 数学 (Mathematics) | Nilpotent Orbits, Primitive Ideals, and Characteristic Classes: A Geometric Perspective in Ring Theory (Progress in Mathematics Book 78) | Walter Borho (他: J.-L. Brylinski, R. MacPherson) | Birkhäuser | - | 2012 | - | 2026/07/04 |
| 62 | 数学 (Mathematics) | Group Theory in Quantum Mechanics: An Introduction to Its Present Usage | Volker Heine | Dover Publications | 480 p. | 2012 (2007) | 9780486458786 | 2026/07/03 |
| 63 | 数学 (Mathematics) | Group Theory and Quantum Mechanics (Dover Books on Chemistry) | Michael Tinkham | Dover Publications | 340 p. | 1964 (2003) | 9780486432472 | 2026/07/03 |
| 64 | 数学 (Mathematics) | The Theory of Groups and Quantum Mechanics (Dover Books on Mathematics) | Hermann Weyl | Dover Publications | 464 p. | 1931 (1950) | 9780486602691 | 2026/07/03 |
| 65 | 数学 (Mathematics) | United Universes: Quaternion Universe - Octonion Megaverse | Stephen Blaha | Pingree-Hill Publishing | 126 p. | 2020 | 9781734583403 | 2026/07/02 |
| 66 | 数学 (Mathematics) | From Octonion Cosmology to the Unified SuperStandard Theory of Particles | Stephen Blaha | Pingree-Hill Publishing | 242 p. | 2020 | 9781735679549 | 2026/07/02 |
| 67 | 数学 (Mathematics) | GEOMETRY OF THE OCTONIONS, THE | DRAY TEVIAN (他: Corinne A Manogue) | World Scientific Publishing Company | 228 p. | 2013 (2015) | 9789814401814 | 2026/07/02 |
| 68 | 数学 (Mathematics) | Quaternions: Theory and Applications (Mathematics Research Developments) | Sandra Griffin | Nova Science Pub Inc | 282 p. | 2017 | 9781536107685 | 2026/06/30 |
| 69 | 数学 (Mathematics) | Elements of quaternions Volume 1 | William Rowan Hamilton | Nabu Press | 628 p. | 1969 (2010) | 9781177632317 | 2026/06/30 |
| 70 | 数学 (Mathematics) | Quaternions and Rotation Sequences: A Primer with Applications to Orbits, Aerospace, and Virtual Reality | Jack B. Kuipers | Princeton University Press | 371 p. | 1998 | 9780691058726 | 2026/06/30 |
| 71 | 数学 (Mathematics) | Visualizing Quaternions (The Morgan Kaufmann Series in Interactive 3D Technology) | Andrew J. Hanson | Morgan Kaufmann | 536 p. | 2005 (2006) | 9780120884001 | 2026/06/30 |
| 72 | 数学 (Mathematics) | On Quaternions and Octonions | John H. Conway (他: Derek Smith) | A K Peters/CRC Press | 159 p. | 2003 | 9781568811345 | 2026/06/30 |
| 73 | 物理学 (Physics) | Electroweak Symmetry Breaking and New Physics at the Tev Scale (Advanced Series on Directions in High Energy Physics) (1997-05-04) | Unknown Author | World Scientific Pub Co Inc | - | - | - | 2026/06/27 |
| 74 | 化学・物質科学 (Chemistry & Materials) | Making And Breaking Symmetry In Chemistry: Syntheses, Mechanisms And Molecular Rearrangements | McGlinchey Michael J | WSPC | 292 p. | 2022 | 9789811249655 | 2026/06/27 |
| 75 | 化学・物質科学 (Chemistry & Materials) | Making And Breaking Symmetry In Chemistry: Syntheses, Mechanisms And Molecular Rearrangements | Michael James Mcglinchey | World Scientific | 292 p. | 2022 | 9789811249679 | 2026/06/27 |
| 76 | 物理学 (Physics) | Higgs Force: The Symmetry-Breaking Force that Makes the World an Interesting Place by Mee, Nicholas (2012) Hardcover | Unknown Author | Lutterworth Press | - | - | - | 2026/06/27 |
| 77 | 数学 (Mathematics) | Electroweak Symmetry Breaking: By Dynamically Generated Masses of Quarks and Leptons (Springer Theses) | Mgr.Adam Smetana | Springer | 190 p. | 2014 | 9783319070728 | 2026/06/27 |
| 78 | 数学 (Mathematics) | Historical Roots of Spontaneous Symmetry Breaking: Steps Towards an Analogy (SpringerBriefs in History of Science and Technology) | Rocco Gaudenzi | Springer | 141 p. | 2022 | 9783030998943 | 2026/06/27 |
| 79 | 数学 (Mathematics) | Symmetry Breaking (Lecture Notes in Physics) | Franco Strocchi | Springer | 228 p. | 2005 (2010) | 9783642092732 | 2026/06/27 |
| 80 | 物理学 (Physics) | Chemical Symmetry Breaking | Rui Tamura | Mdpi AG | 256 p. | 2021 | 9783036511306 | 2026/06/27 |
| 81 | 物理学 (Physics) | Magnetic Atoms and Molecules (Dover Books on Physics and Chemistry) | William Weltner | Dover Publications | 436 p. | 1989 | 9780486661407 | 2026/06/27 |
| 82 | 数学 (Mathematics) | Course of Theoretical Physics: Vol. 5, Statistical Physics, Part 1 | L.D. Landau (他: E.M. Lifshitz) | Butterworth-Heinemann | 564 p. | 1980 | 9780750633727 | 2026/06/27 |
| 83 | 物理学 (Physics) | Symmetry Principles in Solid State and Molecular Physics (Dover Books on Physics) | Melvin J. Lax | Dover Publications | 512 p. | 1974 (2012) | 9780486420011 | 2026/06/27 |
| 84 | 数学 (Mathematics) | Symmetry and Structure: Readable Group Theory for Chemists | Sidney F. A. Kettle | Wiley | 440 p. | 1985 (2007) | 9780470060407 | 2026/06/27 |
| 85 | 数学 (Mathematics) | Group Theory: Application to the Physics of Condensed Matter | Mildred S. Dresselhaus (他: Gene Dresselhaus, Ado Jorio) | Springer | 596 p. | 2008 (2010) | 9783642069451 | 2026/06/27 |
| 86 | 物理学 (Physics) | Space Groups for Solid State Scientists | A.M. Glazer | Academic Press | 360 p. | 1990 | 9780121457617 | 2026/06/27 |
| 87 | 生物学・生命科学 (Biology) | The Book of Alternative Data: A Guide for Investors, Traders and Risk Managers | Alexander Denev (他: Saeed Amen) | Wiley | 416 p. | 2020 | 9781119601791 | 2026/06/27 |
| 88 | 生物学・生命科学 (Biology) | Handbook of Alternative Data in Finance, Volume I (CRC Press/OptiRisk Series in Finance) | Gautam Mitra (他: Christina Erlwein-Sayer, Kieu Thi Hoang, Diana Román, Zryan Sadik) | Chapman and Hall/CRC | 576 p. | 2023 | 9781032276489 | 2026/06/26 |
| 89 | 数学 (Mathematics) | Sophus Lie and Felix Klein: The Erlangen Program and Its Impact in Mathematics and Physics (IRMA Lectures in Mathematics and Theoretical Physics) | Lizhen Ji (他: Athanase Papadopoulos) | European Mathematical Society | 348 p. | 2015 | 9783037191484 | 2026/06/25 |
| 90 | 数学 (Mathematics) | Topological Methods in Hydrodynamics (Applied Mathematical Sciences, 125) | Vladimir I. Arnold (他: Boris A. Khesin) | Springer | 475 p. | 2022 | 9783030742805 | 2026/06/18 |
| 91 | 数学 (Mathematics) | Lectures on Topological Fluid Mechanics: Lectures given at the C.I.M.E. Summer School held in Cetraro, Italy, July 2 - 10, 2001 (Lecture Notes in Mathematics Book 1973) | Mitchell A. Berger (他: Renzo L. Ricca, Louis H. Kauffman, Boris Khesin, H. Keith Moffatt, De Witt Sumners) | Springer | - | 2009 | - | 2026/06/18 |
| 92 | 数学 (Mathematics) | Topological Fluid Mechanics: Proceedings of the IUTAM Symposium, Cambridge, UK, 13–18 August, 1989 | H.K. Moffatt | Cambridge University Press | 823 p. | 1990 | 9780521381451 | 2026/06/18 |
| 93 | 数学 (Mathematics) | Topological Methods in Hydrodynamics (Applied Mathematical Sciences, 125) | Vladimir I. Arnold | Springer | 391 p. | 1998 | 9780387949475 | 2026/06/18 |
| 94 | 物理学 (Physics) | Quantum Gravity (International Series of Monographs on Physics, Vol. 136) | Claus Kiefer | Oxford University Press | 376 p. | 2004 (2007) | 9780199212521 | 2026/06/11 |
| 95 | 物理学 (Physics) | Quantum Cosmology: An Introduction | Jean-Luc Lehners | Cambridge University Press | 395 p. | 2026 | 9781009516808 | 2026/06/11 |
| 96 | 数学 (Mathematics) | Topology Illustrated | Peter Saveliev | Peter Saveliev | 657 p. | 2016 | 9781495188756 | 2026/06/06 |
| 97 | 生物学・生命科学 (Biology) | Generalized Functions: Representation Theory and Automorphic Functions (6) | Israel M. Gelfand | Chelsea Pub Co | 426 p. | 1990 (2016) | 9781470426644 | 2026/06/06 |
| 98 | 生物学・生命科学 (Biology) | Spaces of Fundamental and Generalized Functions (Generalized Functions, Volume 2) | Israel M. Gelfand (他: G.E. Shilov, Morris D. Friedman, Amiel Feinstein, Christian P. Peltzer) | Academic Press | 261 p. | 1968 | 9780122795022 | 2026/06/06 |
| 99 | 数学 (Mathematics) | A course of differential geometry and topology | Mishchenko and Fomenko | Mir Publishers | 455 p. | 1988 | 9785030002200 | 2026/06/06 |
| 100 | 数学 (Mathematics) | Visual Geometry and Topology | Anatolij T. Fomenko A. T. Fomenko | Springer | 324 p. | 1993 (1994) | 9783540533610 | 2026/06/06 |
| 101 | 数学 (Mathematics) | Geometry, Topology and Physics | M. Nakahara | CRC Press | 596 p. | 1999 (2003) | 9780750306065 | 2026/05/30 |
| 102 | 数学 (Mathematics) | Topology from the Differentiable Viewpoint | John Milnor | Princeton University Press | 80 p. | 1997 | 9780691048338 | 2026/05/30 |
| 103 | 数学 (Mathematics) | Algebraic Topology | Allen Hatcher | Cambridge University Press | 556 p. | 2001 | 9780521795401 | 2026/05/30 |
| 104 | 数学 (Mathematics) | Toric Topology and Polyhedral Products (Fields Institute Communications, 89) | Anthony Bahri (他: Lisa Jeffrey, Taras Panov, Donald Stanley, Stephen Theriault) | Springer | 334 p. | 2024 | 9783031572036 | 2026/05/30 |
| 105 | 数学 (Mathematics) | Toric Topology | Victor Buchstaber (他: Taras Panov) | American Mathematical Society | 518 p. | 2015 | 9781470422141 | 2026/05/30 |
| 106 | 数学 (Mathematics) | Acupuncture Techniques: A Practical Manual | Tianjun Wang (他: Weixiang Wang) | Springer | 532 p. | 2024 | 9783031592720 | 2026/05/26 |
| 107 | 数学 (Mathematics) | Complex Analysis | Elias M Stein Rami Shakarchi (他: Rami Shakarchi) | Princeton University Press | 400 p. | 2003 | 9780691113852 | 2026/05/24 |
| 108 | 数学 (Mathematics) | Visual Complex Analysis | Tristan Needham | Clarendon Press | 616 p. | 1997 (1999) | 9780198534464 | 2026/05/24 |
| 109 | 数学 (Mathematics) | Infinite Dimensional Analysis: A Hitchhiker's Guide | Charalambos D. Aliprantis (他: Kim C. Border) | Springer | 726 p. | 1994 (2007) | 9783540326960 | 2026/05/23 |
| 110 | 数学 (Mathematics) | Stochastics in Finite and Infinite Dimensions: In Honor of Gopinath Kallianpur (Trends in Mathematics) | Takeyuki Hida (他: Rajeeva L. Karandikar, Hiroshi Kunita, Balram S. Rajput, Shinzo Watanabe, Jie Xiong) | Birkhäuser | 447 p. | 2000 | 9780817641375 | 2026/05/23 |
| 111 | 数学 (Mathematics) | White Noise: An Infinite Dimensional Calculus (Mathematics and Its Applications, 253) | Takeyuki Hida (他: Hui-Hsiung Kuo, Jürgen Potthoff, L. Streit) | Springer | 534 p. | 1993 (2010) | 9789048142606 | 2026/05/23 |
| 112 | 数学 (Mathematics) | White Noise: An Infinite Dimensional Calculus (Mathematics and Its Applications) by Takeyuki Hida (2010-12-06) | Unknown Author | Springer | - | - | - | 2026/05/23 |
| 113 | 自然科学・複雑系 (Natural Science & Complex Systems) | LECTURES ON WHITE NOISE FUNCTIONALS | Takeyuki Hida (他: Si Si) | World Scientific Publishing Company | 280 p. | 2006 (2008) | 9789812560520 | 2026/05/23 |
| 114 | 自然科学・複雑系 (Natural Science & Complex Systems) | INNOVATION APPROACH TO RANDOM FIELDS, AN: APPLICATION OF WHITE NOISE THEORY | Takeyuki Hida (他: Si Si) | World Scientific Publishing Company | 204 p. | 2004 | 9789812380951 | 2026/05/23 |
| 115 | 数学 (Mathematics) | Infinite-dimensional Analysis: Operators In Hilbert Space; Stochastic Calculus Via Representations, And Duality Theory | Palle Jorgensen (他: James Tian) | World Scientific | 253 p. | 2021 | 9789811225796 | 2026/05/23 |
| 116 | 数学 (Mathematics) | Stochastic Analysis on Infinite Dimensional Spaces | Hiroshi Kunita (他: Hui-Hsiung Kuo) | Chapman and Hall/CRC | 336 p. | 1994 | 9780582244900 | 2026/05/23 |
| 117 | 数学 (Mathematics) | QUANTUM PROBABILITY AND INFINITE DIMENSIONAL ANALYSIS: FROM FOUNDATIONS TO APPLLICATIONS (Qp-Pq: Quantum Probability and White Noise Analysis) | Uwe Franz (他: Michael Schürmann) | World Scientific Publishing Company | 548 p. | 2005 | 9789812561473 | 2026/05/23 |
| 118 | 数学 (Mathematics) | Spectral Analysis of Growing Graphs: A Quantum Probability Point of View (SpringerBriefs in Mathematical Physics, 20) | Nobuaki Obata | Springer | 146 p. | 2017 | 9789811035050 | 2026/05/23 |
| 119 | 数学 (Mathematics) | Quantum Probability and Spectral Analysis of Graphs (Theoretical and Mathematical Physics) by Hora, Akihito, Obata, Nobuaki (2007) Hardcover | Akihito Hora (他: Unknown Author) | Springer | - | - | - | 2026/05/23 |
| 120 | 数学 (Mathematics) | White Noise Calculus and Fock Space (Lecture Notes in Mathematics, 1577) | Nobuaki Obata | Springer | 200 p. | 1994 | 9783540579854 | 2026/05/23 |
| 121 | 数学 (Mathematics) | P-Adic Functional Analysis (Lecture Notes in Pure and Applied Mathematics) | A.K. Katsaras (他: W.H. Schikhof) | CRC Press | 336 p. | 2001 | 9780824706111 | 2026/05/17 |
| 122 | 数学 (Mathematics) | P-ADIC ANALYSIS AND MATHEMATICAL PHYSICS (Soviet & East European Maths) | Vladimirov V S (他: I V Volovich, E I Zelenov) | World Scientific Publishing Company | - | 1994 | 9789810208806 | 2026/05/17 |
| 123 | 数学 (Mathematics) | Ultrametric Calculus: An Introduction to p-Adic Analysis (Cambridge Studies in Advanced Mathematics, Series Number 4) | W.H. Schikhof (他: Béla Bollobás) | Cambridge University Press | 320 p. | 1985 (2007) | 9780521032872 | 2026/05/17 |
| 124 | 数学 (Mathematics) | P-adic Analysis Compared With Real (Student Mathematical Library) | Svetlana Katok | American Mathematical Society | - | 2007 | 9780821842201 | 2026/05/17 |
| 125 | 数学 (Mathematics) | p-Adic Analysis: Stochastic Processes and Pseudo-Differential Equations (Advances in Analysis and Geometry, 11) | W A Zúñiga-Galindo | De Gruyter | 162 p. | 2024 | 9783111578330 | 2026/05/17 |
| 126 | 数学 (Mathematics) | Geometry and Representation Theory of Real and p-adic groups (Progress in Mathematics, 158) | Juan Tirao (他: David A. Vogan Jr., Joe Wolf) | Birkhäuser | 336 p. | 2011 | 9781461286813 | 2026/05/17 |
| 127 | 数学 (Mathematics) | Berkeley Lectures on p-adic Geometry (Annals of Mathematics Studies, 207) | Peter Scholze (他: Jared Weinstein) | Princeton University Press | 264 p. | 2020 | 9780691202082 | 2026/05/17 |
| 128 | 数学 (Mathematics) | Lectures on Kähler Geometry (London Mathematical Society Student Texts, Series Number 69) | Andrei Moroianu | Cambridge University Press | 182 p. | 2007 | 9780521688970 | 2026/05/17 |
| 129 | 数学 (Mathematics) | Canonical Metrics in Kähler Geometry | Gang Tian (他: M. Akveld) | Birkhäuser | 108 p. | 2000 | 9783764361945 | 2026/05/17 |
| 130 | 数学 (Mathematics) | Handbook of Writing for the Mathematical Sciences | Nicholas J.  Higham | SIAM: Society for Industrial and Applied Mathematics | 184 p. | 1993 (1998) | 9780898714203 | 2026/05/16 |
| 131 | 化学・物質科学 (Chemistry & Materials) | Construction of Haar measure on projective limit group and random order values of non-atomic games (Discussion paper) | L. K Raut | University of California, San Diego, Dept. of Economics | 26 p. | 1994 | - | 2026/05/14 |
| 132 | 数学 (Mathematics) | The Joys of Haar Measure (Graduate Studies in Mathematics, 150) | Joe Diestel (他: Angela Spalsbury) | Amer Mathematical Society | 320 p. | 2013 (2014) | 9781470409357 | 2026/05/14 |
| 133 | 物理学 (Physics) | Quantum techniques for stochastic mechanics | John C. Baez (他: Jacob D. Biamonte) | - | 270 p. | 2012 | - | 2026/05/12 |
| 134 | 数学 (Mathematics) | The Craft of Scientific Writing | Michael Alley | Springer | 282 p. | 1986 (1998) | 9780387947662 | 2026/05/08 |
| 135 | 数学 (Mathematics) | The Craft of Scientific Writing, 3rd Edition by Michael Alley(1998-09-02) | Michael Alley (他: Unknown Author) | Springer | - | - | - | 2026/05/08 |
| 136 | 自然科学・複雑系 (Natural Science & Complex Systems) | How to Write & Publish a Scientific Paper | Robert A. Day | Greenwood | 275 p. | 1979 (1998) | 9781573561655 | 2026/05/08 |
| 137 | 生物学・生命科学 (Biology) | Guide to Academic and Scientific Publication: How to Get Your Writing Published in Scholarly Journals | Linda Olson | eacademia | 136 p. | 2014 | 9780992958800 | 2026/05/08 |
| 138 | 数学 (Mathematics) | Toda Lattices, Cosymplectic Manifolds, Backlund Transformations and Kinks Part B. Interdisciplinary Mathematics Volume XVIII | Robert. Hermann | Brookline, Massachusetts : Math Sci Press, 1977 | - | 1977 | - | 2026/05/07 |
| 139 | 数学 (Mathematics) | A Continuum Limit of the Toda Lattice (Memoirs of the American Mathematical Society) | Percy Deift | Amer Mathematical Society | 216 p. | 1998 | 9780821806913 | 2026/05/07 |
| 140 | 物理学 (Physics) | Shadows of Reality: The Fourth Dimension in Relativity, Cubism, and Modern Thought | Tony Robbin | Yale University Press | 137 p. | 2006 | 9780300110395 | 2026/05/07 |
| 141 | 数学 (Mathematics) | The Toda Lattice and Universality for the Computation of the Eigenvalues of a Random Matrix (London Mathematical Society Lecture Note Series, Series Number 500) | Percy Deift (他: Guillaume Dubach, Carlos Tomei, Thomas Trogdon) | Cambridge University Press | 172 p. | 2025 | 9781009664356 | 2026/05/07 |
| 142 | 数学 (Mathematics) | Tropical and Logarithmic Methods in Enumerative Geometry (Oberwolfach Seminars Book 52) | Renzo Cavalieri (他: Hannah Markwig, Dhruv Ranganathan) | Birkhäuser | - | 2023 | 9783031394010 | 2026/05/05 |
| 143 | 数学 (Mathematics) | Tropical Algebraic Geometry (Oberwolfach Seminars, 35) | Ilia Itenberg (他: Grigory Mikhalkin, Eugenii Shustin) | Birkhäuser | 113 p. | 2007 (2009) | 9783034600477 | 2026/05/05 |
| 144 | 数学 (Mathematics) | Introduction to Tropical Geometry (Graduate Studies in Mathematics, 161) | Diane Maclagan (他: Bernd Sturmfels) | Amer Mathematical Society | 363 p. | 2015 | 9780821851982 | 2026/05/05 |
| 145 | 物理学 (Physics) | The Visual Guide to Extra Dimensions: The Physics Of The Fourth Dimension, Compactification, And Current And Upcoming Experiments (A Fourth Dimension of Space Book 2) | Chris McMullen | - | 218 p. | 2014 | - | 2026/05/02 |
| 146 | 数学 (Mathematics) | A Visual Introduction to the Fourth Dimension (Rectangular 4D Geometry) (A Fourth Dimension of Space Book 5) | Chris McMullen | Topher Books | 94 p. | 2012 | - | 2026/05/02 |
| 147 | 生物学・生命科学 (Biology) | The Accidental Superpower: The Next Generation of American Preeminence and the Coming Global Disorder | Peter Zeihan | Twelve | 384 p. | 2014 | 9781455583669 | 2026/04/28 |
| 148 | 数学 (Mathematics) | Quantum Computing: A Gentle Introduction (Scientific and Engineering Computation) | Eleanor Rieffel (他: Wolfgang H. Polak) | Mit Pr | 372 p. | 2011 | 9780262015066 | 2026/04/24 |
| 149 | 数学 (Mathematics) | Introduction to the Maths and Physics of Quantum Mechanics | Lucio Piccirillo | CRC Press | 232 p. | 2023 | 9780367703028 | 2026/04/24 |
| 150 | 物理学 (Physics) | Introduction to Quantum Mechanics | DAVID J. GRIFFITHS DARRELL F. SCHROETER | - | - | 2020 | - | 2026/04/24 |
| 151 | 数学 (Mathematics) | Cost–Benefit Analysis and Health Care Evaluations | Robert J. Brent | Edward Elgar Publishing | 400 p. | 2004 | 9781843765080 | 2026/04/19 |
| 152 | 物理学 (Physics) | Quantum Stochastic Thermodynamics: Foundations and Selected Applications (Oxford Graduate Texts) | Philipp Strasberg | Oxford University Press | 334 p. | 2022 | 9780192895585 | 2026/04/17 |
| 153 | 物理学 (Physics) | Stochastic Thermodynamics | Udo Seifert | Cambridge University Press | 493 p. | 2025 | 9781316519554 | 2026/04/17 |
| 154 | 数学 (Mathematics) | Complex Numbers in Geometry | Isaak M. Yaglom | Academic Press | 243 p. | 1968 | - | 2026/04/10 |
| 155 | 生物学・生命科学 (Biology) | International Financial Management | Geert Bekaert (他: Robert Hodrick) | Cambridge University Press | 925 p. | 2008 (2017) | 9781108547154 | 2026/04/08 |
| 156 | 数学 (Mathematics) | Interest Rates, Exchange Rates and World Monetary Policy | John E. Floyd | Springer | 416 p. | 2009 | 9783642102790 | 2026/04/08 |
| 157 | 数学 (Mathematics) | The Economics of Foreign Exchange and Global Finance | Peijie Wang | Springer | - | 2005 | 9783540212379 | 2026/04/08 |
| 158 | 生物学・生命科学 (Biology) | Exchange Rates and International Finance (5th Edition) | Laurence Copeland | Prentice Hall | 544 p. | 2004 (2008) | 9780273710271 | 2026/04/08 |
| 159 | 数学 (Mathematics) | Empirical Asset Pricing: The Cross Section of Stock Returns (Wiley Series in Probability and Statistics) | Turan G. Bali | Wiley | 512 p. | 2016 | 9781118095041 | 2026/04/07 |
| 160 | 数学 (Mathematics) | Probability Distributions in Quantum Statistical Mechanics (Lecture Notes in Mathematics Book 1148) | Mark A. Kon | Springer | - | 2006 | 9783540396376 | 2026/04/07 |
| 161 | 自然科学・複雑系 (Natural Science & Complex Systems) | Handbook Of Applied Investment Research | John B Guerard | World Scientific | 813 p. | 2020 | 9789811225185 | 2026/04/04 |
| 162 | 数学 (Mathematics) | MODERN FINANCIAL ENGINEERING: COUNTERPARTY, CREDIT, PORTFOLIO AND SYSTEMIC RISKS (Topics in Systems Engineering) | Giuseppe Orlando (他: Michele Bufalo, Henry Penikas, Concetta Zurlo, Chin Choon, Lakshmi) | World Scientific Publishing Company | 436 p. | 2022 | 9789811252358 | 2026/04/04 |
| 163 | 数学 (Mathematics) | Interest Rate Models - Theory and Practice: With Smile, Inflation and Credit (Springer Finance) | Damiano Brigo (他: Fabio Mercurio) | Springer | 1038 p. | 2006 | 9783540221494 | 2026/04/04 |
| 164 | 計算機科学・情報科学 (Computer Science) | Machine Learning and Data Sciences for Financial Markets: A Guide to Contemporary Practices | Agostino Capponi (他: Charles-Albert Lehalle) | Cambridge University Press | - | 2023 | 9781009034036 | 2026/04/04 |
| 165 | 数学 (Mathematics) | Handbook of Financial Econometrics, Mathematics, Statistics, and Machine Learning | Cheng-Few Lee (他: John C. Lee, Alice C. Lee) | World Scientific Pub Co Inc | 4881 p. | 2020 | 9789811202384 | 2026/04/04 |
| 166 | 数学 (Mathematics) | The Cult of Statistical Significance: How the Standard Error Costs Us Jobs, Justice, and Lives (Economics, Cognition, And Society) | Stephen T. Ziliak (他: Deirdre Nansen McCloskey) | University of Michigan Press | 352 p. | 2008 | 9780472050079 | 2026/04/03 |
| 167 | 数学 (Mathematics) | Statistics Done Wrong: The Woefully Complete Guide | Alex Reinhart | No Starch Press | 176 p. | 2013 (2015) | 9781593276201 | 2026/04/03 |
| 168 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Book of Why: The New Science of Cause and Effect | Judea Pearl (他: Dana Mackenzie) | Basic Books | 432 p. | 2018 | 9780465097609 | 2026/04/03 |
| 169 | 数学 (Mathematics) | Controversial Statistical Issues in Clinical Trials | Shein-Chung Chow | CRC Press | 598 p. | 2011 (2014) | 9781283257534 | 2026/04/03 |
| 170 | 数学 (Mathematics) | Modern Issues and Methods in Biostatistics (Statistics for Biology and Health) | Mark Chang | Springer | 321 p. | 2011 | 9781441998415 | 2026/04/03 |
| 171 | 数学 (Mathematics) | HODGE THEORY OF PROJECTIVE MANIFOLDS, THE | Mark Andrea De Cataldo | Imperial College Press | 102 p. | 2007 | 9781860948008 | 2026/03/30 |
| 172 | 数学 (Mathematics) | Introduction to Hodge Theory | J. P. Demailly (他: J. P. Demailly, L. Illusie, C. Peters, Jose Bertin) | Amer Mathematical Society | - | 2002 | 9780821820407 | 2026/03/30 |
| 173 | 生物学・生命科学 (Biology) | Geopolitics, Supply Chains, and International Relations in East Asia | Etel Solingen | Cambridge University Press | 350 p. | 2021 | 9781108833561 | 2026/03/29 |
| 174 | 自然科学・複雑系 (Natural Science & Complex Systems) | The New Map: Energy, Climate, and the Clash of Nations | Daniel Yergin | Penguin Press | 512 p. | 2020 | 9781594206436 | 2026/03/29 |
| 175 | 数学 (Mathematics) | Introduction to Noncommutative Algebra (Universitext) | Matej Bresar | Springer | 236 p. | 2014 | 9783319086927 | 2026/03/28 |
| 176 | 数学 (Mathematics) | Noncommutative Algebra (Graduate Texts in Mathematics, 144) | Benson Farb (他: R. Keith Dennis) | Springer | 240 p. | 1993 (2012) | 9781461269366 | 2026/03/28 |
| 177 | 数学 (Mathematics) | Basic Noncommutative Geometry (EMS Series of Lectures in Mathematics) | Masoud Khalkhali | Amer Mathematical Society | 223 p. | 2009 | 9783037190616 | 2026/03/27 |
| 178 | 数学 (Mathematics) | Noncommutative Geometry and Particle Physics (Mathematical Physics Studies) | Walter D. van Suijlekom | Springer Nature | 237 p. | 2014 | 9789401791618 | 2026/03/27 |
| 179 | 数学 (Mathematics) | Elements of Noncommutative Geometry (Birkhäuser Advanced Texts Basler Lehrbücher) | Joseph C. Varilly (他: Joseph C. Varilly, Hector Figueroa) | Birkhäuser | - | 2000 | 9780817641245 | 2026/03/27 |
| 180 | 数学 (Mathematics) | Noncommutative Geometry | Alain Connes | Academic Press | 680 p. | 1990 (1994) | 9780121858605 | 2026/03/27 |
| 181 | 数学 (Mathematics) | Clinical Trials: A Methodologic Perspective (Wiley Series in Probability and Statistics) | Steven Piantadosi | Wiley-Interscience | 687 p. | 1997 (2005) | 9780471727811 | 2026/03/27 |
| 182 | 数学 (Mathematics) | Medical Statistics Made Easy by Michael Harris, Scion Publishing Ltd. | Michael Harris | Scion Publishing Ltd. | - | - | - | 2026/03/27 |
| 183 | 数学 (Mathematics) | Intuitive Biostatistics | Harvey Motulsky | Oxford University Press | 408 p. | 1995 | 9780195086072 | 2026/03/27 |
| 184 | 数学 (Mathematics) | Statistical Methods in Medical Research | Peter Armitage (他: Geoffrey Berry, J.N.S. Matthews) | Wiley-Blackwell | 832 p. | 1971 (2001) | 9780632052578 | 2026/03/27 |
| 185 | 数学 (Mathematics) | Biostatistics: A Foundation for Analysis in the Health Sciences—Student Solutions Manual | Chad L. Cross (他: Wayne W. Daniel) | Wiley | 168 p. | 2001 (2009) | 9780470105818 | 2026/03/27 |
| 186 | 数学 (Mathematics) | Fundamentals Of Biostatistics | Bernard Rosner | Duxbury Press | 868 p. | 1982 (2005) | 9780534418205 | 2026/03/27 |
| 187 | 数学 (Mathematics) | A First Course in Topos Quantum Theory (Lecture Notes in Physics, 868) | Cecilia Flori | Springer | 462 p. | 2013 | 9783642357121 | 2026/03/21 |
| 188 | 数学 (Mathematics) | Higher Topos Theory (Annals of Mathematics Studies, 170) | Jacob Lurie | Princeton University Press | 944 p. | 2009 | 9780691140483 | 2026/03/21 |
| 189 | 数学 (Mathematics) | Handbook of Categorical Algebra: Volume 3, Sheaf Theory (Encyclopedia of Mathematics and its Applications, Series Number 52) | Francis Borceux | Cambridge University Press | 544 p. | 1994 (2008) | 9780521061247 | 2026/03/21 |
| 190 | 数学 (Mathematics) | Sheaves in Geometry and Logic: A First Introduction to Topos Theory (Universitext) (Volume 0) | Saunders MacLane (他: Ieke Moerdijk) | Springer | 642 p. | 1992 | 9780387977102 | 2026/03/21 |
| 191 | 数学 (Mathematics) | Elements of ∞-Category Theory | Emily Riehl (他: Dominic Verity) | Cambridge University Press | 770 p. | 2022 | 9781108837989 | 2026/03/21 |
| 192 | 数学 (Mathematics) | Category Theory in Context (Aurora: Dover Modern Math Originals) | Emily Riehl | Dover Publications | 272 p. | 2015 (2016) | 9780486809038 | 2026/03/21 |
| 193 | 数学 (Mathematics) | Complex Projective Geometry: Selected Papers (London Mathematical Society Lecture Note Series, Series Number 179) (Volume 0) | G. Ellingsrud (他: C. Peskine, G. Sacchiero, S. A. Stromme) | Cambridge University Press | 352 p. | 1992 | 9780521433525 | 2026/03/19 |
| 194 | 数学 (Mathematics) | Algebraic Geometry I: Complex Projective Varieties | David Mumford | Springer-Verlag | 186 p. | 1976 | 9780387076034 | 2026/03/19 |
| 195 | 数学 (Mathematics) | Differential and Complex Geometry: Origins, Abstractions and Embeddings | Raymond O. Wells Jr. | Springer | 333 p. | 2017 | 9783319581835 | 2026/03/19 |
| 196 | 数学 (Mathematics) | Riemann Surfaces by Way of Complex Analytic Geometry (Graduate Studies in Mathematics) | Dror Varolin | American Mathematical Society | 236 p. | 2011 | 9780821853696 | 2026/03/19 |
| 197 | 数学 (Mathematics) | Hodge Theory and Complex Algebraic Geometry I: Volume 1 (Cambridge Studies in Advanced Mathematics, Series Number 76) | Claire Voisin (他: Leila Schneps) | Cambridge University Press | 334 p. | 1998 (2008) | 9780521718011 | 2026/03/19 |
| 198 | 数学 (Mathematics) | Geometry of Complex Numbers (Dover Books on Mathematics) | Hans Schwerdtfeger | Dover Publications | 224 p. | 1980 | 9780486638300 | 2026/03/19 |
| 199 | 数学 (Mathematics) | Algebraic Structures and Graph Theory, 2nd Edition | Irina Cristea (他: Alessandro Linzi) | Mdpi AG | 188 p. | 2025 | 9783725833559 | 2026/03/19 |
| 200 | 数学 (Mathematics) | Combinatorial mathematics and its applications;: Proceedings of a conference held at the Mathematical Institute, Oxford, from 7-10 July, 1969, | D.J.A. Welsh | AP | 364 p. | 1971 | 9780127433509 | 2026/03/14 |
| 201 | 数学 (Mathematics) | Spinors and Space-Time: Volume 1, Two-Spinor Calculus and Relativistic Fields (Cambridge Monographs on Mathematical Physics) | Roger Penrose (他: Wolfgang Rindler) | Cambridge University Press | 472 p. | 1984 (1987) | 9780521337076 | 2026/03/14 |
| 202 | 数学 (Mathematics) | Nonparametric Inference on Manifolds: With Applications to Shape Spaces (Institute of Mathematical Statistics Monographs, Series Number 2) | Abhishek Bhattacharya (他: Rabi Bhattacharya) | Cambridge University Press | 252 p. | 2012 | 9781107019584 | 2026/03/14 |
| 203 | 数学 (Mathematics) | [ Directional Statistics (Wiley Series in Probability and Statistics) By Jupp, P E ( Author ) Hardcover 1999 ] | P E Jupp | John Wiley & Sons Jan-26-1999 | - | 1999 | - | 2026/03/14 |
| 204 | 数学 (Mathematics) | Finite Volume Methods for Hyperbolic Problems (Cambridge Texts in Applied Mathematics, Series Number 31) | Randall J. LeVeque | Cambridge University Press | 580 p. | 2002 | 9780521009249 | 2026/03/11 |
| 205 | 数学 (Mathematics) | Numerical Methods for Partial Differential Equations: Finite Difference and Finite Volume Methods | Sandip Mazumder | Academic Press | 484 p. | 2015 (2016) | 9780128498941 | 2026/03/11 |
| 206 | 数学 (Mathematics) | An Invitation to Algebraic Geometry (Universitext) | Karen E.   Smith (他: William Traves, Lauri Kahanpää, Pekka Kekäläinen) | Springer | 180 p. | 2000 (2010) | 9781441931955 | 2026/03/10 |
| 207 | 数学 (Mathematics) | Projective Geometry: An Introduction (Oxford Handbooks) | Rey Casse | Oxford University Press | 212 p. | 2006 | 9780199298860 | 2026/03/10 |
| 208 | 数学 (Mathematics) | Projective Geometry (Compact Textbooks in Mathematics) | Emre Coskun | Birkhäuser | 149 p. | 2025 | 9783032021953 | 2026/03/10 |
| 209 | 数学 (Mathematics) | Perspectives on Projective Geometry: A Guided Tour Through Real and Complex Geometry | Jürgen Richter-Gebert | Springer | 593 p. | 2011 | 9783642172854 | 2026/03/10 |
| 210 | 数学 (Mathematics) | An Introduction to Nonlinear Finite Element Analysis | J.N. Reddy | Oxford University Press | 488 p. | 2004 | 9780198525295 | 2026/03/10 |
| 211 | 数学 (Mathematics) | Fundamentals of Finite Element Analysis | David V. Hutton | McGraw-Hill Science/Engineering/Math | 640 p. | 2003 | 9780072922363 | 2026/03/10 |
| 212 | 数学 (Mathematics) | Advanced Topics in Finite Element Analysis of Structures: With Mathematica and MATLAB Computations | M. Asghar Bhatti | Wiley | 608 p. | 2005 (2006) | 9780471648079 | 2026/03/10 |
| 213 | 数学 (Mathematics) | Practical Finite Element Analysis | Nitin S. Gokhale (他: Sanjay S.Deshpande, Sanjeev V.Bedekar) | Finite To Infinite | 446 p. | 2008 | 9788190619509 | 2026/03/10 |
| 214 | 数学 (Mathematics) | Geometric Invariant Theory (ERGEBNISSE DER MATHEMATIK UND IHRER GRENZGEBIETE 2 FOLGE) | David Mumford | Springer Verlag | 292 p. | 1965 (2009) | 9780387569635 | 2026/03/05 |
| 215 | 数学 (Mathematics) | The Geometric Hopf Invariant and Surgery Theory (Springer Monographs in Mathematics) | Michael Crabb (他: Andrew Ranicki) | Springer | 413 p. | 2018 | 9783319713052 | 2026/03/05 |
| 216 | 数学 (Mathematics) | An Invariant Approach to Statistical Analysis of Shapes | Subhash R. Lele (他: J. T. Richtsmeier) | Chapman and Hall/CRC | 322 p. | 2001 | 9780849303197 | 2026/03/04 |
| 217 | 数学 (Mathematics) | A Career in Statistics: Beyond the Numbers | Gerald J. Hahn (他: Necip Doganaksoy) | Wiley | 360 p. | 2011 | 9780470404416 | 2026/02/27 |
| 218 | 計算機科学・情報科学 (Computer Science) | Build a Career in Data Science | Emily  Robinson (他: Jacqueline Nolis) | MEAP | 250 p. | 2020 | 9781617296246 | 2026/02/27 |
| 219 | 数学 (Mathematics) | Shapes and Geometries: Metrics, Analysis, Differential Calculus, and Optimization (Advances in Design and Control, Series Number 22) | Michel C. Delfour | Society for Industrial and Applied Mathematics | 646 p. | 2010 (2011) | 9780898719369 | 2026/02/27 |
| 220 | 数学 (Mathematics) | Modern Geometries: The Analytic Approach | Michael Henle | Pearson College Div | 372 p. | 1996 | 9780131934184 | 2026/02/27 |
| 221 | 数学 (Mathematics) | A Course in Metric Geometry | Dmitri Burago | Amer Mathematical Society | 417 p. | 2001 | 9780821821299 | 2026/02/27 |
| 222 | 数学 (Mathematics) | Metric Affine Geometry | Ernst Snapper | Dover Pubns | - | 1971 (1989) | 9780486661087 | 2026/02/27 |
| 223 | 数学 (Mathematics) | Concepts of Modern Mathematics (Dover Books on Mathematics) | Ian Stewart | Dover Publications | 352 p. | 1975 (1995) | 9780486284248 | 2026/02/26 |
| 224 | 数学 (Mathematics) | Introduction to Random Matrices: Theory and Practice (SpringerBriefs in Mathematical Physics, 26) | Giacomo Livan (他: Marcel Novaes, Pierpaolo Vivo) | Springer | 133 p. | 2018 | 9783319708836 | 2026/02/26 |
| 225 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Fabric of Reality: The Science of Parallel Universes--and Its Implications | David Deutsch | Penguin Books | 390 p. | 1996 (1998) | 9780140275414 | 2026/02/22 |
| 226 | 数学 (Mathematics) | What Is Mathematics? An Elementary Approach to Ideas and Methods | Richard Courant (他: Ian Stewart, Herbert Robbins) | Oxford University Press | 592 p. | 1941 (1996) | 9780195105193 | 2026/02/21 |
| 227 | 数学 (Mathematics) | Food Research: Nutritional Anthropology and Archaeological Methods (Research Methods for Anthropological Studies of Food and Nutrition, 1) | Janet Chrzan (他: John Brett) | Berghahn Books | 254 p. | 2017 | 9781785332876 | 2026/02/17 |
| 228 | 数学 (Mathematics) | Canadian Perspectives on Immigration in Small Cities (International Perspectives on Migration, 12) | Glenda Tibe Bonifacio (他: Julie L. Drolet) | Springer | 316 p. | 2016 | 9783319404233 | 2026/02/16 |
| 229 | 数学 (Mathematics) | On The Cultural Cringe (Melbourne University Press Masterworks S) | A.A. Phillips | Melbourne University | 90 p. | 2024 | 9780522852219 | 2026/02/16 |
| 230 | 数学 (Mathematics) | Health Care and Public Policy: An Australian Analysis | George R. Palmer (他: Stephanie D. Short) | Macmillan Co of Australia | 398 p. | 1989 (2000) | 9780732963408 | 2026/02/16 |
| 231 | 数学 (Mathematics) | The International Living Guide to Retiring Overseas on a Budget: How to Live Well on $25,000 a Year | Suzan Haskins (他: Dan Prescher) | Wiley | 272 p. | 2014 | 9781118758595 | 2026/02/16 |
| 232 | 数学 (Mathematics) | The Co-Housing Phenomenon: Environmental Alliance in Times of Changes (The Urban Book Series) | Emanuele Giorgi | Springer | 472 p. | 2020 | 9783030370978 | 2026/02/16 |
| 233 | 計算機科学・情報科学 (Computer Science) | Hypothesis Testing with E-values (Foundations and Trends(r) in Artificial Intelligence) | Aaditya Ramdas (他: Ruodu Wang) | Now Publishers | 426 p. | 2025 | 9781638285908 | 2026/02/13 |
| 234 | 数学 (Mathematics) | Testing Statistical Hypotheses (Springer Texts in Statistics) | E.L. Lehmann (他: Joseph P. Romano) | Springer | 1027 p. | 2022 | 9783030705770 | 2026/02/13 |
| 235 | 数学 (Mathematics) | Entropy-Enthalpy Compensation: Finding a Methodological Common Denominator through Probability, Statistics, and Physics | Evgeni Starikov | Jenny Stanford Publishing | 418 p. | 2020 | 9781000091861 | 2026/02/13 |
| 236 | 数学 (Mathematics) | Entropy-Enthalpy Compensation: Finding a Methodological Common Denominator Through Probability, Statistics, and Physics | Evgeni Starikov | Jenny Stanford Publishing | 350 p. | 2020 | 9781000091922 | 2026/02/13 |
| 237 | 数学 (Mathematics) | The Entropy Principle: Thermodynamics for the Unsatisfied | Andre Thess | Springer | 191 p. | 2007 (2011) | 9783642133480 | 2026/02/13 |
| 238 | 数学 (Mathematics) | Entropy and Free Energy in Structural Biology: From Thermodynamics to Statistical Mechanics to Computer Simulation (Foundations of Biochemistry and Biophysics) | Hagai Meirovitch | CRC Press | 379 p. | 2020 | 9781000072327 | 2026/02/13 |
| 239 | 数学 (Mathematics) | Nonadditive Entropies and Nonextensive Statistical Mechanics: Dedicated to Professor Constantino Tsallis on the Occasion of His 80th Birthday | Ugur Tirnakli (他: Christian Beck, Hans J Herrmann) | Mdpi AG | 314 p. | 2025 | 9783725839995 | 2026/02/13 |
| 240 | 数学 (Mathematics) | Statistical Foundations Of Entropy, The (Statistical Physics Complexity) | John D. Ramshaw | World Scientific | 217 p. | 2017 | 9789813234147 | 2026/02/13 |
| 241 | 数学 (Mathematics) | Holographic Entanglement Entropy (Lecture Notes in Physics, 931) | Mukund Rangamani (他: Tadashi Takayanagi) | Springer | 255 p. | 2017 | 9783319525716 | 2026/02/12 |
| 242 | 数学 (Mathematics) | AdS3/CFT2 and Holographic Entanglement Entropy (Springer Theses) | Jie-qiang Wu | Springer | 292 p. | 2019 | 9789811332128 | 2026/02/12 |
| 243 | 数学 (Mathematics) | Mathematical Foundations Of Nonextensive Statistical Mechanics | Umarov Sabir (他: Tsallis Constantino) | WSPC | 336 p. | 2022 | 9789811245152 | 2026/02/11 |
| 244 | 自然科学・複雑系 (Natural Science & Complex Systems) | Nonextensive Entropy: Interdisciplinary Applications (Santa Fe Institute Studies on the Sciences of Complexity) | Murray Gell-Mann (他: Constantino Tsallis) | Oxford University Press | 440 p. | 2004 | 9780195159776 | 2026/02/11 |
| 245 | 数学 (Mathematics) | Introductory Accounting (Idiot's Guides) | David H. Ringstrom CPA (他: Gail Perry) | Alpha | 320 p. | 2016 | 9781615648870 | 2026/02/07 |
| 246 | 数学 (Mathematics) | The Mathematical Language of Quantum Theory: From Uncertainty to Entanglement | Teiko Heinosaari (他: Mario Ziman) | Cambridge University Press | 339 p. | 2011 | 9780521195836 | 2026/02/06 |
| 247 | 数学 (Mathematics) | Methods of Information Geometry (Translations of Mathematical Monographs) | Shun-Ichi Amari (他: Hiroshi Nagaoka) | Amer Mathematical Society | 206 p. | 2000 (2001) | 9780821805312 | 2026/02/06 |
| 248 | 数学 (Mathematics) | Information Geometry and Its Applications (Applied Mathematical Sciences, 194) | Shun-Ichi Amari | Springer | 387 p. | 2016 | 9784431559771 | 2026/02/06 |
| 249 | 数学 (Mathematics) | Geometry of Quantum States: An Introduction to Quantum Entanglement | Ingemar Bengtsson (他: Karol Życzkowski) | Cambridge University Press | 418 p. | 2006 | 9780521814515 | 2026/02/05 |
| 250 | 数学 (Mathematics) | Probabilistic and Statistical Aspects of Quantum Theory (Publications of the Scuola Normale Superiore) | Alexander S. Holevo | Edizioni della Normale | 340 p. | 2011 | 9788876423758 | 2026/02/05 |
| 251 | 数学 (Mathematics) | Quantum Information Theory and Quantum Statistics (Theoretical and Mathematical Physics) | Denes Petz | Springer | 225 p. | 2007 | 9783540746348 | 2026/02/05 |
| 252 | 物理学 (Physics) | Quantum Computing for Everyone | Chris Bernhardt | The MIT Press | 216 p. | 2019 | 9780262039253 | 2026/02/04 |
| 253 | 物理学 (Physics) | A First Course in Loop Quantum Gravity | Rodolfo Gambini (他: Jorge Pullin) | Oxford University Press | 183 p. | 2011 | 9780199590759 | 2026/01/30 |
| 254 | 数学 (Mathematics) | Covariant Loop Quantum Gravity: An Elementary Introduction to Quantum Gravity and Spinfoam Theory (Cambridge Monographs on Mathematical Physics) | Carlo Rovelli (他: Francesca Vidotto) | Cambridge University Press | 277 p. | 2014 | 9781107069626 | 2026/01/30 |
| 255 | 物理学 (Physics) | Time Reborn: From the Limits of Physics to the Future of the Universe | Lee Smolin (他: Henry Reich) | Houghton Mifflin Harcourt | 352 p. | 2013 | 9780547511726 | 2026/01/30 |
| 256 | 物理学 (Physics) | Quantum Space: Loop Quantum Gravity and the Search for the Structure of Space, Time, and the Universe | Jim Baggott | Oxford University Press | 448 p. | 2019 | 9780198809111 | 2026/01/30 |
| 257 | 計算機科学・情報科学 (Computer Science) | The Cartoon Guide to the Computer | Larry Gonick | Harper Paperbacks | 249 p. | 1991 | 9780062730978 | 2026/01/28 |
| 258 | 数学 (Mathematics) | The Cartoon Guide to Statistics | Larry Gonick (他: Woollcott Smith) | HarperPerennial | 230 p. | 1993 | 9780062731029 | 2026/01/28 |
| 259 | 物理学 (Physics) | Wavelet Transforms and Their Applications | Lokenath Debnath | Birkhäuser | 565 p. | 2001 | 9780817642044 | 2026/01/23 |
| 260 | 物理学 (Physics) | Introduction to Wavelets and Wavelet Transforms: A Primer | C. Sidney Burrus (他: Ramesh Gopinath, Haitao Guo) | Pearson | 288 p. | 1997 | 9780134896007 | 2026/01/23 |
| 261 | 数学 (Mathematics) | Elementary Topology: Problem Textbook | VIRO | Orient Blackswan | 400 p. | 2008 (2012) | 9780821887264 | 2026/01/23 |
| 262 | 数学 (Mathematics) | Riemann, Topology, and Physics | Michael I. Monastyrsky | Birkhäuser Boston | 216 p. | 1999 | 9780817637897 | 2026/01/23 |
| 263 | 数学 (Mathematics) | Topology | James R. Munkres | Pearson College Div | 537 p. | 1974 (2000) | 9780131816299 | 2026/01/23 |
| 264 | 数学 (Mathematics) | Introduction to Topology | Bert Mendelson | Dover Publications | 224 p. | 1975 (1990) | 9780486663524 | 2026/01/23 |
| 265 | 数学 (Mathematics) | Topology & Modern Analysis | George F. Simmons | MCGRAW HILL COMPANIES | - | - | - | 2026/01/23 |
| 266 | 数学 (Mathematics) | Modelling Non-Markovian Quantum Systems Using Tensor Networks (Springer Theses) | Aidan Strathearn | Springer | 122 p. | 2020 | 9783030549756 | 2026/01/23 |
| 267 | 数学 (Mathematics) | Most Honourable Remembrance: The Life and Work of Thomas Bayes (Sources and Studies in the History of Mathematics and Physical Sciences) | Andrew I. Dale | Springer | 693 p. | 2003 | 9780387004990 | 2026/01/23 |
| 268 | 数学 (Mathematics) | Introduction to Tensor Network Methods: Numerical simulations of low-dimensional many-body quantum systems | Simone Montangero | Springer | 320 p. | 2018 | - | 2026/01/23 |
| 269 | 数学 (Mathematics) | Vectors, Tensors and the Basic Equations of Fluid Mechanics (Dover Books on Mathematics) | Rutherford Aris | Dover Publications | 320 p. | 1990 | 9780486661100 | 2026/01/23 |
| 270 | 数学 (Mathematics) | Vector and Tensor Analysis with Applications (Dover Books on Mathematics) | A.I. Borisenko (他: I.E. Tarapov, Richard A. Silverman) | Dover Publications | 288 p. | 1979 | 9780486638331 | 2026/01/23 |
| 271 | 数学 (Mathematics) | Vector and Tensor Analysis (Dover Books on Mathematics) | G.E. Hay | Dover Publications | 206 p. | 1979 (2012) | 9780486601090 | 2026/01/23 |
| 272 | 数学 (Mathematics) | Tensors: Geometry and Applications (Graduate Studies in Mathematics) | J.M. Landsberg | American Mathematical Society | 439 p. | 2011 | 9780821869079 | 2026/01/23 |
| 273 | 数学 (Mathematics) | Tensor Calculus: A Concise Course (Dover Books on Mathematics) | Barry Spain | Dover Publications | 144 p. | 2003 | 9780486428314 | 2026/01/23 |
| 274 | 数学 (Mathematics) | Tensor Analysis on Manifolds (Dover Books on Mathematics) | Richard L. Bishop (他: Samuel I. Goldberg) | Dover Publications | 288 p. | 1980 | 9780486640396 | 2026/01/23 |
| 275 | 数学 (Mathematics) | A Student's Guide to Vectors and Tensors (Student's Guides) | Daniel Fleisch | Cambridge University Press | 206 p. | 2011 | 9780521171908 | 2026/01/23 |
| 276 | 数学 (Mathematics) | The Absolute Differential Calculus (Calculus of Tensors) (Dover Books on Mathematics) | Tullio Levi-Civita | Dover Publications | 480 p. | 1928 (2013) | 9780486634012 | 2026/01/23 |
| 277 | 数学 (Mathematics) | A Geometrical Introduction to Tensor Calculus | Jeroen Tromp | Princeton University Press | 248 p. | 2025 | 9780691267982 | 2026/01/23 |
| 278 | 数学 (Mathematics) | Regular and Chaotic Oscillations (Foundations of Engineering Mechanics) | David P. Landau | Springer | 409 p. | 2001 | 9783540410010 | 2026/01/23 |
| 279 | 数学 (Mathematics) | Stochastic Equations in Infinite Dimensions | Giuseppe Da Prato (他: Jerzy Zabczyk) | Cambridge University Press | 476 p. | 1992 (2011) | 9780511877223 | 2026/01/23 |
| 280 | 数学 (Mathematics) | Semigroups of Linear Operators and Applications to Partial Differential Equations (Applied Mathematical Sciences, 44) | Amnon Pazy | Springer | 279 p. | 1983 (1992) | 9780387908458 | 2026/01/23 |
| 281 | 数学 (Mathematics) | Kolmogorov Equations for Stochastic PDEs (Advanced Courses in Mathematics - CRM Barcelona) | Giuseppe Da Prato | Birkhäuser | 189 p. | 2004 | 9783764372163 | 2026/01/23 |
| 282 | 数学 (Mathematics) | Nonlocal Diffusion and Applications (Lecture Notes of the Unione Matematica Italiana, 20) | Claudia Bucur (他: Enrico Valdinoci) | Springer | 167 p. | 2016 | 9783319287386 | 2026/01/23 |
| 283 | 数学 (Mathematics) | Spline Functions and Multivariate Interpolations (Mathematics and Its Applications Book 248) | Borislav D. Bojanov (他: H. Hakopian, B. Sahakian) | Springer | - | 2013 | 9789401581691 | 2026/01/23 |
| 284 | 数学 (Mathematics) | Boris Hessen: Physics and Philosophy in the Soviet Union, 1927–1931: Neglected Debates on Emergence and Reduction (History of Physics) | Chris Talbot (他: Olga Pattison) | Springer | 178 p. | 2021 | 9783030700447 | 2026/01/23 |
| 285 | 数学 (Mathematics) | Techniques of Semigroup Theory (Oxford Science Publications) | Peter M. Higgins | Clarendon Press | 268 p. | 1992 | 9780198535775 | 2026/01/23 |
| 286 | 数学 (Mathematics) | Semigroup Approach to Nonlinear Diffusion Equations | Barbu Viorel | World Scientific Pub Co Inc | 220 p. | 2021 | 9789811246517 | 2026/01/23 |
| 287 | 数学 (Mathematics) | An Introduction to Semigroup Theory (L.M.S. Monographs ; 7) | John M. Howie | Academic Pr | 272 p. | 1976 | 9780123569509 | 2026/01/23 |
| 288 | 自然科学・複雑系 (Natural Science & Complex Systems) | Inverse Semigroups: The Theory of Partial Symmetries | Mark Verus Lawson | World Scientific Publishing | 428 p. | 1998 | 9789810233167 | 2026/01/23 |
| 289 | 数学 (Mathematics) | Phenomenology and QBism: New Approaches to Quantum Mechanics (Routledge Studies in the Philosophy of Mathematics and Physics) | Philipp Berghofer (他: Harald A. Wiltsche) | Routledge | - | 2023 | 9781003824268 | 2026/01/22 |
| 290 | 物理学 (Physics) | QBism: The Future of Quantum Physics | Hans Christian Von Baeyer (他: Lili Von Baeyer) | Harvard University Press | 253 p. | 2016 | 9780674545359 | 2026/01/22 |
| 291 | 生物学・生命科学 (Biology) | Scholarpedia of Touch | Tony J. Prescott (他: Ehud Ahissar, Eugene Izhikevich) | Atlantis Press | 1511 p. | 2015 | 9789462391338 | 2026/01/21 |
| 292 | 神経科学・認知科学 (Neuroscience) | In touch with the future: The sense of touch from cognitive neuroscience to virtual reality | Alberto Gallace (他: Charles Spence) | Oxford University Press | 480 p. | 2014 | 9780199644469 | 2026/01/21 |
| 293 | 神経科学・認知科学 (Neuroscience) | Touching for Knowing: Cognitive psychology of haptic manual perception (Advances in Consciousness Research) | Yvette Hatwell | John Benjamins Publishing Company | 330 p. | 2003 | 9781588114242 | 2026/01/21 |
| 294 | 数学 (Mathematics) | Random Heterogeneous Materials: Microstructure and Macroscopic Properties (Interdisciplinary Applied Mathematics, 16) | Salvatore Torquato | Springer | 724 p. | 2001 | 9780387951676 | 2026/01/21 |
| 295 | 生物学・生命科学 (Biology) | Towards Resilient Societies: The Synergy of Religion, Education, Health, Science, and Technology: Proceedings of the International Conference on Innovative ... September 12th—13th, 2024 (Volume 2) | Maila D.H. Rahiem | CRC Press | 454 p. | 2025 | 9781040414750 | 2026/01/21 |
| 296 | 生物学・生命科学 (Biology) | Investing in International Real Estate For Dummies | Nicholas Wallwork | For Dummies | 361 p. | 2019 | 9781119527541 | 2026/01/21 |
| 297 | 生物学・生命科学 (Biology) | Ramanujan Lecture Notes Series, Vol. 14: Ramanujan Rediscovered: Proceedings of a Conference on Elliptic Functions, Partitions, and q-Series in Memory of K. Venkatachaliengar, Bangalore, June 2009 | Nayandeep Deka (他: Bruce C. Berndt, Shaun Cooper, Tim Huber, Michael J. Schlosser) | International Press of Boston, Incorporated | 244 p. | 2012 | 9781571462459 | 2026/01/21 |
| 298 | 数学 (Mathematics) | Ramanujan Lecture Notes Series, Vol. 12: The Iwasawa theory of totally real fields (Ramanujan Mathematical Society Lecture Notes) by [various] (2010-12-22) | Unknown Author | International Press of Boston, Incorporated | - | - | - | 2026/01/21 |
| 299 | 数学 (Mathematics) | Electron Spin Resonance: Analysis and Interpretation | Philip H. Rieger (他: Royal Society of Chemistry, Anne Rieger, David L. Collinson, Bruce C. Gilbert, Damien M. Murphy) | Royal Society of Chemistry | 286 p. | 2007 | 9780854043552 | 2026/01/21 |
| 300 | 生物学・生命科学 (Biology) | Nuclear Magnetic Resonance Spectroscopy: An Introduction to Principles, Applications, and Experimental Methods | Joseph B. Lambert (他: Eugene P. Mazzola) | Prentice Hall | 368 p. | 2003 | 9780130890665 | 2026/01/21 |
| 301 | 物理学 (Physics) | Quantum Measurement and Control | Howard M. Wiseman (他: Gerard J. Milburn) | Cambridge University Press | 478 p. | 2009 | 9780521804424 | 2026/01/21 |
| 302 | 数学 (Mathematics) | Decoherence: and the Quantum-To-Classical Transition | Maximilian A. Schlosshauer | Springer | 433 p. | 2007 | 9783540357735 | 2026/01/21 |
| 303 | 数学 (Mathematics) | Symbolic Mathematics with Python (Synthesis Lectures on Mathematics & Statistics) | Hugo D. Junghenn | Springer | 263 p. | 2025 | 9783031905216 | 2026/01/21 |
| 304 | 数学 (Mathematics) | Python Programming for Mathematics (Chapman & Hall/CRC The Python Series) | Julien Guillod | Chapman and Hall/CRC | 248 p. | 2024 | 9781032933382 | 2026/01/21 |
| 305 | 数学 (Mathematics) | Python for Mathematics (Chapman & Hall/CRC The Python Series) | Vincent Knight | Chapman and Hall/CRC | 267 p. | 2025 | 9781040341414 | 2026/01/21 |
| 306 | 数学 (Mathematics) | Numerical Methods in Engineering & Science (with Programs in C,C++ &MATLAB) | B.S. Grewal | Khanna Publisher | 700 p. | 2014 | 9788174092489 | 2026/01/21 |
| 307 | 数学 (Mathematics) | Math Adventures with Python: An Illustrated Guide to Exploring Math with Code | Peter Farrell | No Starch Press | 296 p. | 2019 | 9781593278687 | 2026/01/21 |
| 308 | 数学 (Mathematics) | Doing Math with Python | Amit Saha | No Starch Press | 304 p. | 2015 | 9781593276409 | 2026/01/21 |
| 309 | 数学 (Mathematics) | Computational Engineering - Introduction to Numerical Methods | Michael Schäfer | Springer | 331 p. | 2006 | 9783540306856 | 2026/01/21 |
| 310 | 数学 (Mathematics) | The Philosophy of Quantitative Methods: Understanding Statistics | Brian D Haig | Oxford University Press | 168 p. | 2018 | 9780190222055 | 2026/01/21 |
| 311 | 数学 (Mathematics) | Philosophy of Statistics (Volume 7) (Handbook of the Philosophy of Science, Volume 7) | Prasanta S. Bandyopadhyay (他: Dov M. Gabbay, Paul Thagard, John Woods, Malcolm R. Forster) | North Holland | 1260 p. | 2011 | 9780444518620 | 2026/01/21 |
| 312 | 数学 (Mathematics) | Pediatric Neuro-oncology | Katrin Scheinemann (他: Eric Bouffet) | Springer | 766 p. | 2015 | 9781493915415 | 2026/01/21 |
| 313 | 生物学・生命科学 (Biology) | Oxford Textbook of Cancer in Children (Oxford Textbooks in Oncology) | Hubert N. Caron (他: Andrea Biondi, Tom Boterberg, Francois Doz) | OUP Oxford | 312 p. | 2020 | - | 2026/01/21 |
| 314 | 数学 (Mathematics) | A Short Course on Operator Semigroups (Universitext) | Klaus-Jochen Engel (他: Rainer Nagel) | Springer | 258 p. | 2006 | 9780387313412 | 2026/01/21 |
| 315 | 物理学 (Physics) | Van der Waals Forces: A Handbook for Biologists, Chemists, Engineers, and Physicists | V. Adrian Parsegian | Cambridge University Press | 398 p. | 2005 | 9780521547789 | 2026/01/21 |
| 316 | 数学 (Mathematics) | Statistical Mechanics: Algorithms and Computations (Oxford Master Series in Physics) | Werner Krauth | Oxford University Press | 360 p. | 2006 | 9780198515357 | 2026/01/21 |
| 317 | 物理学 (Physics) | Molecular Quantum Mechanics | Peter   Atkins (他: Ronald S. Friedman) | Oxford University Press | 592 p. | 1970 (2005) | 9780199274987 | 2026/01/21 |
| 318 | 化学・物質科学 (Chemistry & Materials) | Intermolecular and Surface Forces, Third Edition by Jacob N. Israelachvili (2010-11-15) | Unknown Author | Academic Press | - | - | - | 2026/01/21 |
| 319 | 化学・物質科学 (Chemistry & Materials) | Intermolecular and Surface Forces: Revised Third Edition by Jacob N. Israelachvili (2011-07-22) | Unknown Author | Academic Press | - | - | - | 2026/01/21 |
| 320 | 数学 (Mathematics) | Several Complex Variables III: Geometric Function Theory (Encyclopaedia of Mathematical Sciences Book 9) | G.M. Khenkin (他: L.I. Ronkin) | Springer | - | 2012 | - | 2026/01/21 |
| 321 | 数学 (Mathematics) | Analytic Function Theory of Several Variables: Elements of Oka’s Coherence | Junjiro Noguchi | Springer | 413 p. | 2016 | 9789811002892 | 2026/01/21 |
| 322 | 数学 (Mathematics) | Nevanlinna Theory in Several Complex Variables and Diophantine Approximation (Grundlehren der mathematischen Wissenschaften, 350) | Junjiro Noguchi (他: Jörg Winkelmann) | Springer | 430 p. | 2013 | 9784431545705 | 2026/01/21 |
| 323 | 数学 (Mathematics) | The 1-2-3 of Modular Forms: Lectures at a Summer School in Nordfjordeid, Norway (Universitext) | Jan Hendrik Bruinier (他: Gerard Van Der Geer, Günter Harder, Don Zagier, Kristian Ranestad) | Springer | 276 p. | 2008 | 9783540741176 | 2026/01/21 |
| 324 | 数学 (Mathematics) | Modular Forms: A Classical Approach (Graduate Studies in Mathematics) | Henri Cohen (他: Fredrik Streomberg) | American Mathematical Society | 700 p. | 2017 | 9780821849477 | 2026/01/21 |
| 325 | 数学 (Mathematics) | A First Course in Modular Forms | Fred Diamond (他: Jerry Shurman) | Springer | 466 p. | 2007 (2005) | 9780387232294 | 2026/01/21 |
| 326 | 数学 (Mathematics) | Shigley's Mechanical Engineering Design (Mcgraw-hill Series in Mechanical Engineering) | Richard G. Budynas (他: J. Keith Nisbett) | McGraw-Hill | 1088 p. | 2005 (2006) | 9780073312606 | 2026/01/21 |
| 327 | 数学 (Mathematics) | Operator Algebras and Applications, Vol 2 | David E. Evans (他: Masamichi Takesaki) | Cambridge University Press | 252 p. | 1989 (2011) | 9780511892417 | 2026/01/21 |
| 328 | 数学 (Mathematics) | Operator Algebras and Applications: Volume 1, Structure Theory; K-theory, Geometry and Topology (London Mathematical Society Lecture Note Series Book 135) | David E. Evans (他: Masamichi Takesaki) | Cambridge University Press | 256 p. | 1989 | 9781316705117 | 2026/01/21 |
| 329 | 数学 (Mathematics) | Operator Theory: Operator Algebras and Applications | Summer Research Institute on Operator Theory/Operator Algebras and Applications | American Mathematical Society | 399 p. | 2014 | 9780821894309 | 2026/01/21 |
| 330 | 数学 (Mathematics) | Matrix Groups for Undergraduates (Student Mathematical Library,) | Kristopher Tapp | American Mathematical Society | 166 p. | 2005 | 9780821837856 | 2026/01/21 |
| 331 | 数学 (Mathematics) | Matrix Algebra Useful for Statistics (Wiley Series in Probability and Statistics) | Shayle R. Searle | Wiley-Interscience | 438 p. | 1982 | 9780471866817 | 2026/01/21 |
| 332 | 数学 (Mathematics) | Introduction to Linear and Matrix Algebra | Nathaniel  Johnston | Springer | 498 p. | 2021 | 9783030528102 | 2026/01/21 |
| 333 | 数学 (Mathematics) | Introduction to Banach Algebras, Operators, and Harmonic Analysis | H. Garth Dales | Cambridge University Press | 336 p. | 2003 | 9780521535847 | 2026/01/21 |
| 334 | 数学 (Mathematics) | Completely Bounded Maps and Operator Algebras (Cambridge Studies in Advanced Mathematics, Series Number 78) | Vern I. Paulsen | Cambridge University Press | 314 p. | 2003 | 9780521816694 | 2026/01/21 |
| 335 | 数学 (Mathematics) | Coding the Matrix: Linear Algebra through Computer Science Applications | Philip N. Klein | createspace | 528 p. | 2013 | 9780615856735 | 2026/01/21 |
| 336 | 数学 (Mathematics) | Matrix Groups: An Introduction to Lie Group Theory | Andrew Baker | Springer | 341 p. | 2001 | 9781852334703 | 2026/01/21 |
| 337 | 数学 (Mathematics) | An Introduction to Operator Algebras (Studies in Advanced Mathematics) | Kehe Zhu | CRC Press | 168 p. | 1993 | 9780849378751 | 2026/01/21 |
| 338 | 数学 (Mathematics) | Advanced Linear and Matrix Algebra | Nathaniel  Johnston | Springer | 510 p. | 2021 | 9783030528140 | 2026/01/21 |
| 339 | 数学 (Mathematics) | Lie Groups, Physics, and Geometry: An Introduction for Physicists, Engineers and Chemists | Robert Gilmore | Cambridge University Press | 332 p. | 2008 | 9780521884006 | 2026/01/21 |
| 340 | 数学 (Mathematics) | Lie Groups, Lie Algebras, and Some of Their Applications (Dover Books on Mathematics) | Robert Gilmore | Dover Publications | 608 p. | 1974 (2006) | 9780486445298 | 2026/01/21 |
| 341 | 数学 (Mathematics) | Lie Groups, Lie Algebras, and Representations: An Elementary Introduction | Brian C. Hall | Springer | 250 p. | 2003 | 9780387401225 | 2026/01/21 |
| 342 | 数学 (Mathematics) | Introduction to Lie Algebras and Representation Theory (Graduate Texts in Mathematics, #9) | James E. Humphreys | Springer | 186 p. | 1973 | 9780387900537 | 2026/01/21 |
| 343 | 数学 (Mathematics) | Lattice-Gas Cellular Automata and Lattice Boltzmann Models: An Introduction (Lecture Notes in Mathematics, 1725) | Dieter A. Wolf-Gladrow | Springer | 324 p. | 2000 | 9783540669739 | 2026/01/21 |
| 344 | 数学 (Mathematics) | The Geometry of Numbers (Anneli Lax New Mathematical Library, Series Number 41) | Carl D. Olds (他: Anneli Lax, Giuliana P. Davidoff) | The Mathematical Association of America | - | 2000 (2001) | 9780883856437 | 2026/01/21 |
| 345 | 数学 (Mathematics) | Sphere Packings (Universitext) | Chuanming Zong (他: John Talbot) | Springer | 256 p. | 1999 | 9780387987941 | 2026/01/21 |
| 346 | 数学 (Mathematics) | Sphere Packings, Lattices and Groups (Grundlehren der mathematischen Wissenschaften, 290) | John H. Conway (他: Neil J. A. Sloane) | Springer | 780 p. | 1987 (1998) | 9780387985855 | 2026/01/21 |
| 347 | 数学 (Mathematics) | Perfect Lattices in Euclidean Spaces (Grundlehren der mathematischen Wissenschaften) Softcover reprint of edition by Martinet, Jacques (2010) Paperback | Unknown Author | Springer | - | - | - | 2026/01/21 |
| 348 | 数学 (Mathematics) | Lattice Theory (COLLOQUIUM PUBLICATIONS (AMER MATHEMATICAL SOC)) | Garrett Birkhoff | American Mathematical Society | 420 p. | 1940 | 9780821810255 | 2026/01/21 |
| 349 | 数学 (Mathematics) | Introduction to Louis Michel's lattice geometry through group action (Current Natural Sciences) | Boris Zhilinskii | EDP Sciences | 262 p. | 2015 | 9782759817382 | 2026/01/21 |
| 350 | 生物学・生命科学 (Biology) | General Lattice Theory | George Grätzer | Birkhäuser | 663 p. | 1978 (2002) | 9783764369965 | 2026/01/21 |
| 351 | 数学 (Mathematics) | Lattice Theory: First Concepts and Distributive Lattices (Dover Books on Mathematics) | George Grätzer | Dover Publications | 240 p. | 2009 | 9780486471730 | 2026/01/21 |
| 352 | 数学 (Mathematics) | Exactly Solved Models in Statistical Mechanics (Dover Books on Physics) | Rodney J. Baxter | Dover Publications | 512 p. | 2008 | 9780486462714 | 2026/01/21 |
| 353 | 数学 (Mathematics) | Theta Invariants of Euclidean Lattices and Infinite-Dimensional Hermitian Vector Bundles over Arithmetic Curves (Progress in Mathematics Book 334) | Jean-Benoit Bost | Birkhäuser | - | 2020 | - | 2026/01/21 |
| 354 | 数学 (Mathematics) | The Lattice Boltzmann Method: Principles and Practice (Graduate Texts in Physics) | Timm Krüger (他: Halim Kusumaatmaja, Alexandr Kuzmin, Orest Shardt, Gonçalo Silva, Erlend Magnus Viggen) | Springer | 718 p. | 2016 | 9783319446479 | 2026/01/21 |
| 355 | 数学 (Mathematics) | The Large Scale Structure of Space-Time (Cambridge Monographs on Mathematical Physics) | Stephen W. Hawking (他: G.F.R. Ellis, P.V. Landshoff, D.R. Nelson, D.W. Sciama, S. Weinberg) | Cambridge University Press | 404 p. | 1973 (1975) | 9780521099066 | 2026/01/21 |
| 356 | 数学 (Mathematics) | Modelling Extremal Events: For Insurance and Finance (Stochastic Modelling and Applied Probability) | Paul Embrechts (他: Claudia Klüppelberg, Thomas Mikosch) | Springer | 648 p. | 2004 (1997) | 9783540609315 | 2026/01/21 |
| 357 | 計算機科学・情報科学 (Computer Science) | Industrial Robotics: Technology, Programming, and Applications | Mikell P. Groover (他: Mitchell Weiss, Roger N. Nagel, Nicholas G. Odrey) | McGraw-Hill College | 546 p. | 1986 | 9780070249899 | 2026/01/21 |
| 358 | 計算機科学・情報科学 (Computer Science) | Programming Robots with ROS: A Practical Introduction to the Robot Operating System | Morgan Quigley (他: Brian Gerkey, William D. Smart) | O'Reilly Media | 300 p. | 2015 | 9781449323899 | 2026/01/21 |
| 359 | 計算機科学・情報科学 (Computer Science) | Handbook of Industrial Robotics: Technology and Applications [Feb 01, 2016] Sanfeliu, Alberto and Radecetto, Juan | Compiled by Auris Reference Editorial Board (他: Auris Reference Editorial Board) | AURIS REFERENCE LIMITED | - | 2015 | 9781781544990 | 2026/01/21 |
| 360 | 計算機科学・情報科学 (Computer Science) | Handbook of Industrial Robotics | Shimon Y. Nof | Wiley | 1376 p. | 1985 (1999) | 9780471177838 | 2026/01/21 |
| 361 | 計算機科学・情報科学 (Computer Science) | Industrial Automation and Robotics: An Introduction | A.K. Gupta | Mercury Learning and Information | 400 p. | 2013 (2016) | 9781938549304 | 2026/01/21 |
| 362 | 数学 (Mathematics) | Molecular Symmetry and Group Theory: Approaches in Spectroscopy and Chemical Reactions (De Gruyter Textbook) | R.C. Maurya (他: J.M. Mir) | De Gruyter | 478 p. | 2019 | 9783110634969 | 2026/01/21 |
| 363 | 数学 (Mathematics) | Group Theory Applied to Chemistry (Theoretical Chemistry and Computational Modelling) | Arnout Jozef Ceulemans | Springer | 282 p. | 2013 | 9789400768628 | 2026/01/21 |
| 364 | 物理学 (Physics) | Quantum Dissipative Systems | Ulrich Weiss | World Scientific Pub Co Inc | 448 p. | 1993 (1999) | 9789810240912 | 2026/01/21 |
| 365 | 物理学 (Physics) | General Relativity: The Theoretical Minimum | Leonard Susskind (他: André Cabannes) | Basic Books | 400 p. | 2023 | 9781541601772 | 2026/01/21 |
| 366 | 数学 (Mathematics) | Statistical Mechanics for Athermal Fluctuation: Non-Gaussian Noise in Physics (Springer Theses) | Kiyoshi Kanazawa | Springer | 427 p. | 2017 | - | 2026/01/21 |
| 367 | 物理学 (Physics) | Fluctuations in Physical Systems | Hans L. Pécseli | Cambridge University Press | 202 p. | 2000 | 9780521655927 | 2026/01/21 |
| 368 | 物理学 (Physics) | The Experimental Foundations of Particle Physics 2nd edition by Cahn, Robert N., Goldhaber, Gerson (2009) Hardcover | Unknown Author | Cambridge University Press | - | - | - | 2026/01/21 |
| 369 | 物理学 (Physics) | Physics Laboratory Experiments 6th edition | Jerry D.Wilson (他: Cecilia A. Hernández) | Houghton Mifflin | 221 p. | 2005 | - | 2026/01/21 |
| 370 | 数学 (Mathematics) | The Foundations of Experimental Physics: Unraveling the Premises of Physical and Scientific Knowledge | Jacopo Parravicini | Springer | 303 p. | 2024 | 9783031554513 | 2026/01/21 |
| 371 | 物理学 (Physics) | Experimental Physics: Principles and Practice for the Laboratory | Walter F Smith | CRC Press | 450 p. | 2020 | 9781498778688 | 2026/01/21 |
| 372 | 生物学・生命科学 (Biology) | The Age of Migration: International Population Movements in the Modern World | Stephen Castles (他: Mark J. Miller) | The Guilford Press | 338 p. | 1993 (2003) | 9781572309005 | 2026/01/21 |
| 373 | 生物学・生命科学 (Biology) | International Migration: A Very Short Introduction | Khalid Koser | Oxford University Press | 152 p. | 2007 | 9780199298013 | 2026/01/21 |
| 374 | 物理学 (Physics) | Physical and Ethereal Spaces | George Adams | Rudolph Steiner Press | 71 p. | 1978 | 9780854403288 | 2026/01/21 |
| 375 | 物理学 (Physics) | A Theory Of Ether, Particles And Atoms: Introduction To The Reform Of Modern Physics | Igor Makarov | CreateSpace Independent Publishing Platform | 130 p. | 2007 | 9781441478412 | 2026/01/21 |
| 376 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Practice and Science of Drawing (Dover Art Instruction) | Harold Speed | Dover Publications | 296 p. | 1913 (1972) | 9780486228709 | 2026/01/21 |
| 377 | 物理学 (Physics) | The Theory of Open Quantum Systems | Heinz-Peter Breuer (他: Francesco Petruccione) | Oxford University Press | 648 p. | 2002 | 9780198520634 | 2026/01/21 |
| 378 | 数学 (Mathematics) | Open Quantum Systems: Foundations and Theory (Graduate Texts in Physics) | Bassano Vacchini | Springer | 444 p. | 2024 | 9783031582172 | 2026/01/21 |
| 379 | 数学 (Mathematics) | Noise in Nonlinear Dynamical Systems: Volume 1, Theory of Continuous Fokker-Planck Systems | Frank Moss (他: P. V. E. McClintock) | Cambridge University Press | 384 p. | 1989 | 9780521352284 | 2026/01/21 |
| 380 | 数学 (Mathematics) | Dissipative Systems Analysis and Control: Theory and Applications (Communications and Control Engineering) | Bernard Brogliato (他: Rogelio Lozano, Olav Egeland, Bernhard Maschke) | Springer | - | 2006 | 9781846285172 | 2026/01/21 |
| 381 | 物理学 (Physics) | Interacting Quantum-Dissipative Tunnelling Systems: Analytic derivation of the Caldeira-Leggett Hamiltonian from a microscopic model | Babak Bayani | Südwestdeutscher Verlag für Hochschulschriften | 124 p. | 2012 | 9783838132075 | 2026/01/21 |
| 382 | 数学 (Mathematics) | Dermatologic Clinics: Skin Signs of Internal Disease | Guest Editors | W.B. Saunders | - | 1989 | - | 2026/01/21 |
| 383 | 数学 (Mathematics) | Handbook of Data Visualization (Springer Handbooks of Computational Statistics) | Chun-Houh Chen (他: Antony Unwin, Wolfgang Karl Härdle) | Springer | 949 p. | 2007 | 9783540330363 | 2026/01/21 |
| 384 | 数学 (Mathematics) | The Art of Writing Reasonable Organic Reaction Mechanisms | Robert B. Grossman | Springer | 376 p. | 2002 | 9780387954684 | 2026/01/21 |
| 385 | 数学 (Mathematics) | Quantum Theory of Chemical Reactions II: Solvent Effect, Reaction Mechanisms, Photochemical Processes | R. Daudel (他: Alberte Pullman, Lionel Salem, A. Veillard) | Springer | 334 p. | 1980 (2012) | 9789401097185 | 2026/01/21 |
| 386 | 数学 (Mathematics) | Quantum Theory of Chemical Reactions I: Collision Theory, Reaction Path, Static Indices | R. Daudel (他: Alberte Pullman, Lionel Salem, A. Veillard) | Springer | 256 p. | 1979 (2011) | 9789400995185 | 2026/01/21 |
| 387 | 物理学 (Physics) | Quantum Mechanical Tunneling in Chemical Physics | Hiroki Nakamura (他: Gennady Mil'nikov) | CRC Press | 226 p. | 2013 | 9781466507319 | 2026/01/21 |
| 388 | 化学・物質科学 (Chemistry & Materials) | Molecular Reaction Dynamics | Raphael D. Levine | Cambridge University Press | - | 2005 | 9780521842761 | 2026/01/21 |
| 389 | 化学・物質科学 (Chemistry & Materials) | Chemical Kinetics and Reaction Mechanisms (Mcgraw-Hill Series in Advanced Chemistry) | James H. Espenson | Mcgraw-Hill College | 218 p. | 1981 | 9780070196674 | 2026/01/21 |
| 390 | 物理学 (Physics) | Advances in Quantum Chemistry, Volume 31: Quantum Systems in Chemistry and Physics Part I | Per-Olov Löwdin (他: Stephen     Wilson, Roy McWeeny, Jean Maruani, John R. Sabin, Michael C. Zerner, Erkki J. Brändas, P.J. Grout, Yves G. Smeyers) | Academic Press | 345 p. | 1998 | 9780120348312 | 2026/01/21 |
| 391 | 物理学 (Physics) | Advances in Quantum Chemistry, Volume 28: Recent Advances in Computational Quantum Chemistry | Per-Olov Löwdin (他: John R. Sabin) | Academic Press | 370 p. | 1997 | 9780120348282 | 2026/01/21 |
| 392 | 物理学 (Physics) | Advances in Quantum Chemistry, Volume 57: Theory of Confined Quantum Systems - Part One | John R. Sabin (他: Erkki J. Brändas) | Academic Press | 690 p. | 2009 | 9780123747648 | 2026/01/21 |
| 393 | 物理学 (Physics) | Advances in Quantum Chemistry, Volume 33: Advances in Density Functional Theory | John R. Sabin (他: Erkki J. Brändas, Michael C. Zerner, Per-Olov Löwdin, Jorge M. Seminario) | Elsevier Science & Technology | 398 p. | 1998 (1999) | 9781281739216 | 2026/01/21 |
| 394 | 化学・物質科学 (Chemistry & Materials) | Advanced Organic Chemistry: Reactions, Mechanisms, and Structure | Jerry March | Wiley-Interscience | 1512 p. | 1977 (1992) | 9780471601807 | 2026/01/21 |
| 395 | 数学 (Mathematics) | Causal Inference in Statistics: A Primer | Judea Pearl | Wiley | 160 p. | 2016 | 9781119186861 | 2026/01/21 |
| 396 | 数学 (Mathematics) | Targeted Learning: Causal Inference for Observational and Experimental Data (Springer Series in Statistics) | Mark van der Laan (他: Sherri Rose) | Springer | 700 p. | 2011 | 9781441997814 | 2026/01/21 |
| 397 | 数学 (Mathematics) | Strategic Brand Managment: Building, Measuring, and Managing Brand Equity | Kevin Lane Keller | by Kevin Keller (Author) | 600 p. | 2013 | 9780273779414 | 2026/01/20 |
| 398 | 生物学・生命科学 (Biology) | Generation to Generation | Kelin E. Gersick (他: John A. Davis, Marion McCollom Hampton, Ivan Lansberg) | Harvard Business Review Press | 320 p. | 1997 | 9780875845555 | 2026/01/20 |
| 399 | 生物学・生命科学 (Biology) | Borrowed from Your Grandchildren: The Evolution of 100-Year Family Enterprises | Dennis T. Jaffe | Wiley | 400 p. | 2020 | 9781119573807 | 2026/01/20 |
| 400 | 数学 (Mathematics) | Dynamical Theories of Brownian Motion (Mathematical Notes) | Edward Nelson | Princeton University Press | 148 p. | 1967 | 9780691079509 | 2026/01/20 |
| 401 | 数学 (Mathematics) | Brownian Ratchets: From Statistical Physics to Bio and Nano-motors | David Cubero (他: Ferruccio Renzoni) | Cambridge University Press | 200 p. | 2016 | 9781107063525 | 2026/01/20 |
| 402 | 計算機科学・情報科学 (Computer Science) | Neuromorphic Devices for Brain-Inspired Computing: Artificial Intelligence, Perception and Robotics | Qing Wan (他: Yi Shi) | Wiley-Vch | - | 2022 | 9783527835294 | 2026/01/20 |
| 403 | 神経科学・認知科学 (Neuroscience) | Event-Based Neuromorphic Systems | Shih-Chii Liu (他: Tobi Delbruck, Giacomo Indiveri, Adrian Whatley, Rodney Douglas) | Wiley | 400 p. | 2014 | - | 2026/01/20 |
| 404 | 物理学 (Physics) | Artificial Intelligence of Neuromorphic Systems: From Digital, Analogue, Quantum, and Brain-Oriented Computing to Hybrid AI (World Scientific Series on Nonlinear Science Series A Book 99) | Klaus Mainzer | World Scientific Publishing Company | 435 p. | 2024 | 9789811290091 | 2026/01/20 |
| 405 | 数学 (Mathematics) | The Magic Theorem: A Greatly-Expanded, Much-Abridged Edition of The Symmetries of Things (AK Peters/CRC Recreational Mathematics Series) | John H. Conway (他: Heidi Burgiel, Chaim Goodman-Strauss) | A K Peters/CRC Press | 190 p. | 2025 | 9781032182735 | 2026/01/20 |
| 406 | 数学 (Mathematics) | Understanding Cultures through Their Key Words: English, Russian, Polish, German, and Japanese (Oxford Studies in Anthropological Linguistics) | Anna Wierzbicka | Oxford University Press | 328 p. | 1997 | 9780195088366 | 2026/01/20 |
| 407 | 数学 (Mathematics) | The Stanford Mathematics Problem Book: With Hints and Solutions (Dover Books on Mathematics) | George Pólya (他: Jeremy Kilpatrick) | Dover Publications | 80 p. | 1974 (2009) | 9780486469249 | 2026/01/20 |
| 408 | 数学 (Mathematics) | The Fourth Dimension: Sacred Geometry, Alchemy & Mathematics (CW 324a) | Rudolf Steiner (他: Catherine E. Creeger, David       Booth) | SteinerBooks | 256 p. | 2001 | 9780880104722 | 2026/01/20 |
| 409 | 数学 (Mathematics) | String Theory and M-Theory: A Modern Introduction | Katrin Becker (他: Melanie Becker, John H. Schwarz) | Cambridge University Press | 739 p. | 2006 (2007) | 9780521860697 | 2026/01/20 |
| 410 | 数学 (Mathematics) | Statistical Mechanics of Nonequilibrium Liquids by Denis J. Evans (2014-08-07) | Unknown Author | Cambridge University Press | - | 1844 | - | 2026/01/20 |
| 411 | 数学 (Mathematics) | Statistical Mechanics of Nonequilibrium Liquids | Denis J. Evans (他: Gary Morriss) | Cambridge University Press | - | 2008 | 9780511402500 | 2026/01/20 |
| 412 | 数学 (Mathematics) | Statistical Mechanics of Nonequilibrium Liquids | Denis J. Evans | ANU E Press | 318 p. | 1997 (2010) | 9781921313226 | 2026/01/20 |
| 413 | 生物学・生命科学 (Biology) | Religion Explained: The Evolutionary Origins of Religious Thought | Pascal Boyer | Basic Books | 375 p. | 2001 (2002) | 9780465006960 | 2026/01/20 |
| 414 | 物理学 (Physics) | Quantum Computing Since Democritus | Scott Aaronson | Cambridge University Press | 370 p. | 2013 | 9780521199568 | 2026/01/20 |
| 415 | 生物学・生命科学 (Biology) | The Peaceful Pill Handbook | Philip Nitschke & Fiona Stewart | Exit International USA | 375 p. | 2017 | 9780975833926 | 2026/01/20 |
| 416 | 生物学・生命科学 (Biology) | The Peaceful Pill Handbook | Philip Nitschke (他: Fiona Stewart) | Exit International US | 211 p. | 2016 | 9780978878818 | 2026/01/20 |
| 417 | 物理学 (Physics) | Gravitation | Charles W. Misner (他: Kip S. Thorne, John Archibald Wheeler) | W. H. Freeman | 1279 p. | 1973 | 9780716703440 | 2026/01/20 |
| 418 | 数学 (Mathematics) | How to Solve It: A New Aspect of Mathematical Method (Princeton Science Library) | George Pólya (他: John H. Conway) | Princeton University Press | 288 p. | 1944 (2015) | 9780691119663 | 2026/01/20 |
| 419 | 数学 (Mathematics) | Handbook of Heuristics | Rafael Martí (他: Panos M. Pardalos, Mauricio G. C. Resende) | Springer | 1406 p. | 2017 (2018) | 9783319071237 | 2026/01/20 |
| 420 | 生物学・生命科学 (Biology) | Facial Diagnosis of Cell Salt Deficiencies: A User's Guide | David R. Card | Kalindi Press | 176 p. | 2004 | 9781935826187 | 2026/01/20 |
| 421 | 物理学 (Physics) | CLASSICAL AND QUANTUM DISSIPATIVE SYSTEMS | Mohsen Razavy | Imperial College Press | 334 p. | 2006 | 9781860945250 | 2026/01/20 |
| 422 | 化学・物質科学 (Chemistry & Materials) | Chemical Dynamics in Condensed Phases: Relaxation, Transfer, and Reactions in Condensed Molecular Systems (Oxford Graduate Texts) | Abraham Nitzan | Oxford University Press | 742 p. | 2006 | 9780198529798 | 2026/01/20 |
| 423 | 数学 (Mathematics) | Advanced Engineering Mathematics, 10e Student Solutions Manual and Study Guide, Volume 2: Chapters 13 - 25 | Herbert Kreyszig (他: Erwin Kreyszig) | Wiley | 312 p. | 2012 (2015) | 9781118266700 | 2026/01/20 |
| 424 | 計算機科学・情報科学 (Computer Science) | The Human Use of Human Beings: Cybernetics and Society | Norbert Wiener | Grand Central Publishing | 199 p. | 1949 (1988) | 9780306803208 | 2026/01/20 |
| 425 | 数学 (Mathematics) | Transcranial Magnetic Stimulation: A Neurochronometrics of Mind | Vincent Walsh (他: Alvaro Pascual-Leone, Stephen M. Kosslyn) | Bradford Books | 319 p. | 2003 (2005) | 9780262731744 | 2026/01/20 |
| 426 | 神経科学・認知科学 (Neuroscience) | Time and Memory: Issues in Philosophy and Psychology (Consciousness & Self-Consciousness Series) | Christoph Hoerl (他: Teresa McCormack) | Clarendon Press | 434 p. | 2001 | 9780198250364 | 2026/01/20 |
| 427 | 数学 (Mathematics) | The Fractal Geometry of the Brain (Springer Series in Computational Neuroscience) | Antonio Di Ieva | Springer | 607 p. | 2016 | 9781493939930 | 2026/01/20 |
| 428 | 数学 (Mathematics) | The Quantum Theory―Origins and Ideas: A Historical Primer for Physics Students (History of Physics) | Carl S. Helrich | Springer | 251 p. | 2021 | 9783030792671 | 2026/01/20 |
| 429 | 物理学 (Physics) | The Physics Book: Big Ideas Simply Explained | D.K. Publishing (他: Jim Al-Khalili, Ben Still) | Dorling Kindersley Ltd | 336 p. | 2020 | 9780241412725 | 2026/01/20 |
| 430 | 計算機科学・情報科学 (Computer Science) | The Oxford Handbook of Cyber Security | Paul Cornish | Oxford University Press | 890 p. | 2022 | 9780198800682 | 2026/01/20 |
| 431 | 神経科学・認知科学 (Neuroscience) | The Orbitofrontal Cortex | Edmund Rolls | Oxford University Press | 318 p. | 2019 | 9780198845997 | 2026/01/20 |
| 432 | 計算機科学・情報科学 (Computer Science) | The Nature of Computation | Cristopher Moore (他: Stephan Mertens) | Oxford University Press, USA | 1032 p. | 2011 | 9780199233212 | 2026/01/20 |
| 433 | 神経科学・認知科学 (Neuroscience) | The Matter With Things: Our Brains, Our Delusions, and the Unmaking of the World | Iain McGilchrist | Perspectiva | 1500 p. | 2021 | 9781914568060 | 2026/01/20 |
| 434 | 生物学・生命科学 (Biology) | The Digital Agricultural Revolution: Innovations and Challenges in Agriculture through Technology Disruptions | Roheet Bhatnagar (他: Nitin Kumar Tripathi, Nitu Bhatnagar, Chandan Kumar Panda) | Wiley-Scrivener | 465 p. | 2022 | 9781119823445 | 2026/01/20 |
| 435 | 生物学・生命科学 (Biology) | The Biology of Desire: Why Addiction Is Not a Disease | Marc  Lewis | PublicAffairs | 256 p. | 2015 | 9781610394376 | 2026/01/20 |
| 436 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Art and Science of Brief Psychotherapies: A Practitioner's Guide (Corecompetencies in Psychotherapy) | Mantosh J. Dewan (他: Brett N. Steenbarger, Roger P. Greenberg) | American Psychiatric Publishing | 397 p. | 2017 | 9781615370795 | 2026/01/20 |
| 437 | 生物学・生命科学 (Biology) | TEXTBOOK OF STRUCTURAL BIOLOGY | Al Anders Liljas Et (他: Lars Liljas, Jure Piskur) | World Scientific Publishing Company | 580 p. | 2008 | 9789812772077 | 2026/01/20 |
| 438 | 数学 (Mathematics) | Technical Analysis of the Financial Markets: A Comprehensive Guide to Trading Methods and Applications | John J. Murphy | New York Institute of Finance | 576 p. | 1999 | 9780735200661 | 2026/01/20 |
| 439 | 数学 (Mathematics) | Systems Medicine: Physiological Circuits and the Dynamics of Disease (Chapman & Hall/CRC Computational Biology Series) | Uri Alon | Chapman and Hall/CRC | 256 p. | 2023 | 9781032412283 | 2026/01/20 |
| 440 | 神経科学・認知科学 (Neuroscience) | Super Consciousness: The Quest for the Peak Experience | Colin Wilson | Watkins | 224 p. | 2007 (2009) | 9781906787097 | 2026/01/20 |
| 441 | 神経科学・認知科学 (Neuroscience) | Subjective Time: The Philosophy, Psychology, and Neuroscience of Temporality | Valtteri Arstila (他: Dan Lloyd, William James, Holly Andersen, James Mensch, Edmund Husserl, Shaun Gallagher, Dan Zahavi, Barry Dainton, Ian Phillips, Niko A. Busch, Rufin VanRullen, Alex O. Holcombe, Konstantinos Moutoussis, Bruno Mölder, Ernst Pöppel, Yan Bao, Thomas Fraps, John Wearden, Alan o'Donoghue, Ruth Ogden, Catharine Montgomery, Dean V. Buonomano, Ryota Kanai, Jeremie Jozefowiez, Armando Machado, John E. R. Staddon, Piotr Jaśkowski, Argiro Vatakis, Georgios Papadelis, Agnieszka Wykowska, Kielan Yarrow, Sukhvinder S. Obhi, Sylvie Droit-Volet, Marc Wittmann, Valdas Noreika, Christine M. Falter, Till M. Wagner, Allison N. Kurti, Dale N. Swanton, Matthew S. Matell, Peter Naish, Melissa J. Allman, Bin Yin, Warren H. Meck) | The MIT Press | 688 p. | 2014 | 9780262019941 | 2026/01/20 |
| 442 | 計算機科学・情報科学 (Computer Science) | Stochastic Modelling for Systems Biology, Third Edition (Chapman & Hall/CRC Computational Biology Series) | Darren J Wilkinson | Chapman and Hall/CRC | 404 p. | 2020 | 9780367656935 | 2026/01/20 |
| 443 | 計算機科学・情報科学 (Computer Science) | Solutions Manual to Accompany Nonlinear Programming: Theory and Algorithms | Mokhtar S. Bazaraa | Wiley-Interscience | 174 p. | 2013 (2014) | 9781118762325 | 2026/01/20 |
| 444 | 数学 (Mathematics) | Safety of Biologics Therapy: Monoclonal Antibodies, Cytokines, Fusion Proteins, Hormones, Enzymes, Coagulation Proteins, Vaccines, Botulinum Toxins | Brian A. Baldo | Springer | 631 p. | 2016 | 9783319304700 | 2026/01/20 |
| 445 | 自然科学・複雑系 (Natural Science & Complex Systems) | Real Magic: Ancient Wisdom, Modern Science, and a Guide to the Secret Power of the Universe | Dean Radin | Harmony | 222 p. | 2018 | 9781524758820 | 2026/01/20 |
| 446 | 物理学 (Physics) | Quantum Networking | Rodney Van Meter | Wiley-Iste | 357 p. | 2014 | 9781306772327 | 2026/01/20 |
| 447 | 物理学 (Physics) | Quantum Machine Learning: Quantum Algorithms and Neural Networks (Quantum Computing) | Pethuru Raj (他: Houbing Herbert Song, Dac-Nhuong Le, Narayan Vyas) | De Gruyter | 335 p. | 2024 | 9783111342092 | 2026/01/20 |
| 448 | 物理学 (Physics) | Quantum Effects in Biology | Masoud Mohseni (他: Yasser Omar, Gregory S. Engel, Martin B. Plenio) | Cambridge University Press | 416 p. | 2014 | 9781107010802 | 2026/01/20 |
| 449 | 生物学・生命科学 (Biology) | Plant Cell Culture: The Basics (The Basics Garland Science) | D.E. Evans (他: J.O.D. Coleman, Anne Kearns) | Taylor &amp; Francis | - | 2003 | 9781859963203 | 2026/01/20 |
| 450 | 数学 (Mathematics) | Philosophy and Psychology of Time (Studies in Brain and Mind, 9) | Bruno Mölder (他: Valtteri Arstila, Peter Ohrstrom) | Springer | 277 p. | 2015 | 9783319221946 | 2026/01/20 |
| 451 | 生物学・生命科学 (Biology) | Origination of Organismal Form: Beyond the Gene in Developmental and Evolutionary Biology (Vienna Series in Theoretical Biology) | Gerd B. Müller (他: Stuart A. Newman) | Bradford Books | 368 p. | 2003 | 9780262134194 | 2026/01/20 |
| 452 | 数学 (Mathematics) | Optimization Theory and Methods: Nonlinear Programming (Springer Optimization and Its Applications, Vol. 1) | Wenyu Sun (他: Ya-xiang Yuan) | Springer | 699 p. | 2006 | 9780387249759 | 2026/01/20 |
| 453 | 数学 (Mathematics) | Open Dialogue for Psychosis (The International Society for Psychological and Social Approaches to Psychosis Book Series) | Nick Putman (他: Brian Martindale) | Routledge | 314 p. | 2021 | 9780815392323 | 2026/01/20 |
| 454 | 数学 (Mathematics) | Nonlinear Time Series Analysis | Holger Kantz (他: Thomas Schreiber) | Cambridge University Press | 388 p. | 1997 (2003) | 9780521529020 | 2026/01/20 |
| 455 | 計算機科学・情報科学 (Computer Science) | Nonlinear Programming | Dimitri P. Bertsekas | Athena Scientific | - | 1995 (1999) | 9781886529007 | 2026/01/20 |
| 456 | 物理学 (Physics) | Nonlinear Optical Cavity Dynamics: From Microresonators to Fiber Lasers | Philippe Grelu | WILEY | 456 p. | 2016 | 9783527413324 | 2026/01/20 |
| 457 | 数学 (Mathematics) | New Handbook of Mathematical Psychology: Volume 2, Modeling and Measurement (Cambridge Handbooks in Psychology) | William H. Batchelder (他: Hans Colonius, Ehtibar N. Dzhafarov) | Cambridge University Press | 476 p. | 2018 | 9781108632461 | 2026/01/20 |
| 458 | 数学 (Mathematics) | New Handbook of Mathematical Psychology: Volume 1, Foundations and Methodology (Cambridge Handbooks in Psychology) | William H. Batchelder (他: Hans Colonius, Ehtibar N. Dzhafarov, Jay Myung) | Cambridge University Press | 1186 p. | 2016 | 9781316587522 | 2026/01/20 |
| 459 | 計算機科学・情報科学 (Computer Science) | Neural Networks and Brain Function | Edmund T. Rolls (他: Alessandro Treves) | Oxford University Press | 428 p. | 1997 | 9780198524335 | 2026/01/20 |
| 460 | 物理学 (Physics) | Modern Condensed Matter Physics | Steven M Girvin (他: Kun Yang) | Cambridge University Press | 718 p. | 2019 | 9781108573474 | 2026/01/20 |
| 461 | 数学 (Mathematics) | Mathematical Handbook: Elementary Mathematics | M. Vygodsky (他: George Yankovsky) | Central Books Ltd | 422 p. | 1987 | 9780714725581 | 2026/01/20 |
| 462 | 数学 (Mathematics) | Mathematical Handbook: Elementary Mathematics | M. Vygodsky (他: George Yankovsky) | Mir Publishers. Moscow | 422 p. | 1979 | - | 2026/01/20 |
| 463 | 数学 (Mathematics) | Machine Learning in Biological Sciences: Updates and Future Prospects | Shyamasree Ghosh | Springer | 357 p. | 2022 | 9789811688805 | 2026/01/20 |
| 464 | 数学 (Mathematics) | The Language of Mathematics: Making the Invisible Visible | Keith Devlin | Holt Paperbacks | 368 p. | 1998 (2000) | 9780805072549 | 2026/01/20 |
| 465 | 生物学・生命科学 (Biology) | Systems Biology: A Textbook by Edda Klipp (2016-05-04) | Unknown Author | Wiley VCH | - | - | - | 2026/01/20 |
| 466 | 数学 (Mathematics) | IoT and AI in Agriculture: Self- sufficiency in Food Production to Achieve Society 5.0 and SDG's Globally | Tofael Ahamed | Springer | 478 p. | 2024 | 9789811981159 | 2026/01/20 |
| 467 | 数学 (Mathematics) | Growth Factors and Cytokines in Skeletal Muscle Development, Growth, Regeneration and Disease (Advances in Experimental Medicine and Biology Book 900) | Jason White (他: Gayle Smythe) | Springer | 415 p. | 2016 | - | 2026/01/20 |
| 468 | 数学 (Mathematics) | Foundations of Probabilistic Programming | Gilles Barthe (他: Joost-Pieter Katoen, Alexandra    Silva) | Cambridge University Press | 582 p. | 2020 | 9781108805742 | 2026/01/20 |
| 469 | 物理学 (Physics) | Entangled Minds: Extrasensory Experiences in a Quantum Reality (A Study on Parapsychology) | Dean Radin | Paraview Pocket Books | 368 p. | 2006 | 9781416516774 | 2026/01/20 |
| 470 | 生物学・生命科学 (Biology) | Digestive System Diseases: Stem Cell Mechanisms and Therapies (Stem Cell Biology and Regenerative Medicine) | Maria Gazouli (他: George E. Theodoropoulos) | Humana | 200 p. | 2019 | 9783030119645 | 2026/01/20 |
| 471 | 物理学 (Physics) | Design A Healthy Home: 100 ways to transform your space for physical and mental wellbeing | Oliver Heath | DK | 192 p. | 2021 | 9780744038033 | 2026/01/20 |
| 472 | 神経科学・認知科学 (Neuroscience) | Dark Persuasion: A History of Brainwashing from Pavlov to Social Media | Joel E. Dimsdale | Yale University Press | 304 p. | 2021 | 9780300247176 | 2026/01/20 |
| 473 | 数学 (Mathematics) | Dark and Bright Mathematics: Hidden Harmony in Art, History and Culture (Copernicus Books) | Dirk Huylebrouck | Birkhäuser | 258 p. | 2023 | 9783031362545 | 2026/01/20 |
| 474 | 数学 (Mathematics) | Cytokines, Stress, and Depression (Advances in Experimental Medicine and Biology, 461) | Robert Dantzer (他: Emmanuelle E. Wollmann, Raz Yirmiya) | Springer | 350 p. | 1999 | 9780306461354 | 2026/01/20 |
| 475 | 数学 (Mathematics) | Cytokine Storm Syndrome | Randy Q. Cron (他: Edward M. Behrens) | Springer | 1222 p. | 2019 | 9783030220945 | 2026/01/20 |
| 476 | 生物学・生命科学 (Biology) | Cytokine Protocols (Methods in Molecular Biology, 820) | Marc De Ley | Humana | 252 p. | 2003 (2011) | 9781617794384 | 2026/01/20 |
| 477 | 数学 (Mathematics) | Cytokine Frontiers: Regulation of Immune Responses in Health and Disease (2013-10-29) | Unknown Author | Springer | - | - | - | 2026/01/20 |
| 478 | 生物学・生命科学 (Biology) | Cytokine Bioassays: Methods and Protocols (Methods in Molecular Biology) (2014-06-07) | Unknown Author | Humana Press; 2014 edition (2014-06-07) | - | - | - | 2026/01/20 |
| 479 | 数学 (Mathematics) | Cybernetics for the 21st Century Vol. 1: Epistemological Reconstruction (Philosophy, Art and Technology) | Andrew Pickering (他: Yuk Hui, Katherine Hayles) | Hanart Press | 274 p. | 2024 | 9789887026808 | 2026/01/20 |
| 480 | 数学 (Mathematics) | Culinary Math by Linda Blocker (2002-01-14) | Linda Blocker;Julia Hill | John Wiley & Sons | - | - | - | 2026/01/20 |
| 481 | 数学 (Mathematics) | Crypto Technical Analysis: Your One-Stop Guide to Investing, Trading, and Profiting in Crypto with Technical Analysis | Alan John | - | 525 p. | 2021 | - | 2026/01/20 |
| 482 | 数学 (Mathematics) | The Comprehensive List of Mathematical Symbols | Math Vault | Math Vault Publishing | 76 p. | 2020 | - | 2026/01/20 |
| 483 | 数学 (Mathematics) | Complex Systems: Chaos and Beyond, A Constructive Approach with Applications in Life Sciences | Kunihiko Kaneko (他: Ichiro Tsuda) | Springer | 273 p. | 2000 | 9783540672029 | 2026/01/20 |
| 484 | 数学 (Mathematics) | Charting and Technical Analysis | Fred McAllen | McAllen | 277 p. | 2010 (2012) | - | 2026/01/20 |
| 485 | 数学 (Mathematics) | Chaos and Complexity in Psychology: The Theory of Nonlinear Dynamical Systems | Stephen J. Guastello (他: Matthijs Koopmans, David Pincus) | Cambridge University Press | 552 p. | 2008 | 9780521887267 | 2026/01/20 |
| 486 | 数学 (Mathematics) | Biological Physics of the Developing Embryo | Gabor Forgacs (他: Stuart A. Newman) | Cambridge University Press | 346 p. | 2005 | 9780521783378 | 2026/01/20 |
| 487 | 生物学・生命科学 (Biology) | Biochemistry and Molecular Biology of Plants | Bob B. Buchanan (他: Wilhelm Gruissem, Russell L. Jones) | Wiley | 1260 p. | 2015 | - | 2026/01/20 |
| 488 | 数学 (Mathematics) | Milestones in Analog and Digital Computing | Herbert Bruderer | Springer | 2083 p. | 2021 | 9783030409739 | 2026/01/20 |
| 489 | 計算機科学・情報科学 (Computer Science) | Analog and Hybrid Computer Programming | Bernd Ulmann | de Gruyter | 300 p. | 2020 | 9783110662078 | 2026/01/20 |
| 490 | 数学 (Mathematics) | An Introduction to Stochastic Thermodynamics: From Basic to Advanced (Fundamental Theories of Physics Book 212) | Naoto Shiraishi | Springer | 710 p. | 2023 | 9789811981869 | 2026/01/20 |
| 491 | 数学 (Mathematics) | Advanced Quantum Condensed Matter Physics: One-Body, Many-Body, and Topological Perspectives | Michael El-Batanouny | Cambridge University Press | 850 p. | 2020 | 9781108480840 | 2026/01/20 |
| 492 | 数学 (Mathematics) | Handbook of Mathematical Functions: with Formulas, Graphs, and Mathematical Tables (Dover Books on Mathematics) | Milton Abramowitz (他: Irene A. Stegun) | Dover Publications | 1072 p. | 1965 | 9780486612720 | 2026/01/20 |
| 493 | 数学 (Mathematics) | A History of Mathematical Notations (Dover Books on Mathematics) | Florian Cajori | Dover Publications | 820 p. | 1974 (2011) | 9780486677668 | 2026/01/20 |
| 494 | 自然科学・複雑系 (Natural Science & Complex Systems) | A Guide to Temporal Networks (Series on Complexity Science) by Naoki Masuda (2016-11-11) | Unknown Author | WSPC (Europe) | - | - | - | 2026/01/20 |
| 495 | 数学 (Mathematics) | A First Course in Statistical Programming with R | W. John Braun (他: Duncan J. Murdoch) | Cambridge University Press | 172 p. | 2007 (2008) | 9780521694247 | 2026/01/20 |
| 496 | 数学 (Mathematics) | A First Course in Continuum Mechanics (Cambridge Texts in Applied Mathematics, Series Number 42) | Óscar González (他: Andrew M. Stuart) | Cambridge University Press | 414 p. | 2008 | 9780521714242 | 2026/01/20 |
| 497 | 数学 (Mathematics) | A Book of Abstract Algebra | Charles C. Pinter | Dover Publications | 400 p. | 1982 (2010) | 9780486474175 | 2026/01/20 |
| 498 | 数学 (Mathematics) | Wave Packet Analysis of Feynman Path Integrals (Lecture Notes in Mathematics, 2305) | Fabio Nicola (他: S. Ivan Trapasso) | Springer | 227 p. | 2022 | 9783031061851 | 2026/01/20 |
| 499 | 数学 (Mathematics) | Wave Packet Analysis (CBMS Regional Conference Series in Mathematics) | Christoph Thiele | Amer Mathematical Society | 86 p. | 2006 | 9780821836613 | 2026/01/20 |
| 500 | 数学 (Mathematics) | Stochastic Resonance: Theory and Applications | Bruno Andò | Springer | 235 p. | 2000 | 9780792377795 | 2026/01/20 |
| 501 | 数学 (Mathematics) | Stochastic Dynamics, Filtering And Optimization | Debasish Roy And G. Visweswara Rao (他: G. Visweswara Rao) | Cambridge India | 742 p. | 2017 | 9781107182646 | 2026/01/20 |
| 502 | 化学・物質科学 (Chemistry & Materials) | STOCHASTIC DYNAMICS OF REACTING BIOMOLECULES | Werner Ebeling (他: Lutz Schimansky-Geier, Yuri M. Romanovsky) | World Scientific Pub Co Inc | 344 p. | 2003 | 9789812381620 | 2026/01/20 |
| 503 | 数学 (Mathematics) | Stochastic Dynamics for Systems Biology (Chapman & Hall/CRC Mathematical Biology Series) | Christian Mazza | Chapman and Hall/CRC | 274 p. | 2014 | 9781466514935 | 2026/01/20 |
| 504 | 数学 (Mathematics) | The Probabilistic World: A Fundamental Approach to Quantum Mechanics and Probabilistic Computing (Fundamental Theories of Physics, 220) | Christof Wetterich | Springer | 568 p. | 2025 | 9783031832123 | 2026/01/20 |
| 505 | 数学 (Mathematics) | The History of Statistics: The Measurement of Uncertainty before 1900 | Stigler | Belknap Press | 428 p. | 1986 (1990) | 9780674403413 | 2026/01/20 |
| 506 | 数学 (Mathematics) | Statistics on the Table: The History of Statistical Concepts and Methods | Stigler | Harvard University Press | 502 p. | 1999 (2002) | 9780674009790 | 2026/01/20 |
| 507 | 数学 (Mathematics) | Selected Papers of Hirotugu Akaike (Springer Series in Statistics) | Emanuel Parzen (他: Kunio Tanabe, Genshiro Kitagawa) | Springer | 442 p. | 1997 (2012) | 9781461272489 | 2026/01/20 |
| 508 | 数学 (Mathematics) | Selected Papers of Hirotugu Akaike (Springer Series in Statistics) | Genshiro Kitagawa | Springer | 442 p. | 1997 | 9780387983554 | 2026/01/20 |
| 509 | 数学 (Mathematics) | Introduction to Modern Statistical Mechanics | David     Chandler | Oxford University Press | 288 p. | 1987 | 9780195042764 | 2026/01/20 |
| 510 | 数学 (Mathematics) | Classic Topics on the History of Modern Mathematical Statistics: From Laplace to More Recent Times | Prakash Gorroochurn | Wiley | 776 p. | 2016 | 9781119127925 | 2026/01/20 |
| 511 | 自然科学・複雑系 (Natural Science & Complex Systems) | Spin Glasses and Complexity (Primers in Complex Systems) | Daniel L. Stein (他: Charles M. Newman) | Princeton University Press | 336 p. | 2012 (2013) | 9780691147338 | 2026/01/20 |
| 512 | 自然科学・複雑系 (Natural Science & Complex Systems) | Spin Glass Theory and Far Beyond | Charbonneau Patrick (他: Enzo Marinari, Giorgio Parisi, Federico Ricci-Tersenghi, Gabriele Sicuro, Francesco Zamponi) | World Scientific Pub Co Inc | 727 p. | 2023 | 9789811273919 | 2026/01/20 |
| 513 | 数学 (Mathematics) | Sojourns in Probability Theory and Statistical Physics - III: Interacting Particle Systems and Random Walks, A Festschrift for Charles M. Newman (Springer ... in Mathematics & Statistics Book 300) | Vladas Sidoravicius | Springer | - | 2019 | - | 2026/01/20 |
| 514 | 物理学 (Physics) | Information, Physics, and Computation (Oxford Graduate Texts) | Marc Mézard (他: Andrea Montanari) | Oxford University Press | 569 p. | 2009 | 9780198570837 | 2026/01/20 |
| 515 | 数学 (Mathematics) | The Cambridge Dictionary of Statistics | Brian S. Everitt | Cambridge University Press | 444 p. | 1998 (2006) | 9780521690270 | 2026/01/20 |
| 516 | 数学 (Mathematics) | Feynman-Kac Formulae: Genealogical and Interacting Particle Systems with Applications (Probability and Its Applications) | Piere Del Moral | Springer | 574 p. | 2004 | 9780387202686 | 2026/01/20 |
| 517 | 数学 (Mathematics) | An Introduction to Sequential Monte Carlo | Nicolas Chopin (他: Omiros Papaspiliopoulos) | Springer | 378 p. | 2020 | - | 2026/01/20 |
| 518 | 数学 (Mathematics) | Sequential Monte Carlo Methods in Practice (Information Science and Statistics) | A. Smith (他: Arnaud Doucet, Nando De Freitas, Neil Gordon) | Springer | 610 p. | 2010 | 9781441928870 | 2026/01/20 |
| 519 | 数学 (Mathematics) | Probability Theory II: Stochastic Calculus (UNITEXT Book 166) | Andrea Pascucci | Springer | - | 2024 | - | 2026/01/20 |
| 520 | 数学 (Mathematics) | Probability Theory I: Random Variables and Distributions (UNITEXT Book 165) | Andrea Pascucci | Springer | - | 2024 | 9783031631900 | 2026/01/20 |
| 521 | 数学 (Mathematics) | Monte Carlo Statistical Methods (Springer Texts in Statistics) | Christian P. Robert (他: George Casella) | Springer | 679 p. | 1999 (2010) | 9781441919397 | 2026/01/20 |
| 522 | 数学 (Mathematics) | Monte Carlo Methods in Statistical Physics | Mark Newman (他: G. T. Barkema) | Clarendon Press | 490 p. | 1999 | 9780198517979 | 2026/01/20 |
| 523 | 数学 (Mathematics) | Handbook of Monte Carlo Methods (Wiley Series in Probability and Statistics) | Dirk P. Kroese (他: Thomas Taimre, Zdravko I. Botev) | Wiley | 772 p. | 2011 | 9780470177938 | 2026/01/20 |
| 524 | 数学 (Mathematics) | Fast Sequential Monte Carlo Methods for Counting and Optimization | Reuven Y. Rubinstein (他: Ad Ridder, Radislav Vaisman) | Wiley | 208 p. | 2013 | 9781118612316 | 2026/01/20 |
| 525 | 数学 (Mathematics) | Explorations in Monte Carlo Methods (Undergraduate Texts in Mathematics) | Ronald W. Shonkwiler (他: Franklin Mendivil) | Springer | 256 p. | 2009 | 9780387878362 | 2026/01/20 |
| 526 | 数学 (Mathematics) | Markov Chains and Stochastic Stability (Communications and Control Engineering) | Sean P. R.L. Meyn (他: Richard L. Tweedie) | Springer | 550 p. | 1996 | 9783540198321 | 2026/01/20 |
| 527 | 数学 (Mathematics) | Markov Chains and Mixing Times | David Asher Levin (他: Yuval Peres, Elizabeth L. Wilmer) | American Mathematical Society | 371 p. | 2008 | 9780821847398 | 2026/01/20 |
| 528 | 数学 (Mathematics) | Diffusions, Markov Processes, and Martingales: Volume 1, Foundations (Cambridge Mathematical Library) | L.C.G. Rogers (他: David Williams) | Cambridge University Press | 410 p. | 1979 (2000) | 9780521775946 | 2026/01/20 |
| 529 | 数学 (Mathematics) | Surrogates: Gaussian Process Modeling, Design, and Optimization for the Applied Sciences | Robert B Gramacy | CRC Press | 559 p. | 2020 | 9780367415426 | 2026/01/20 |
| 530 | 数学 (Mathematics) | Gaussian Processes for Machine Learning (Adaptive Computation and Machine Learning series) | Carl Edward Rasmussen (他: Christopher K. I. Williams) | The MIT Press | 272 p. | 2005 | 9780262182539 | 2026/01/20 |
| 531 | 数学 (Mathematics) | Learning with Kernels: Support Vector Machines, Regularization, Optimization, and Beyond (Adaptive Computation and Machine Learning) | Bernhard Schölkopf (他: Alexander J. Smola) | Mit Pr | 644 p. | 2001 | 9780262194754 | 2026/01/20 |
| 532 | 数学 (Mathematics) | Introduction to Hierarchical Bayesian Modeling for Ecological Data | Parent E Rivot Etienne | Not Avail | 426 p. | 2014 | 9781584889205 | 2026/01/20 |
| 533 | 数学 (Mathematics) | Bayesian Data Analysis | Andrew Gelman (他: John B. Carlin, Hal S. Stern, Donald B. Rubin) | Chapman and Hall/CRC | 690 p. | 1995 (2003) | 9781584883883 | 2026/01/20 |
| 534 | 数学 (Mathematics) | Bayesian Models of Cognition: Reverse Engineering the Mind | Thomas L. Griffiths (他: Nick Chater, Joshua Tenenbaum) | The MIT Press | 648 p. | 2024 | 9780262049412 | 2026/01/20 |
| 535 | 数学 (Mathematics) | Bayesian Brain: Probabilistic Approaches to Neural Coding (Computational Neuroscience) | Kenji Doya (他: Shin Ishii, Alexandre Pouget, Rajesh P.N. Rao) | Mit Pr | 340 p. | 2006 (2011) | 9780262516013 | 2026/01/20 |
| 536 | 数学 (Mathematics) | Everything Is Predictable: How Bayesian Statistics Explain Our World | Tom  Chivers | Atria/One Signal Publishers | 384 p. | 2024 | 9781668052600 | 2026/01/20 |
| 537 | 数学 (Mathematics) | Introduction to Bayesian Statistics, 2nd Edition | William M. Bolstad | Wiley-Interscience | 464 p. | 2004 (2007) | 9780470141151 | 2026/01/20 |
| 538 | 数学 (Mathematics) | A Student’s Guide to Bayesian Statistics | Ben Lambert | SAGE Publications Ltd | 517 p. | 2018 | 9781526418265 | 2026/01/20 |
| 539 | 数学 (Mathematics) | Bayesian Statistics the Fun Way: Understanding Statistics and Probability with Star Wars, LEGO, and Rubber Ducks | Will Kurt | No Starch Press | 256 p. | 2019 | 9781593279561 | 2026/01/20 |
| 540 | 数学 (Mathematics) | Evaluating Derivatives: Principles and Techniques of Algorithmic Differentiation | Andreas Griewank (他: Andrea Walther) | Society for Industrial and Applied Mathematics | 460 p. | 1987 (2008) | 9780898716597 | 2026/01/20 |
| 541 | 数学 (Mathematics) | Practical Optimization | Philip E. Gill | Emerald Group Pub Ltd | 418 p. | 1982 | 9780122839528 | 2026/01/20 |
| 542 | 数学 (Mathematics) | Optimal Control Theory: An Introduction (Dover Books on Electrical Engineering) | Donald E. Kirk | Dover Publications | 480 p. | 1970 (2004) | 9780486434841 | 2026/01/20 |
| 543 | 数学 (Mathematics) | Numerical Optimization (Springer Series in Operations Research and Financial Engineering) | Jorge Nocedal (他: Stephen Wright) | Springer | 686 p. | 2000 (2006) | 9780387303031 | 2026/01/20 |
| 544 | 数学 (Mathematics) | Nonlinear Optimization with Engineering Applications (Springer Optimization and Its Applications, 19) | Michael Bartholomew-Biggs | Springer | 296 p. | 2008 (2010) | 9781441946218 | 2026/01/20 |
| 545 | 数学 (Mathematics) | Convex Optimization | Stephen Boyd (他: Lieven Vandenberghe) | Cambridge University Press | 727 p. | 2004 | 9780521833783 | 2026/01/20 |
| 546 | 数学 (Mathematics) | Applied Optimal Control: Optimization, Estimation and Control | Arthur E. Bryson Jr. (他: Yu-Chi Ho) | Routledge | 496 p. | 1975 | 9780891162285 | 2026/01/20 |
| 547 | 数学 (Mathematics) | An Introduction to Optimization | Edwin K.P. Chong (他: Stanislaw H. Zak) | Wiley-Interscience | 584 p. | 1995 (2008) | 9780471758006 | 2026/01/20 |
| 548 | 数学 (Mathematics) | A First Course in Combinatorial Optimization (Cambridge Texts in Applied Mathematics, Series Number 36) | Jon Lee | Cambridge University Press | 228 p. | 2004 | 9780521010122 | 2026/01/20 |
| 549 | 数学 (Mathematics) | A Course in the Calculus of Variations: Optimization, Regularity, and Modeling (Universitext) | Filippo Santambrogio | Springer | 359 p. | 2023 | 9783031450358 | 2026/01/20 |
| 550 | 数学 (Mathematics) | Fractional Programming: Theory, Methods and Applications (Mathematics and Its Applications, 409) | I.M. Stancu-Minasian | Springer | - | 1997 | 9780792345800 | 2026/01/20 |
| 551 | 数学 (Mathematics) | Introduction to Continuous Optimization (Springer Optimization and Its Applications, 172) | Roman A Polyak | Springer | 557 p. | 2021 | 9783030687113 | 2026/01/20 |
| 552 | 数学 (Mathematics) | An Introduction to Continuous Optimization | N. Andreasson | Studentlitteratur | 400 p. | 2007 (2006) | 9789144044552 | 2026/01/20 |
| 553 | 神経科学・認知科学 (Neuroscience) | Complex Valued Nonlinear Adaptive Filters: Noncircularity, Widely Linear and Neural Models (Adaptive and Cognitive Dynamic Systems: Signal Processing, Learning, Communications and Control) | Danilo Mandic (他: Vanessa Su Lee Goh) | Wiley | 352 p. | 2009 | 9780470066355 | 2026/01/20 |
| 554 | 数学 (Mathematics) | Using Multivariate Statistics | Barbara G. Tabachnick (他: Linda S. Fidell) | Pearson College Div | 980 p. | 1983 (2006) | 9780205459384 | 2026/01/20 |
| 555 | 数学 (Mathematics) | Understanding The New Statistics: Effect Sizes, Confidence Intervals, and Meta-Analysis | Geoff Cumming | Routledge | 537 p. | 2011 (2013) | - | 2026/01/20 |
| 556 | 数学 (Mathematics) | Reading and Understanding More Multivariate Statistics | Laurence G. Grimm | Amer Psychological Assn | 437 p. | 2000 | 9781557986986 | 2026/01/20 |
| 557 | 数学 (Mathematics) | Multivariate Data Analysis | Joseph F. Hair Jr. (他: Barry J. Babin, William C. Black, Rolph E. Anderson, Ronald L. Tatham) | Pearson College Div | 899 p. | 1979 (2005) | 9780130329295 | 2026/01/20 |
| 558 | 数学 (Mathematics) | Applied Multivariate Statistical Analysis | Richard A.  Johnson (他: Dean W. Wichern) | Pearson College Div | 767 p. | 1982 (2002) | 9780130925534 | 2026/01/20 |
| 559 | 物理学 (Physics) | Optical Holography: Principles, Techniques and Applications (Cambridge Studies in Modern Optics, Series Number 20) (Volume 0) | P. Hariharan | Cambridge University Press | 428 p. | 1984 (1996) | 9780521439657 | 2026/01/20 |
| 560 | 数学 (Mathematics) | Exploratory Factor Analysis (Understanding Statistics) | Leandre R. Fabrigar (他: Duane T. Wegener) | Oxford University Press | 176 p. | 2011 | 9780199734177 | 2026/01/20 |
| 561 | 数学 (Mathematics) | Exploratory and Confirmatory Factor Analysis: Understanding Concepts and Applications | Bruce Thompson | Amer Psychological Assn | 195 p. | 2004 | 9781591470939 | 2026/01/20 |
| 562 | 数学 (Mathematics) | A Step-By-Step Guide to Exploratory Factor Analysis with R and Rstudio | Marley W Watkins | Routledge | 184 p. | 2020 | 9781000336566 | 2026/01/20 |
| 563 | 数学 (Mathematics) | Confirmatory Factor Analysis for Applied Research, Second Edition (Methodology in the Social Sciences) Second edition by Brown PsyD, Timothy A. (2015) Hardcover | Unknown Author | The Guilford Press | - | - | - | 2026/01/20 |
| 564 | 数学 (Mathematics) | Principal Manifolds for Data Visualization and Dimension Reduction (Lecture Notes in Computational Science and Engineering, 58) | Alexander N. Gorban (他: Balazs Kegl, Donald C. Wunsch, Andrei Zinovyev) | Springer | - | 2007 | 9783540737490 | 2026/01/20 |
| 565 | 数学 (Mathematics) | Principal Component Analysis: Methods, Applications and Technology (Mathematics Research Developments) | Virginia Gray | Nova Science Pub Inc | 143 p. | 2017 | 9781536108897 | 2026/01/20 |
| 566 | 数学 (Mathematics) | Principal Components Analysis (Quantitative Applications in the Social Sciences) | George H. Dunteman | SAGE Publications, Inc | 96 p. | 1989 | 9780803931046 | 2026/01/20 |
| 567 | 数学 (Mathematics) | Principal Component Analysis (Springer Series in Statistics) | Ian T. Jolliffe | Springer | 518 p. | 1986 (2002) | 9780387954424 | 2026/01/20 |
| 568 | 数学 (Mathematics) | Practical Guide To Principal Component Methods in R (Multivariate Analysis Book 2) | Alboukadel Kassambara | - | 284 p. | 2017 | - | 2026/01/20 |
| 569 | 数学 (Mathematics) | Nonlinear Dimensionality Reduction (Information Science and Statistics) | John A.  Lee (他: Michel Verleysen) | Springer | 326 p. | 2007 (2010) | 9781441922885 | 2026/01/20 |
| 570 | 数学 (Mathematics) | Toward Category-Level Object Recognition (Lecture Notes in Computer Science, 4170) | Jean Ponce (他: Martial Hebert, Cordelia Schmid, Andrew Zisserman) | Springer | 631 p. | 2007 (2006) | 9783540687948 | 2026/01/20 |
| 571 | 数学 (Mathematics) | Three-Dimensional Imaging, Visualization, and Display (Signals and Communication Technology) (2008-12-12) | Unknown Author | Springer; 2009 edition (2008-12-12) | - | - | - | 2026/01/20 |
| 572 | 計算機科学・情報科学 (Computer Science) | The Birth of Computer Vision | James E. Dobson | University of Minnesota Press | 214 p. | 2023 | 9781517914219 | 2026/01/20 |
| 573 | 数学 (Mathematics) | Image Recognition and Classification: Algorithms, Systems, and Applications (Optical Science and Engineering) | Bahram Javidi | CRC Press | 520 p. | 2002 | 9780824707835 | 2026/01/20 |
| 574 | 数学 (Mathematics) | IMAGE PATTERN RECOGNITION: SYNTHESIS AND ANALYSIS IN BIOMETRICS (Machine Perception and Artificial Intelligence) | Sargur N. Srihari | World Scientific Publishing Company | 452 p. | 2007 | 9789812569080 | 2026/01/20 |
| 575 | 数学 (Mathematics) | Computer Vision: Algorithms and Applications (Texts in Computer Science) | Richard Szeliski | Springer-Nature New York Inc | 812 p. | 2010 | 9781848829343 | 2026/01/20 |
| 576 | 数学 (Mathematics) | Computer Vision: Statistical Models for Marr's Paradigm | Song-Chun Zhu (他: Ying Nian Wu) | Springer | 371 p. | 2023 | 9783030965297 | 2026/01/20 |
| 577 | 数学 (Mathematics) | Modern Multivariate Statistical Techniques: Regression, Classification, and Manifold Learning (Springer Texts in Statistics) | Alan Julian Izenman | Springer | 758 p. | 2008 | 9780387781884 | 2026/01/19 |
| 578 | 数学 (Mathematics) | Robust and Non-Robust Models in Statistics | Lev B. Klebanov (他: Svetlozar T. Rachev, Frank J. Fabozzi) | Nova Science Pub Inc | 317 p. | 2009 | 9781607417682 | 2026/01/19 |
| 579 | 数学 (Mathematics) | Robust Statistics: Theory and Methods (Wiley Series in Probability and Statistics) | Ricardo A. Maronna (他: Douglas R. Martin, Victor J. Yohai) | Wiley | 436 p. | 2006 | 9780470010921 | 2026/01/19 |
| 580 | 物理学 (Physics) | Quantum Simulations of Complex Many-Body Systems: | Unknown Author | - | - | - | 9783000090578 | 2026/01/19 |
| 581 | 数学 (Mathematics) | Quantum Dynamics: Applications In Biological And Materials Systems | Eric Bittner | T&F India | 322 p. | 2009 | 9781420080537 | 2026/01/19 |
| 582 | 数学 (Mathematics) | Quantum Circuit Simulation | George F. Viamontes (他: Igor L. Markov, John P. Hayes) | Springer | 200 p. | 2009 | 9789048130641 | 2026/01/19 |
| 583 | 数学 (Mathematics) | Analogue Quantum Simulation: A New Instrument for Scientific Understanding (Springerbriefs in Philosophy) | Dominik Hangleiter (他: Jacques Carolan, Karim P. Y. Thébault) | Springer | 159 p. | 2022 | 9783030872151 | 2026/01/19 |
| 584 | 数学 (Mathematics) | Computational Physics: Simulation of Classical and Quantum Systems (Graduate Texts in Physics) | Philipp O.J. Scherer | Springer | 1052 p. | 2017 | - | 2026/01/19 |
| 585 | 数学 (Mathematics) | Neural-Network Simulation of Strongly Correlated Quantum Systems (Springer Theses) | Stefanie Czischek | Springer | 220 p. | 2021 | 9783030527174 | 2026/01/19 |
| 586 | 物理学 (Physics) | The Theory of Quantum Information | John Watrous | Cambridge University Press | 598 p. | 2018 | 9781107180567 | 2026/01/19 |
| 587 | 物理学 (Physics) | Quantum Information Theory | Mark Wilde | Cambridge University Press | 672 p. | 2013 | 9781107034259 | 2026/01/19 |
| 588 | 物理学 (Physics) | Quantum Computation and Quantum Information (Cambridge Series on Information and the Natural Sciences) | Michael A. Nielsen (他: Isaac L. Chuang) | Cambridge University Press | 700 p. | 2000 | 9780521635035 | 2026/01/19 |
| 589 | 物理学 (Physics) | Quantum Field Theory, as Simply as Possible | A. Zee | Princeton University Press | 392 p. | 2023 | 9780691174297 | 2026/01/19 |
| 590 | 数学 (Mathematics) | Group Theory in a Nutshell for Physicists | A. Zee | Princeton University Press | 608 p. | 2016 | 9780691162690 | 2026/01/19 |
| 591 | 物理学 (Physics) | Special Relativity and Classical Field Theory: The Theoretical Minimum | Leonard Susskind (他: Art Friedman) | Basic Books | 448 p. | 2017 | 9780465093342 | 2026/01/19 |
| 592 | 物理学 (Physics) | Quantum Field Theory in a Nutshell | A. Zee | Princeton University Press | 518 p. | 2003 | 9780691010199 | 2026/01/19 |
| 593 | 物理学 (Physics) | Quantum Physics: A First Encounter: Interference, Entanglement, and Reality | Valerio Scarani | Oxford University Press | 144 p. | 2006 | 9780198570479 | 2026/01/19 |
| 594 | 物理学 (Physics) | Quantum in Pictures: A New Way to Understand the Quantum World | Bob Coecke (他: Stefano Gogioso) | Quantinuum | 218 p. | 2023 | 9781739214722 | 2026/01/19 |
| 595 | 数学 (Mathematics) | Quantum Entanglement Engineering and Applications (Coherent Sources and Applications) | F J Duarte (他: Travis Taylor) | Iop Publishing Ltd | 200 p. | 2021 | 9780750334051 | 2026/01/19 |
| 596 | 数学 (Mathematics) | Quantum Electrodynamics (Frontiers in Physics) | Richard P. Feynman | CRC Press | 212 p. | 1962 (1971) | 9780201360752 | 2026/01/19 |
| 597 | 数学 (Mathematics) | Introduction to Quantum Mechanics: Schrodinger Equation And Path Integral by Harald J. W. Muller-Kirsten (2006-03-03) | Unknown Author | World Scientific Publishing Company | - | - | - | 2026/01/19 |
| 598 | 物理学 (Physics) | Fundamentals of Quantum Entanglement | F J Duarte | Institute of Physics Publishing | 382 p. | 2019 | 9780750322270 | 2026/01/19 |
| 599 | 物理学 (Physics) | Quantum Entanglement | Jed Brody | MIT Press | 184 p. | 2020 | 9780262538442 | 2026/01/19 |
| 600 | 数学 (Mathematics) | A Student's Guide to the Schrödinger Equation (Student's Guides) | Daniel A. Fleisch | Cambridge University Press | 237 p. | 2020 | - | 2026/01/19 |
| 601 | 数学 (Mathematics) | A Student's Guide to Fourier Transforms: With Applications in Physics and Engineering | J.F. James | Cambridge University Press | - | 1995 (2003) | 9780521004282 | 2026/01/19 |
| 602 | 数学 (Mathematics) | Quantum Chaos: An Introduction: An Introduction (Volume 0) | Hans-Jürgen Stöckmann | Cambridge University Press | 384 p. | 1999 (2008) | 9780521027151 | 2026/01/19 |
| 603 | 数学 (Mathematics) | Quantum Chaos: A New Paradigm of Nonlinear Dynamics (Cambridge Nonlinear Science Series) by Nakamura, Katsuhiro published by Cambridge University Press Paperback | Unknown Author | Cambridge University Press | - | 1994 | - | 2026/01/19 |
| 604 | 数学 (Mathematics) | Nonlinear Dynamics and Quantum Chaos: An Introduction (Graduate Texts in Physics) | Sandro Wimberger | Springer | 275 p. | 2023 | 9783031012488 | 2026/01/19 |
| 605 | 数学 (Mathematics) | The Oxford Handbook of Comparative Institutional Analysis | Glenn Morgan (他: John Campbell, Colin Crouch, Ove Kai Pedersen, Richard Whitley) | Oxford University Press | 724 p. | 2010 | 9780199233762 | 2026/01/19 |
| 606 | 生物学・生命科学 (Biology) | The Oxford Handbook of International Business Strategy | Kamel Mellahi (他: Klaus Meyer, Rajneesh Narula, Irina Surdu, Alain Verbeke) | Oxford University Press | 528 p. | 2021 | 9780198868378 | 2026/01/19 |
| 607 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Oxford Handbook of Climate Change and Society | John S. Dryzek (他: Richard B. Norgaard, David Schlosberg) | Oxford University Press | 727 p. | 2011 | 9780199566600 | 2026/01/19 |
| 608 | 生物学・生命科学 (Biology) | Music as Biology: The Tones We Like and Why | Dale Purves | Harvard University Press | 176 p. | 2017 | 9780674545151 | 2026/01/19 |
| 609 | 数学 (Mathematics) | Mechatronics: Electronic Control Systems in Mechanical and Electrical Engineering | W. Bolton | Prentice Hall | 574 p. | 1996 (2004) | 9780131216334 | 2026/01/19 |
| 610 | 数学 (Mathematics) | Mathematical Foundations of Soft Robotics Engineering (Computational Methods in Soft Robotics Design) | Jamie Flux | - | - | 2024 | - | 2026/01/19 |
| 611 | 物理学 (Physics) | Machine Elements In Mechanical Design | Robert L. Mott | - | - | 1985 | 9780131911291 | 2026/01/19 |
| 612 | 数学 (Mathematics) | Interpreting Engineering Drawings (Drafting and Design) | Cecil Howard Jensen (他: Jay D. Helsel) | Delmar Cengage Learning | - | 1970 (2006) | 9781418055738 | 2026/01/19 |
| 613 | 数学 (Mathematics) | Interpreting Engineering Drawings | Ted Branoff | Cengage Learning | 528 p. | 2015 | 9781305445055 | 2026/01/19 |
| 614 | 数学 (Mathematics) | Engineering Drawing: Principles and Applications | Lakhwinder Pal Singh | Cambridge University Press | 475 p. | 2021 | 9781009032292 | 2026/01/19 |
| 615 | 数学 (Mathematics) | Handbook on Soft Robotics | Thrishantha Nanayakkara | Springer | 380 p. | 2024 | 9783031686191 | 2026/01/19 |
| 616 | 物理学 (Physics) | Nonequilibrium Many-Body Theory of Quantum Systems: A Modern Introduction | Gianluca Stefanucci (他: Robert Van Leeuwen) | Cambridge University Press | 620 p. | 2013 | 9780521766173 | 2026/01/19 |
| 617 | 物理学 (Physics) | Introduction to Many-Body Physics | Piers Coleman | Cambridge University Press | 810 p. | 2012 (2016) | 9780521864886 | 2026/01/19 |
| 618 | 数学 (Mathematics) | Green's Function Estimates for Lattice Schrödinger Operators and Applications (Annals of Mathematics Studies, 158) | Jean Bourgain | Princeton University Press | 200 p. | 2004 | 9780691120980 | 2026/01/19 |
| 619 | 数学 (Mathematics) | Fundamentals of Many-Body Physics: Principles and Methods | Wolfgang Nolting (他: William D. Brewer) | Springer Verlag | 602 p. | 2008 (2009) | 9783540719304 | 2026/01/19 |
| 620 | 物理学 (Physics) | Green's Function in Condensed Matter Physics | Wang Huaiyu | Alpha Science | 446 p. | 2011 (2012) | 9781842657140 | 2026/01/19 |
| 621 | 数学 (Mathematics) | Green s Functions in Quantum Physics by Economou, Eleftherios N.. (Springer,2006) [Hardcover] | Eleftherios N. Economou | Springer,2006 | - | 1983 | - | 2026/01/19 |
| 622 | 物理学 (Physics) | A Middle Way: A Non-Fundamental Approach to Many-Body Physics | Robert W. Batterman | Oxford University Press | 190 p. | 2021 | 9780197568613 | 2026/01/19 |
| 623 | 数学 (Mathematics) | An Introduction to Manifolds (Universitext) | Loring W. Tu | Springer | 428 p. | 2007 (2010) | 9781441973993 | 2026/01/19 |
| 624 | 数学 (Mathematics) | A Visual Introduction to Differential Forms and Calculus on Manifolds | Jon Pierre Fortney | Birkhäuser | 467 p. | 2018 | 9783319969916 | 2026/01/19 |
| 625 | 数学 (Mathematics) | Manifold Learning Theory and Applications | Yunqian Ma (他: Yun Fu) | CRC Press | 330 p. | 2011 (2012) | 9781439871096 | 2026/01/19 |
| 626 | 神経科学・認知科学 (Neuroscience) | Brain and Perception (Distinguished Lecture Series) | Karl H. Pribram | Lawrence Erlbaum Associates | 420 p. | 1991 | 9780898599954 | 2026/01/19 |
| 627 | 数学 (Mathematics) | Fractional Calculus in Bioengineering | Richard L. Magin | BH | 684 p. | 2006 | 9781567002157 | 2026/01/19 |
| 628 | 数学 (Mathematics) | Functional Fractional Calculus for System Identification and Controls | Shantanu Das | Springer | 258 p. | 2007 | 9783540727026 | 2026/01/19 |
| 629 | 数学 (Mathematics) | An Introduction to the Fractional Calculus and Fractional Differential Equations | Kenneth S. Miller (他: Bertram Ross) | Wiley-Interscience | 384 p. | 1993 | 9780471588849 | 2026/01/19 |
| 630 | 自然科学・複雑系 (Natural Science & Complex Systems) | Science from Fisher Information: A Unification | B. Roy Frieden | Cambridge University Press | - | 2004 | 9780521009119 | 2026/01/16 |
| 631 | 物理学 (Physics) | Physics from Fisher Information: A Unification | B. Roy Frieden | Cambridge University Press | 328 p. | 1998 (1999) | 9780521631679 | 2026/01/16 |
| 632 | 数学 (Mathematics) | Security Analysis, Seventh Edition: Principles and Techniques | Benjamin Graham (他: David L. Dodd, Seth A. Klarman) | McGraw Hill | 1460 p. | 1934 (2023) | 9781264932757 | 2026/01/16 |
| 633 | 生物学・生命科学 (Biology) | Business Model Generation | Alexander Osterwalder (他: Yves Pigneur) | Alexander Osterwalder & Yves Pigneur | 273 p. | 2010 | 9782839906173 | 2026/01/16 |
| 634 | 物理学 (Physics) | Business Anthropology | Ann T. Jordan | Waveland Pr Inc | 144 p. | 2002 | 9781577662136 | 2026/01/16 |
| 635 | 数学 (Mathematics) | Introduction to Differential Geometry (Springer Studium Mathematik (Master)) | Joel W. Robbin (他: Dietmar A. Salamon) | Springer Spektrum | - | 2022 | 9783662643402 | 2026/01/16 |
| 636 | 数学 (Mathematics) | Differential Topology: An Introduction (Dover Books on Mathematics) | David B. Gauld | Dover Publications | 256 p. | 2006 | 9780486450216 | 2026/01/16 |
| 637 | 数学 (Mathematics) | An Introduction to Differential Geometry | T.J. Willmore | Oxford Univ Pr | 328 p. | 2012 (1959) | 9780198531258 | 2026/01/16 |
| 638 | 数学 (Mathematics) | Differential Topology | Victor W. Guillemin (他: Alan Pollack) | Pearson College Div | 222 p. | 1974 | 9780132126052 | 2026/01/16 |
| 639 | 化学・物質科学 (Chemistry & Materials) | Time-Dependent Density Functional Theory: Nonadiabatic Molecular Dynamics | Chaoyuan Zhu | Jenny Stanford Publishing | - | 2022 | 9781000647075 | 2026/01/16 |
| 640 | 計算機科学・情報科学 (Computer Science) | Theoretical and Computational Chemistry, Volume 4: Recent Developments and Applications of Modern Density Functional Theory | Jorge M. Seminario | Elsevier Science & Technology | 863 p. | 1996 (2014) | 9780080540399 | 2026/01/16 |
| 641 | 数学 (Mathematics) | Density Functional Theory: An Approach to the Quantum Many-Body Problem | Reiner M. Dreizler (他: Eberhard K.U. Gross) | Springer | 302 p. | 1991 (1996) | 9783540519935 | 2026/01/16 |
| 642 | 数学 (Mathematics) | Density Functional Theory: An Advanced Course | Eberhard Engel (他: Reiner M. Dreizler) | Springer | 548 p. | 2011 | 9783642140914 | 2026/01/16 |
| 643 | 自然科学・複雑系 (Natural Science & Complex Systems) | Density Functional Theory: A Practical Introduction | David Sholl (他: Janice A. Steckel) | Wiley-Interscience | 238 p. | 2009 | 9780470373170 | 2026/01/16 |
| 644 | 数学 (Mathematics) | Density Functional Methods In Physics (Nato ASI Subseries B:, 123) | Reiner M. Dreizler (他: Joao Da Providencia) | Springer | 541 p. | 1985 (2013) | 9781475708202 | 2026/01/16 |
| 645 | 化学・物質科学 (Chemistry & Materials) | A Chemist's Guide to Density Functional Theory, 2nd Edition | Wolfram Koch (他: Max C. Holthausen) | VCH | 313 p. | 2000 (2001) | 9783527303724 | 2026/01/16 |
| 646 | 計算機科学・情報科学 (Computer Science) | Computer Programming And Cyber Security for Beginners: This Book Includes: Python Machine Learning, SQL, Linux, Hacking with Kali Linux, Ethical Hacking. Coding and Cybersecurity Fundamentals | Zach Codings | - | 412 p. | 2019 | - | 2026/01/16 |
| 647 | 計算機科学・情報科学 (Computer Science) | Applied Cryptography: Protocols, Algorithms, and Source Code in C | Bruce Schneier | Wiley | 784 p. | 1993 (1995) | 9780471128458 | 2026/01/16 |
| 648 | 生物学・生命科学 (Biology) | Nutritional Anthropology: Biocultural Perspectives on Food and Nutrition | Darna L. Dufour (他: Allan H. Goodman, Gretel H. Pelto) | - | - | 2012 | - | 2026/01/16 |
| 649 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Warming Papers: The Scientific Foundation for the Climate Change Forecast | David  Archer (他: Raymond T. Pierrehumbert) | Wiley-Blackwell | 432 p. | 2010 (2011) | 9781405196161 | 2026/01/16 |
| 650 | 数学 (Mathematics) | Numerical Weather and Climate Prediction | Thomas Tomkins Warner | Cambridge University Press | 550 p. | 2010 (2011) | 9780521513890 | 2026/01/16 |
| 651 | 自然科学・複雑系 (Natural Science & Complex Systems) | Assessment of Intraseasonal to Interannual Climate Prediction and Predictability (Climate Change) | National Research Council (他: Division on Earth and Life Studies, Board on Atmospheric Sciences and Climate, Committee on Assessment of Intraseasonal to Interannual Climate Prediction and Predictability) | National Academies Press | 192 p. | 2010 | 9780309151832 | 2026/01/16 |
| 652 | 数学 (Mathematics) | Theory of Automata (International Series of Monographs in Pure and Applied Mathematics, v. 100) | Arto Salomaa | Pergamon Press | 263 p. | 1969 | 9780080133768 | 2026/01/16 |
| 653 | 計算機科学・情報科学 (Computer Science) | Elements of the Theory of Computation 2nd Ed | Lewis & Papadimitriou (他: Papadimitriou Christos H.) | Prentice Hall of India | 380 p. | 2007 | 9788120322332 | 2026/01/16 |
| 654 | 計算機科学・情報科学 (Computer Science) | Elements of the Theory of Computation | Harry R. Lewis (他: Christos H. Papadimitriou) | Prentice-Hall | 384 p. | 1981 (1997) | 9780132624787 | 2026/01/16 |
| 655 | 数学 (Mathematics) | The Mathematics of Cellular Automata (Student Mathematical Library) | Jane Hawkins | American Mathematical Society | 228 p. | 2024 | 9781470475376 | 2026/01/16 |
| 656 | 物理学 (Physics) | QUANTUM CELLULAR AUTOMATA: THEORY, EXPERIMENTATION AND PROSPECTS | Massimo Macucci | Imperial College Pr | 284 p. | 2006 | 9781860946325 | 2026/01/16 |
| 657 | 数学 (Mathematics) | Automata and Computability (Undergraduate Texts in Computer Science) | Dexter C. Kozen | Springer | 413 p. | 1997 | 9780387949079 | 2026/01/16 |
| 658 | 生物学・生命科学 (Biology) | A Manual of Acupuncture | Peter Deadman (他: Kevin Baker, Mazin Al-Khafaji) | Journal of Chinese Medicine | 670 p. | 1998 (2001) | 9780951054673 | 2026/01/16 |
| 659 | 生物学・生命科学 (Biology) | Natural Eating: Nutritional Anthropology - Eating in Harmony with our Genetic Progamming | Geoff Bond | - | 249 p. | 2000 (2011) | - | 2025/02/13 |
| 660 | 生物学・生命科学 (Biology) | Nutritional Anthropology: Biocultural Perspectives on Food and Nutrition | Darna L. Dufour (他: Alan H. Goodman, Gretel H. Pelto) | McGraw-Hill Humanities/Social Sciences/Languages | - | 1999 | 9780767411974 | 2025/02/13 |
| 661 | 物理学 (Physics) | Quantum Mechanics: The Theoretical Minimum (Theoretical Minimum #2) | Leonard Susskind (他: Art Friedman) | Basic Books | 364 p. | 2014 | 9780465036677 | 2024/12/30 |
| 662 | 計算機科学・情報科学 (Computer Science) | Practical Python and OpenCV | Adrian Rosebrock | PyImageSearch | - | - | - | 2024/12/29 |
| 663 | 計算機科学・情報科学 (Computer Science) | Learning OpenCV: Computer Vision with the OpenCV Library | Gary Bradski (他: Adrian Kaehler) | O'Reilly Media | 575 p. | 2008 | 9780596516130 | 2024/12/29 |
| 664 | 数学 (Mathematics) | Advances in Automatic Differentiation (Lecture Notes in Computational Science and Engineering) | Christian H. Bischof | Springer | 368 p. | 2008 | 9783540689355 | 2024/12/29 |
| 665 | 数学 (Mathematics) | Automatic Differentiation: Applications, Theory, and Implementations (Lecture Notes in Computational Science and Engineering, 50) | George F. Corliss (他: M. Bucker) | Springer | 370 p. | 2006 (2005) | 9783540284031 | 2024/12/29 |
| 666 | 数学 (Mathematics) | Quantum Software: Aspects of Theory and System Design | Iaakov Exman (他: Ricardo Perez-Castillo, Mario Piattini, Michael Felderer) | Springer | 372 p. | 2024 | 9783031641350 | 2024/12/27 |
| 667 | 物理学 (Physics) | Quantum Programming: Writing Software for Quantum Computers: Master the Fundamentals and Advanced Techniques to Unlock the Power of Quantum Algorithms (TechTales Chronicles) | Albert Tetteh Adjei | Independently published | 257 p. | 2024 | 9798328947800 | 2024/12/27 |
| 668 | 数学 (Mathematics) | Quantum Software Engineering | Manuel A. Serrano (他: Ricardo Pérez-Castillo, Mario Piattini) | Springer | 330 p. | 2022 | 9783031053238 | 2024/12/27 |
| 669 | 物理学 (Physics) | Quantum Psychology: How Brain Software Programs You & Your World | Robert Anton Wilson | New Falcon Pubns | 202 p. | 1990 (1993) | 9781561840717 | 2024/12/27 |
| 670 | 数学 (Mathematics) | Handbook of Markov Chain Monte Carlo (Chapman & Hall/CRC Handbooks of Modern Statistical Methods) | Steve Brooks (他: Andrew Gelman, Galin Jones, Xiao-Li Meng) | Chapman and Hall/CRC | 618 p. | 2010 (2011) | 9781420079418 | 2024/12/17 |
| 671 | 神経科学・認知科学 (Neuroscience) | The New Visual Neurosciences (Mit Press) | John Simon Werner (他: Leo M. Chalupa) | The MIT Press | 1675 p. | 2013 | 9780262019163 | 2024/11/18 |
| 672 | 計算機科学・情報科学 (Computer Science) | Neural Computation in Hopfield Networks and Boltzmann Machines | James P. Coughlih | UNKNO | 281 p. | 1995 | 9780874134643 | 2024/09/26 |
| 673 | 生物学・生命科学 (Biology) | Biochemistry & Molecular Biology of Plants | Russell L. Jones | Wiley | 1408 p. | 2002 | 9780943088396 | 2024/09/13 |
| 674 | 物理学 (Physics) | Nonlinear Fiber Optics | Govind P. Agrawal | Academic Press | 552 p. | 1989 (2006) | 9780123695161 | 2024/07/12 |
| 675 | 物理学 (Physics) | Atomic Light (Shadow Optics) | Akira Mizuta Lippit | University Of Minnesota Press | 224 p. | 2005 (2006) | 9780816646111 | 2024/07/12 |
| 676 | 物理学 (Physics) | Theoretical Optics: An Introduction | Hartmann R&ouml;mer (他: Hartmann Rvmer) | Wiley-VCH | 375 p. | 2005 | 9783527404292 | 2024/07/12 |
| 677 | 物理学 (Physics) | Nonlinear Optical Cavity Dynamics: From Microresonators to Fiber Lasers (2016-03-14) | Unknown Author | Wiley | - | - | - | 2024/07/12 |
| 678 | 物理学 (Physics) | Principles of Optics: Electromagnetic Theory of Propagation, Interference and Diffraction of Light | Max Born (他: Emil Wolf, A.B. Bhatia, P.C. Clemmow, D. Gabor, A.R. Stokes, A.M. Taylor, P.A. Wayman, W.L. Wilcock) | Cambridge University Press | 985 p. | 1980 (1999) | 9780521642224 | 2024/07/12 |
| 679 | 数学 (Mathematics) | Heavenly Mathematics: The Forgotten Art of Spherical Trigonometry | Glen van Brummelen | Princeton University Press | 208 p. | 2012 | 9780691148922 | 2024/06/28 |
| 680 | 数学 (Mathematics) | The Seduction of Curves: The Lines of Beauty That Connect Mathematics, Art, and the Nude | Allan McRobie (他: Helena Weightman) | Princeton University Press | 168 p. | 2017 | 9780691175331 | 2024/06/28 |
| 681 | 数学 (Mathematics) | Mathematics and Art: A Cultural History | Lynn Gamwell | Princeton University Press | 584 p. | 2015 | 9780691165288 | 2024/06/28 |
| 682 | 生物学・生命科学 (Biology) | Plant Cell Culture: Essential Methods | Michael R. Davey (他: Tom Butler-Bowdon) | Wiley | 358 p. | 2010 | 9780470686515 | 2024/06/24 |
| 683 | 数学 (Mathematics) | Plant Cell and Tissue Culture - A Tool in Biotechnology: Basics and Application (Principles and Practice) | Karl-Hermann Neumann (他: Ashwani Kumar, Jafargholi Imani) | Springer | 344 p. | 2009 (2010) | 9783642101021 | 2024/06/24 |
| 684 | 生物学・生命科学 (Biology) | Plant Cell Culture Protocols (Methods in Molecular Biology, 318) | Víctor M. Loyola-Vargas (他: Felipe Vázquez-Flota) | Humana | 410 p. | 2005 (2010) | 9781617376344 | 2024/06/24 |
| 685 | 神経科学・認知科学 (Neuroscience) | The Mystery of the Mind: A Critical Study of Consciousness and the Human Brain | Wilder Penfield | Princeton University Press | 160 p. | 1975 | 9780691081595 | 2024/06/20 |
| 686 | 数学 (Mathematics) | Cytokines, Stress, and Depression | Robert Dantzer | Springer | 352 p. | 2013 | 9781475786095 | 2024/06/13 |
| 687 | 数学 (Mathematics) | Quantum Processes in Biology (Springer Series in Biophysics, 26) | Jose Antonio Fornes | Springer | 228 p. | 2024 | 9783031580772 | 2024/06/10 |
| 688 | 物理学 (Physics) | Quantum Biology | Shiv Sanjeevi | Delve Publishing | 290 p. | 2019 | 9781774073377 | 2024/06/10 |
| 689 | 計算機科学・情報科学 (Computer Science) | Cell Reprogramming for Immunotherapy: Methods and Protocols | Samuel G. Katz (他: Peter M. Rabinovich) | Humana | 343 p. | 2019 | 9781071602027 | 2024/06/09 |
| 690 | 生物学・生命科学 (Biology) | The Future of Brain Repair: A Realist's Guide to Stem Cell Therapy | Jack Price | MIT Press | 288 p. | 2020 | 9780262043755 | 2024/06/09 |
| 691 | 生物学・生命科学 (Biology) | Plant Stem Cells: Methods and Protocols (Methods in Molecular Biology, 2094) | Muhammad Naseem (他: Thomas Dandekar) | Humana | 161 p. | 2019 | 9781071601822 | 2024/06/09 |
| 692 | 数学 (Mathematics) | Cell and Gene Therapies (Advances and Controversies in Hematopoietic Transplantation and Cell Therapy) | Miguel-Angel Perales (他: Syed A. Abutalib, Catherine Bollard) | Springer | 496 p. | 2018 | 9783319543680 | 2024/06/09 |
| 693 | 数学 (Mathematics) | Artificial Neural Network Modelling (Studies in Computational Intelligence, 628) | Subana Shanmuganathan (他: Sandhya Samarasinghe) | Springer | 479 p. | 2016 | 9783319284934 | 2024/06/07 |
| 694 | 数学 (Mathematics) | Artificial Neural Networks (Methods in Molecular Biology, 1260) | Hugh Cartwright | Springer | 351 p. | 2015 (2014) | 9781493922383 | 2024/06/07 |
| 695 | 数学 (Mathematics) | Modern Mathematical Statistics with Applications (Springer Texts in Statistics) | Jay L. Devore | Springer | 857 p. | 2006 (2011) | 9781461403906 | 2024/05/23 |
| 696 | 数学 (Mathematics) | Modern Statistics: A Computer-Based Approach with Python (Statistics for Industry, Technology, and Engineering) | Ron S. Kenett (他: Shelemyahu Zacks, Peter Gedeck) | Birkhäuser | 461 p. | 2022 | 9783031075650 | 2024/05/23 |
| 697 | 数学 (Mathematics) | An Introduction to Statistical Learning: with Applications in Python (Springer Texts in Statistics) | Gareth James (他: Daniela Witten, Trevor Hastie, Robert Tibshirani, Jonathan Taylor) | Springer | 607 p. | 2023 | 9783031387463 | 2024/05/12 |
| 698 | 数学 (Mathematics) | An Introduction to Statistical Learning: with Applications in R (Springer Texts in Statistics) | Gareth James (他: Daniela Witten, Trevor Hastie, Robert Tibshirani) | SPRINGER | 426 p. | 2013 | 9781461471370 | 2024/05/12 |
| 699 | 数学 (Mathematics) | Mathematical Handbook: Higher Mathematics | M. Vygodsky | Mir Publishers, Moscow | - | 1971 | - | 2024/05/03 |
| 700 | 生物学・生命科学 (Biology) | Random Walks in Biology: New and Expanded Edition | Howard C. Berg | Princeton University Press | 152 p. | 1984 (1993) | 9780691000640 | 2024/04/04 |
| 701 | 物理学 (Physics) | The Physics of Plasmas (Volume 0) | T.J.M. Boyd (他: J. J. Sanderson) | Cambridge University Press | 548 p. | 1903 (2003) | 9780521459129 | 2024/03/19 |
| 702 | 物理学 (Physics) | Fundamentals of Plasma Physics | Paul M. Bellan | Cambridge University Press | 628 p. | 2006 (2008) | 9780521528009 | 2024/03/19 |
| 703 | 数学 (Mathematics) | Fundamentals of Plasma Physics | J.A. Bittencourt | Springer | 702 p. | 1986 (2004) | 9780387209753 | 2024/03/19 |
| 704 | 計算機科学・情報科学 (Computer Science) | Fluent Python: Clear, Concise, and Effective Programming | Luciano Ramalho | O'Reilly Media | 790 p. | 2015 | 9781491946008 | 2024/03/17 |
| 705 | 生物学・生命科学 (Biology) | Mesenchymal Stem Cells: Methods and Protocols (Methods in Molecular Biology, 1416) | Massimiliano Gnecchi | Humana | 589 p. | 2016 | 9781493935826 | 2024/03/12 |
| 706 | 生物学・生命科学 (Biology) | Mesenchymal Stem Cell Derived Exosomes: The Potential for Translational Nanomedicine | Yaoliang Tang (他: Buddhadeb Dawn) | Academic Press | 288 p. | 2015 | 9780128001646 | 2024/03/12 |
| 707 | 計算機科学・情報科学 (Computer Science) | Making Sense of Cybersecurity | Thomas Kranz | Manning | 288 p. | 2022 | 9781617298004 | 2024/03/11 |
| 708 | 計算機科学・情報科学 (Computer Science) | Evidence-Based Cybersecurity: Foundations, Research, and Practice (ISSN) | Pierre-Luc Pomerleau (他: David Maimon) | CRC Press | 229 p. | 2022 | 9781000600933 | 2024/03/11 |
| 709 | 計算機科学・情報科学 (Computer Science) | Cyber Threat Hunting | Nadhem Alfardan | Manning Publications | 416 p. | 2025 | 9781633439474 | 2024/03/11 |
| 710 | 物理学 (Physics) | Love and Gravity | Samantha Sotto (他: Samantha Sotto Yambao) | Ballantine | 308 p. | 2017 | 9780399593246 | 2024/03/11 |
| 711 | 計算機科学・情報科学 (Computer Science) | Neural Networks: A Comprehensive Foundation | Simon Haykin | Prentice Hall | 842 p. | 1994 (1998) | 9780132733502 | 2024/03/04 |
| 712 | 数学 (Mathematics) | Visual Explorations in Finance: with Self-Organizing Maps (Springer Finance) | Guido Deboeck (他: Teuvo Kohonen) | Springer | 303 p. | 1998 | 9783540762669 | 2024/03/01 |
| 713 | 数学 (Mathematics) | Visual Group Theory (MAA Problem Book Series) | Nathan Carter | The Mathematical Association of America | 306 p. | 2009 | 9780883857571 | 2024/03/01 |
| 714 | 数学 (Mathematics) | The Historical Development of the Calculus (Springer Study Edition) (Volume 0) | Charles Henry Edwards | Springer | 380 p. | 1994 | 9780387943138 | 2024/03/01 |
| 715 | 数学 (Mathematics) | Tensor Geometry: The Geometric Viewpoint and its Uses (Graduate Texts in Mathematics, 130) | C.T.J. Dodson | Springer | 448 p. | 1977 (1991) | 9783540520184 | 2024/03/01 |
| 716 | 数学 (Mathematics) | Real Analysis: A Long-Form Mathematics Textbook | Jay Cummings | CreateSpace Independent Publishing Platform | 375 p. | 2018 | 9781724510129 | 2024/03/01 |
| 717 | 数学 (Mathematics) | Differential Equations with Applications and Historical Notes, 2nd Edition | George F. Simmons (他: John S. Robertson) | McGraw-Hill | 640 p. | 1972 (1991) | 9780070575400 | 2024/03/01 |
| 718 | 数学 (Mathematics) | Advanced Mathematical Methods for Scientists and Engineers I: Asymptotic Methods and Perturbation Theory | Carl M. Bender (他: Steven A. Orszag) | Springer | 607 p. | 1978 (2010) | 9781441931870 | 2024/03/01 |
| 719 | 数学 (Mathematics) | A Combinatorial Introduction to Topology (Dover Books on Mathematics) | Michael Henle | Dover Publications | 320 p. | 1979 (1994) | 9780486679662 | 2024/03/01 |
| 720 | 数学 (Mathematics) | Self-Organizing Maps | Teuvo Kohonen | Springer | 521 p. | 1995 (2000) | 9783540679219 | 2024/02/23 |
| 721 | 数学 (Mathematics) | Childhood in Turkey: Educational, Sociological, and Psychological Perspectives (Science Across Cultures: The History of Non-Western Science, 11) | Hilal H. Şen (他: Helaine Selin (Retired)) | Springer | 358 p. | 2022 | 9783031082078 | 2024/02/12 |
| 722 | 数学 (Mathematics) | Cytoskeleton of the Nervous System | Springer | Springer | 792 p. | 2011 | 9781441967886 | 2024/02/04 |
| 723 | 生物学・生命科学 (Biology) | Textbook Of Structural Biology (Second Edition) (Series In Structural Biology 8) | Anders Liljas (他: Lars Liljas, Miriam-Rose Ash, G?ran Lindblom, Poul Nissen, Morten Kjeldgaard) | World Scientific | 587 p. | 2016 | 9789813142497 | 2024/02/04 |
| 724 | 数学 (Mathematics) | Dynamical Systems in Neuroscience: The Geometry of Excitability And Bursting (Computational Neuroscience) | Eugene M. Izhikevich | Mit Pr | 441 p. | 2006 | 9780262090438 | 2024/01/30 |
| 725 | 計算機科学・情報科学 (Computer Science) | Computational Modeling Methods for Neuroscientists (Computational Neuroscience Series) | Erik De Schutter | The MIT Press | 419 p. | 2009 | 9780262013277 | 2024/01/30 |
| 726 | 計算機科学・情報科学 (Computer Science) | From Neuron to Cognition via Computational Neuroscience | Michael A. Arbib (他: James J. Bonaiuto) | The MIT Press | 808 p. | 2016 | 9780262034968 | 2024/01/30 |
| 727 | 計算機科学・情報科学 (Computer Science) | An Introductory Course in Computational Neuroscience | Paul   Miller | The MIT Press | 408 p. | 2018 | 9780262038256 | 2024/01/30 |
| 728 | 数学 (Mathematics) | Neural Control Engineering: The Emerging Intersection Between Control Theory and Neuroscience (Computational Neuroscience) | Steven J. Schiff | The MIT Press | 361 p. | 2011 (2012) | 9780262015370 | 2024/01/30 |
| 729 | 計算機科学・情報科学 (Computer Science) | Principles of Brain Dynamics: Global State Interactions (Computational Neuroscience Series) | Mikhail I. Rabinovich (他: Karl J. Friston, Pablo Varona) | The MIT Press | 344 p. | 2012 | 9780262017640 | 2024/01/30 |
| 730 | 数学 (Mathematics) | The Oxford Handbook of Philosophy of Mathematics and Logic | Stewart Shapiro (他: David Charles McCarty, Roy T. Cook) | Oxford University Press | 832 p. | 2005 (2007) | 9780195325928 | 2024/01/30 |
| 731 | 数学 (Mathematics) | Philosophy of Mathematics | Øystein Linnebo | Princeton University Press | 210 p. | 2017 | - | 2024/01/30 |
| 732 | 数学 (Mathematics) | A Secret Love of Chaos | Ben Goertzel | Humanity Plus Press | 234 p. | 2016 | - | 2024/01/23 |
| 733 | 物理学 (Physics) | Investigations on the Theory of the Brownian Movement (Dover Books on Physics) | Albert Einstein | Dover Publications | 144 p. | 1956 | 9780486603049 | 2024/01/18 |
| 734 | 自然科学・複雑系 (Natural Science & Complex Systems) | The Laboratory of the Mind: Thought Experiments in the Natural Sciences by James Robert Brown (31-Aug-2010) Paperback | Unknown Author | Routledge; 2 edition (31 Aug. 2010) | - | - | - | 2024/01/17 |
| 735 | 数学 (Mathematics) | Thought Experiments (Springerbriefs in Philosophy) | Nenad Miščević | Springer | 140 p. | 2021 | 9783030810818 | 2024/01/17 |
| 736 | 数学 (Mathematics) | Astrocytes: Wiring the Brain (Frontiers in Neuroscience) | Eliana Scemes (他: David C. Spray) | CRC Press | 450 p. | 2011 | 9781439825846 | 2024/01/17 |
| 737 | 数学 (Mathematics) | Astrocytes: Wiring the Brain (Frontiers in Neuroscience) | Eliana Scemes (他: David C. Spray) | CRC Press | 426 p. | 2011 (2016) | - | 2024/01/17 |
| 738 | 生物学・生命科学 (Biology) | The Biology of Oligodendrocytes (2010-10-21) | Unknown Author | Cambridge University Press | - | - | - | 2024/01/17 |
| 739 | 数学 (Mathematics) | The Biology of Oligodendrocytes | Patricia J. Armati (他: Emily Mathey) | Cambridge University Press | 304 p. | 2010 | 9780521899659 | 2024/01/17 |
| 740 | 生物学・生命科学 (Biology) | Neurobiology of Epilepsy: From Genes to Networks | Karl Smith | American Medical Publishers | 237 p. | 2023 | 9798887403014 | 2024/01/14 |
| 741 | 生物学・生命科学 (Biology) | The Neurobiology of Epilepsy and Aging | James C. Cloyd | Academic Press | 364 p. | 2012 | 9780124112780 | 2024/01/14 |
| 742 | 生物学・生命科学 (Biology) | International Review of Neurobiology, Volume 81: The Neurobiology of Epilepsy and Aging | R. Eugene Ramsay (他: Emilio Perucca) | Academic Press | 368 p. | 2007 | 9780123740182 | 2024/01/14 |
| 743 | 自然科学・複雑系 (Natural Science & Complex Systems) | Diffusion-Limited Reactions (Volume 25) (Comprehensive Chemical Kinetics, Volume 25) | C.H. Bamford (他: C.F.H. Tipper, Richard G. Compton) | Elsevier Science | 403 p. | 1985 | 9780444423542 | 2024/01/06 |
| 744 | 数学 (Mathematics) | Brownian Motion: A Guide to Random Processes and Stochastic Calculus (De Gruyter Textbook) | René L. Schilling (他: Björn Böttcher) | De Gruyter | 533 p. | 2021 | 9783110741254 | 2024/01/03 |
| 745 | 数学 (Mathematics) | Human Neural Stem Cells: From Generation to Differentiation and Application (Results and Problems in Cell Differentiation, 66) | Leonora Buzanska | Springer | 340 p. | 2018 | 9783319934846 | 2023/12/28 |
| 746 | 生物学・生命科学 (Biology) | Neural Stem Cells and Cellular Therapy (Stem Cells- Laboratory and Clinical Research) | Philippe Taupin | Nova Biomedical | 210 p. | 2009 (2010) | 9781608760176 | 2023/12/28 |
| 747 | 数学 (Mathematics) | Microhydrodynamics, Brownian Motion, and Complex Fluids (Cambridge Texts in Applied Mathematics, Series Number 58) | Michael D. Graham | Cambridge University Press | 278 p. | 2018 | 9781107695931 | 2023/12/28 |
| 748 | 化学・物質科学 (Chemistry & Materials) | Brownian Motion and Molecular Reality (Oxford Studies in Philosophy of Science) | George E. Smith (他: Raghav Seth, Jean Perrin) | Oxford University Press | 468 p. | 2020 | 9780190098025 | 2023/12/28 |
| 749 | 数学 (Mathematics) | A Physical Introduction to Suspension Dynamics (Cambridge Texts in Applied Mathematics, Series Number 45) | Elisabeth Guazzelli (他: Jeffrey F. Morris) | Cambridge University Press | 256 p. | 2011 | 9780521149273 | 2023/12/28 |
| 750 | 数学 (Mathematics) | Chaos and Dynamical Systems (Primers in Complex Systems) | David P. Feldman | Princeton University Press | 262 p. | 2019 | 9780691161525 | 2023/12/24 |
| 751 | 神経科学・認知科学 (Neuroscience) | The Noisy Brain: Stochastic Dynamics as a Principle of Brain Function | Edmund T. Rolls (他: Gustavo Deco) | Oxford University Press | 314 p. | 2010 | 9780199587865 | 2023/12/20 |
| 752 | 数学 (Mathematics) | Chaos: The Science of Predictable Random Motion | Richard Kautz | Oxford University Press | 384 p. | 2010 | 9780199594580 | 2023/12/20 |
| 753 | 生物学・生命科学 (Biology) | Cell Signalling | John T. Hancock | Oxford University Press | 368 p. | 1997 (2010) | 9780199232109 | 2023/12/20 |
| 754 | 数学 (Mathematics) | Stochastic Analysis and Diffusion Processes (Oxford Graduate Texts in Mathematics) | Gopinath Kallianpur (他: P Sundar) | Oxford University Press | 368 p. | 2014 | 9780199657070 | 2023/12/18 |
| 755 | 数学 (Mathematics) | New Perspectives in Stochastic Geometry | Wilfrid S. Kendall (他: Ilya Molchanov) | Oxford University Press | 606 p. | 2009 (2010) | 9780199232574 | 2023/12/18 |
| 756 | 数学 (Mathematics) | Chaos and Time-Series Analysis | Julien Clinton Sprott | Oxford University Press | 507 p. | 2001 (2003) | 9780198508403 | 2023/12/18 |
| 757 | 神経科学・認知科学 (Neuroscience) | Neurotheology: How Science Can Enlighten Us About Spirituality | Andrew B. Newberg | Columbia University Press | 330 p. | 2018 | 9780231546775 | 2023/12/01 |
| 758 | 神経科学・認知科学 (Neuroscience) | Principles of Neurotheology (Routledge Science and Religion Series) | Andrew B. Newberg | Routledge | 288 p. | 2010 | 9780754669944 | 2023/12/01 |
| 759 | 生物学・生命科学 (Biology) | Moon Lists: Questions and Rituals for Self-Reflection: A Guided Journal | Leigh Patterson | Clarkson Potter | 160 p. | 2019 | 9781984822727 | 2023/11/07 |
| 760 | 生物学・生命科学 (Biology) | Eternal Questions: A Maybe Interesting List | Iwanna Twainbee | Atmosphere Press | 106 p. | 2022 | - | 2023/11/07 |
| 761 | 生物学・生命科学 (Biology) | Biochemical Oscillations and Cellular Rhythms: The Molecular Bases of Periodic and Chaotic Behaviour (Volume 0) | Albert Goldbeter (他: M. J. Berridge) | Cambridge University Press | 632 p. | 1996 (1997) | 9780521599467 | 2023/11/07 |
| 762 | 生物学・生命科学 (Biology) | Systems Biology: Properties of Reconstructed Networks | Bernhard O. Palsson | Cambridge University Press | 336 p. | 2006 | 9780521859035 | 2023/11/07 |
| 763 | 生物学・生命科学 (Biology) | Systems Biology: Simulation of Dynamic Network States | Bernhard O. Palsson | Cambridge University Press | 332 p. | 2011 | 9781107001596 | 2023/11/07 |
| 764 | 生物学・生命科学 (Biology) | System Modeling in Cellular Biology: From Concepts to Nuts and Bolts | Zoltan Szallasi (他: Vipul Periwal, Jorg Stelling) | Mit Pr | 448 p. | 2006 (2010) | 9780262514224 | 2023/11/07 |
| 765 | 計算機科学・情報科学 (Computer Science) | Understanding Molecular Simulation: From Algorithms to Applications (Computational Science Series, Vol 1) | Daan Frenkel (他: Berend Smit) | Academic Press | 664 p. | 1996 (2001) | 9780122673511 | 2023/10/29 |
| 766 | 数学 (Mathematics) | Simulation and Learning: A Model-Centered Approach | Franco Landriscina (他: Norbert Seel) | Springer | 253 p. | 2012 (2013) | 9781461419532 | 2023/10/28 |
| 767 | 計算機科学・情報科学 (Computer Science) | Stochastic Modelling for Systems Biology, Third Edition (Chapman & Hall/CRC Computational Biology Series) | Darren J Wilkinson | Chapman and Hall/CRC | 404 p. | 2006 (2018) | 9781351000901 | 2023/10/23 |
| 768 | 数学 (Mathematics) | Stochastic Dynamical Systems: Concepts, Numerical Methods, Data Analysis | Josef Honerkamp | Wiley-VCH | 552 p. | 1993 (1996) | 9780471188346 | 2023/10/23 |
| 769 | 物理学 (Physics) | Stochastic Processes in Physics and Chemistry (North-Holland Personal Library) | N.G. Van Kampen | North Holland | 480 p. | 1981 (2007) | 9780444529657 | 2023/10/23 |
| 770 | 数学 (Mathematics) | The Complete Idiot's Guide to Statistics, 2nd Edition | Robert A. Donnelly Jr. | - | - | 2007 | - | 2023/10/22 |
| 771 | 神経科学・認知科学 (Neuroscience) | Textbook of Traumatic Brain Injury. Third edition | Jonathan M. Silver (他: Thomas W. McAllister, David B. Arciniegas) | American Psychiatric Association Publishing | 985 p. | 2019 | 9781615371129 | 2023/10/10 |
| 772 | 生物学・生命科学 (Biology) | Oxford Textbook of Cancer Biology (Oxford Textbooks in Oncology) | Francesco Pezzella (他: Mahvash Tavassoli, David J. Kerr) | OUP Oxford | 499 p. | 2019 | 9780191084874 | 2023/10/07 |
| 773 | 数学 (Mathematics) | The Oxford Handbook of the History of Mathematics | Jacqueline A. Stedall (他: Eleanor Robson) | Oxford University Press | 928 p. | 2008 (2011) | 9780199603190 | 2023/09/29 |
| 774 | 数学 (Mathematics) | The Maths Book: Big Ideas Simply Explained | D.K. Publishing | DK | 352 p. | 2019 | 9780241350362 | 2023/09/27 |
